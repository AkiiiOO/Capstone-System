﻿namespace ILAGAN_Management_System
{
    partial class ViewInventoryMasterList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewInventoryMasterList));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Print = new ILAGAN_Management_System.RoundedButton();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Quantity = new System.Windows.Forms.Label();
            this.lbl_EquipmentCondition = new System.Windows.Forms.Label();
            this.lbl_EquipmentType = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.lbl_DamageNote = new System.Windows.Forms.Label();
            this.lbl_EquipmentQuality = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pnl_InvetoryMasterList = new System.Windows.Forms.Panel();
            this.lbl_EquipmentName = new System.Windows.Forms.Label();
            this.lbl_EquipmentID = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_InvetoryMasterList.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.btn_Print);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(395, 68);
            this.panel1.TabIndex = 65;
            // 
            // btn_Print
            // 
            this.btn_Print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Print.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Print.BorderRadius = 5;
            this.btn_Print.BorderSize = 0;
            this.btn_Print.FlatAppearance.BorderSize = 0;
            this.btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Print.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Print.ForeColor = System.Drawing.Color.White;
            this.btn_Print.Location = new System.Drawing.Point(322, 28);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(70, 30);
            this.btn_Print.TabIndex = 136;
            this.btn_Print.Text = "Print";
            this.btn_Print.TextColor = System.Drawing.Color.White;
            this.btn_Print.UseVisualStyleBackColor = false;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Inventory Master List";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 16);
            this.label6.TabIndex = 135;
            this.label6.Text = "Equipment Condition:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 207);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 16);
            this.label3.TabIndex = 134;
            this.label3.Text = "Quantity:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(25, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(155, 15);
            this.label14.TabIndex = 130;
            this.label14.Text = "Equipment Information";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(25, 107);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 16);
            this.label12.TabIndex = 128;
            this.label12.Text = "Equipment Type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 240);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 16);
            this.label4.TabIndex = 126;
            this.label4.Text = "Damage Note:";
            // 
            // lbl_Quantity
            // 
            this.lbl_Quantity.AutoSize = true;
            this.lbl_Quantity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quantity.Location = new System.Drawing.Point(171, 207);
            this.lbl_Quantity.Name = "lbl_Quantity";
            this.lbl_Quantity.Size = new System.Drawing.Size(67, 16);
            this.lbl_Quantity.TabIndex = 125;
            this.lbl_Quantity.Text = "---------------";
            // 
            // lbl_EquipmentCondition
            // 
            this.lbl_EquipmentCondition.AutoSize = true;
            this.lbl_EquipmentCondition.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipmentCondition.Location = new System.Drawing.Point(171, 172);
            this.lbl_EquipmentCondition.Name = "lbl_EquipmentCondition";
            this.lbl_EquipmentCondition.Size = new System.Drawing.Size(67, 16);
            this.lbl_EquipmentCondition.TabIndex = 124;
            this.lbl_EquipmentCondition.Text = "---------------";
            // 
            // lbl_EquipmentType
            // 
            this.lbl_EquipmentType.AutoSize = true;
            this.lbl_EquipmentType.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipmentType.Location = new System.Drawing.Point(171, 107);
            this.lbl_EquipmentType.Name = "lbl_EquipmentType";
            this.lbl_EquipmentType.Size = new System.Drawing.Size(67, 16);
            this.lbl_EquipmentType.TabIndex = 123;
            this.lbl_EquipmentType.Text = "---------------";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // lbl_DamageNote
            // 
            this.lbl_DamageNote.AutoSize = true;
            this.lbl_DamageNote.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DamageNote.Location = new System.Drawing.Point(171, 240);
            this.lbl_DamageNote.Name = "lbl_DamageNote";
            this.lbl_DamageNote.Size = new System.Drawing.Size(67, 16);
            this.lbl_DamageNote.TabIndex = 116;
            this.lbl_DamageNote.Text = "---------------";
            // 
            // lbl_EquipmentQuality
            // 
            this.lbl_EquipmentQuality.AutoSize = true;
            this.lbl_EquipmentQuality.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipmentQuality.Location = new System.Drawing.Point(171, 139);
            this.lbl_EquipmentQuality.Name = "lbl_EquipmentQuality";
            this.lbl_EquipmentQuality.Size = new System.Drawing.Size(67, 16);
            this.lbl_EquipmentQuality.TabIndex = 115;
            this.lbl_EquipmentQuality.Text = "---------------";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 139);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 16);
            this.label9.TabIndex = 111;
            this.label9.Text = "Equipment Quality:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 16);
            this.label2.TabIndex = 108;
            this.label2.Text = "Equipment Name:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Location = new System.Drawing.Point(25, 34);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(350, 2);
            this.panel7.TabIndex = 103;
            // 
            // pnl_InvetoryMasterList
            // 
            this.pnl_InvetoryMasterList.Controls.Add(this.lbl_EquipmentID);
            this.pnl_InvetoryMasterList.Controls.Add(this.label7);
            this.pnl_InvetoryMasterList.Controls.Add(this.label6);
            this.pnl_InvetoryMasterList.Controls.Add(this.label3);
            this.pnl_InvetoryMasterList.Controls.Add(this.label14);
            this.pnl_InvetoryMasterList.Controls.Add(this.label12);
            this.pnl_InvetoryMasterList.Controls.Add(this.label4);
            this.pnl_InvetoryMasterList.Controls.Add(this.lbl_Quantity);
            this.pnl_InvetoryMasterList.Controls.Add(this.lbl_EquipmentCondition);
            this.pnl_InvetoryMasterList.Controls.Add(this.lbl_EquipmentType);
            this.pnl_InvetoryMasterList.Controls.Add(this.lbl_DamageNote);
            this.pnl_InvetoryMasterList.Controls.Add(this.lbl_EquipmentQuality);
            this.pnl_InvetoryMasterList.Controls.Add(this.lbl_EquipmentName);
            this.pnl_InvetoryMasterList.Controls.Add(this.label9);
            this.pnl_InvetoryMasterList.Controls.Add(this.label2);
            this.pnl_InvetoryMasterList.Controls.Add(this.panel7);
            this.pnl_InvetoryMasterList.Location = new System.Drawing.Point(0, 64);
            this.pnl_InvetoryMasterList.Name = "pnl_InvetoryMasterList";
            this.pnl_InvetoryMasterList.Size = new System.Drawing.Size(395, 295);
            this.pnl_InvetoryMasterList.TabIndex = 66;
            // 
            // lbl_EquipmentName
            // 
            this.lbl_EquipmentName.AutoSize = true;
            this.lbl_EquipmentName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipmentName.Location = new System.Drawing.Point(171, 76);
            this.lbl_EquipmentName.Name = "lbl_EquipmentName";
            this.lbl_EquipmentName.Size = new System.Drawing.Size(67, 16);
            this.lbl_EquipmentName.TabIndex = 114;
            this.lbl_EquipmentName.Text = "---------------";
            // 
            // lbl_EquipmentID
            // 
            this.lbl_EquipmentID.AutoSize = true;
            this.lbl_EquipmentID.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipmentID.Location = new System.Drawing.Point(171, 50);
            this.lbl_EquipmentID.Name = "lbl_EquipmentID";
            this.lbl_EquipmentID.Size = new System.Drawing.Size(67, 16);
            this.lbl_EquipmentID.TabIndex = 137;
            this.lbl_EquipmentID.Text = "---------------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 16);
            this.label7.TabIndex = 136;
            this.label7.Text = "Equipment Name:";
            // 
            // ViewInventoryMasterList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 359);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_InvetoryMasterList);
            this.Name = "ViewInventoryMasterList";
            this.Text = "ViewInventoryMasterList";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_InvetoryMasterList.ResumeLayout(false);
            this.pnl_InvetoryMasterList.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private RoundedButton btn_Print;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_Quantity;
        private System.Windows.Forms.Label lbl_EquipmentCondition;
        private System.Windows.Forms.Label lbl_EquipmentType;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label lbl_DamageNote;
        private System.Windows.Forms.Label lbl_EquipmentQuality;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel pnl_InvetoryMasterList;
        private System.Windows.Forms.Label lbl_EquipmentName;
        private System.Windows.Forms.Label lbl_EquipmentID;
        private System.Windows.Forms.Label label7;
    }
}