﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace ILAGAN_Management_System
{
    public partial class LoginForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        int attempts = 0;
        int maxAttempts = 3;
        DateTime lastFailedAttempt;  
        
        public LoginForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void chk_ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_ShowPassword.Checked == true)
            {
                txtpassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }
       
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (attempts >= maxAttempts && DateTime.Now < lastFailedAttempt.AddSeconds(30))
            {
                // If attempts exceeded and 30 seconds haven't passed
                MessageBox.Show("You have exceeded the maximum login attempts. Please wait 30 seconds before trying again.", "Too Many Attempts", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (DateTime.Now >= lastFailedAttempt.AddSeconds(30))
            {
                attempts = 0;
            }

            //Validations
            //Check for spaces in username or password
            if (txtusername.Text.Contains(" ") || txtpassword.Text.Contains(" ") || string.IsNullOrEmpty(txtusername.Text) || string.IsNullOrEmpty(txtpassword.Text))
            {
                MessageBox.Show("Username and Password cannot contain spaces.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LoginAttempt();
                return;
            }

            try
            {
                string hashedPassword = HashPassword(txtpassword.Text);

                string query = @"SELECT u.UserID, u.Username, u.StatusID, u.FirstName, u.LastName, ua.AccessLevelID, al.AccessLevelName 
                                 FROM Users u 
                                 INNER JOIN UserAccessLevels ua ON u.UserID = ua.UserID 
                                 INNER JOIN AccessLevels al ON ua.AccessLevelID = al.AccessLevelID 
                                 WHERE u.Username COLLATE Latin1_General_BIN = @Username 
                                 AND u.Password COLLATE Latin1_General_BIN = @Password";

                SqlCommand command = new SqlCommand(query, db);

                command.Parameters.AddWithValue("@Username", txtusername.Text);
                command.Parameters.AddWithValue("@Password", hashedPassword);

                y.Open();

                SqlDataReader dr = command.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    int userID = Convert.ToInt32(dr["UserID"]);
                    string status = dr["StatusID"].ToString();
                    string accessLevelID = dr["AccessLevelID"].ToString();
                    string accessLevelName = dr["AccessLevelName"].ToString();
                    string username = dr["Username"].ToString();
                    string firstName = dr["FirstName"].ToString();
                    string lastName = dr["LastName"].ToString();

                    
                    if (status == "1")
                    {
                        CurrentUser.UserID = userID;
                        CurrentUser.AccessLevel = accessLevelID;
                        CurrentUser.Username = username;
                        CurrentUser.FirstName = firstName;
                        CurrentUser.LastName = lastName;


                        dr.Close();

                        LogUserLogin(userID);
                        MessageBox.Show("Welcome " + username);

                        this.Hide();
                        Home form2 = new Home();
                        form2.Show();
                    }
                    else
                    {
                        MessageBox.Show("This account is deactivated.", "Deactivated Account", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    
                }
                else
                {
                    MessageBox.Show("Username or Password is incorrect. Please note that the login is case-sensitive.", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    LoginAttempt();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                y.Close();
            }
        }
        private void LogUserLogin(int userID)
        {
            try
            {
                string loginQuery = "INSERT INTO UserLog (UserID, LoginDateTime) OUTPUT INSERTED.LogID VALUES (@UserID, GETDATE())";
                SqlCommand loginCommand = new SqlCommand(loginQuery, db);
                loginCommand.Parameters.AddWithValue("@UserID", userID);

                CurrentUser.LogID = (int)loginCommand.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while logging in: " + ex.Message);
            }
        }
        //hash pasword detection
        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void LoginAttempt()
        {
            attempts++;
            lastFailedAttempt = DateTime.Now;
            MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtusername.Clear();
            txtpassword.Clear();
            txtusername.Focus();

            if (attempts >= maxAttempts)
            {
                MessageBox.Show("Maximum login attempts reached. You can try again in 30 seconds.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_ForgotPassword_Click(object sender, EventArgs e)
        {
            ForgotPassword forgotPasswordForm = new ForgotPassword();
            forgotPasswordForm.ShowDialog();
        }
    }
    public class CurrentUser
    {
        public static int UserID { get; set; }
        public static string AccessLevel { get; set; }
        public static string Username { get; set; }
        public static string FirstName { get; set; }
        public static string LastName { get; set; }
        public static int LogID { get; set; }
    }
}


