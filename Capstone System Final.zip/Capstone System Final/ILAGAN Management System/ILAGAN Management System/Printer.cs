﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public class Printer
    {

        public string PageTitle { get; set; }
        public string PageSubtitle { get; set; }
        public Image PageImage { get; set; }


        private DataGridView _dataGridView;
        private PrintDocument _printDocument;
        private int _currentRow;
        private StringFormat _stringFormat;


        public Printer(DataGridView dataGridView)
        {
            _dataGridView = dataGridView;
            _printDocument = new PrintDocument();
            _printDocument.DefaultPageSettings.Landscape = true;
            _printDocument.PrintPage += PrintDocument_PrintPage;
            _stringFormat = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Trimming = StringTrimming.EllipsisCharacter
            };
        }

        public void Print()
        {
            using (PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog())
            {
                printPreviewDialog.Document = _printDocument;
                printPreviewDialog.Width = 800;
                printPreviewDialog.Height = 600;

                if (printPreviewDialog.ShowDialog() == DialogResult.OK)
                {
                    _printDocument.Print();
                }
            }
        }


        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            int leftMargin = e.MarginBounds.Left;
            int topMargin = e.MarginBounds.Top;
            int totalWidth = e.MarginBounds.Width;
            int totalHeight = e.MarginBounds.Height;
            int totalColumns = _dataGridView.Columns.Count;

            e.PageSettings.Landscape = true;

            int totalGridWidth = 0;
            foreach (DataGridViewColumn column in _dataGridView.Columns)
            {
                if (column.Visible) 
                    totalGridWidth += column.Width;
            }

            int[] columnWidths = new int[totalColumns];
            for (int i = 0; i < totalColumns; i++)
            {
                if (_dataGridView.Columns[i].Visible) 
                {
                    columnWidths[i] = (int)((_dataGridView.Columns[i].Width / (float)totalGridWidth) * totalWidth);
                }
                else
                {
                    columnWidths[i] = 0; 
                }
            }

            using (Font subtitleFont = new Font("Arial", 10, FontStyle.Bold))
            using (Font titleFont = new Font("Arial", 22, FontStyle.Bold))
            using (Font headerFont = new Font("Arial", 9, FontStyle.Bold))
            using (Font rowFont = new Font("Arial", 8))
            {
                int rowHeight = _dataGridView.RowTemplate.Height + 5;
                int headerHeight = rowHeight + 10;

                StringFormat stringFormat = new StringFormat
                {
                    Alignment = StringAlignment.Near,
                    LineAlignment = StringAlignment.Center,
                    Trimming = StringTrimming.EllipsisCharacter
                };

                if (!string.IsNullOrEmpty(PageTitle))
                {
                    e.Graphics.DrawString(PageTitle, titleFont, Brushes.Black,
                        new RectangleF(leftMargin, topMargin - -10, totalWidth, rowHeight * 2),
                        _stringFormat);
                    topMargin += 1;
                }

                // Draw the page subtitle
                if (!string.IsNullOrEmpty(PageSubtitle))
                {
                    e.Graphics.DrawString(PageSubtitle, subtitleFont, Brushes.Gray,
                        new RectangleF(leftMargin, topMargin - -40, totalWidth, rowHeight * 2),
                        _stringFormat);
                    topMargin += 20;
                }

                int imageWidth = 0, imageHeight = 0;

                if (PageImage != null)
                {
                    imageHeight = 100;
                    imageWidth = (int)((float)PageImage.Width / PageImage.Height * imageHeight); 
                    Rectangle imageRect = new Rectangle(leftMargin - -400, topMargin - 110, imageWidth, imageHeight);
                    e.Graphics.DrawImage(PageImage, imageRect);

                    //  gap between the image and the title text
                    leftMargin += imageWidth;
                }
   

                // Draw column headers
                for (int i = 0; i < totalColumns; i++)
                {
                    if (_dataGridView.Columns[i].Visible) 
                    {
                        RectangleF headerRect = new RectangleF(leftMargin -100 , topMargin - -80, columnWidths[i], headerHeight);
                        e.Graphics.FillRectangle(Brushes.LightGray, headerRect);
                        e.Graphics.DrawRectangle(Pens.Black, Rectangle.Round(headerRect));
                        e.Graphics.DrawString(_dataGridView.Columns[i].HeaderText, headerFont, Brushes.Black, headerRect, stringFormat);
                        leftMargin += columnWidths[i];
                    }
                }

                topMargin += headerHeight; 
                leftMargin = e.MarginBounds.Left; 

                // Draw rows
                while (_currentRow < _dataGridView.Rows.Count)
                {
                    DataGridViewRow row = _dataGridView.Rows[_currentRow];
                    for (int i = 0; i < totalColumns; i++)
                    {
                        if (_dataGridView.Columns[i].Visible) 
                        {
                            RectangleF cellRect = new RectangleF(leftMargin, topMargin - -80, columnWidths[i], rowHeight);
                            e.Graphics.DrawRectangle(Pens.Black, Rectangle.Round(cellRect));

                            // Get cell value
                            if (row.Cells[i].Value != null)
                            {
                                e.Graphics.DrawString(row.Cells[i].Value.ToString(), rowFont, Brushes.Black, cellRect, stringFormat);
                            }

                            leftMargin += columnWidths[i];
                        }
                    }

                    topMargin += rowHeight;
                    leftMargin = e.MarginBounds.Left; 

                    if (topMargin + rowHeight > e.MarginBounds.Bottom)
                    {
                        _currentRow++;
                        e.HasMorePages = true;
                        return;
                    }

                    _currentRow++; 
                }

                // End of printing
                _currentRow = 0;
                e.HasMorePages = false;
            }
        }

        private void HideEmptyColumns(DataGridView dataGridView)
        {
            foreach (DataGridViewColumn column in dataGridView.Columns)
            {
                bool isEmpty = true;

                // Check if all cells in the column are empty
                foreach (DataGridViewRow row in dataGridView.Rows)
                {
                    if (row.Cells[column.Index].Value != null &&
                         row.Cells[column.Index].Value.ToString().Trim() != "")
                    {
                        isEmpty = false;
                        break;
                    }
                }

                // Hide the column if it's empty
                column.Visible = !isEmpty;
            }
        }
    }
}
