﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CustomizePackage : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        //For package name and id
        private int selectedPackageId;
        //casket
        public int SelectedCasketID { get; set; }
        private decimal casketPrice = 0.0M;
        //Vehicle
        public int SelectedVehicleID { get; set; }
        private decimal vehiclePrice = 0.0M;
        //Flower Arrangment
        public int SelectedFlowerID { get; set; }
        private string flowerName;
        private int flowerQuantity;
        private decimal flowerPrice = 0.0M;
        private decimal flowerPricedisplaying = 0.0M;

        //Equipments
        public int equipmentID { get; set; }
        string equipmentName;
        int equipmentQuantity;
        int equipmentQualityID;
        int equipmentConditionID ;
        string damageNote;


        // Embalming Prices
        private decimal baseEmbalmingPrice = 0.0M;
        private decimal additionalDayCharge = 0.0M;
        private int includedDays = 0;

        public int CustomizePackageID { get; private set; }

        public CustomizePackage(int customizepackageID)
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadPackage();
            LoadEmbalmingPrices();
            InitializeDataGridView();
            if (customizepackageID != 0)
            {
                MessageBox.Show("Loading customize package details for ID: " + customizepackageID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.CustomizePackageID = customizepackageID;
                LoadCustomizePackageDetails(this.CustomizePackageID);
            }
            
        }
        private void InitializeDataGridView()
        {
            if (dgv_FlowerArrangement.Columns.Count == 0)
            {
                dgv_FlowerArrangement.Columns.Add("FlowerID", "Flower ID");
                dgv_FlowerArrangement.Columns.Add("FlowerName", "Flower");
                dgv_FlowerArrangement.Columns.Add("FlowerPrice", "Price");
                dgv_FlowerArrangement.Columns.Add("Quantity", "Quantity");
            }
            if (dgv_Equipments.Columns.Count == 0)
            {
                dgv_Equipments.Columns.Add("EquipmentName", "Equipment Name");
                dgv_Equipments.Columns.Add("EquipmentType", "Equipment Type");
                dgv_Equipments.Columns.Add("EquipmentQuality", "Quality");
                dgv_Equipments.Columns.Add("EquipmentCondition", "Condition");
                dgv_Equipments.Columns.Add("Quantity", "Quantity");
                dgv_Equipments.Columns.Add("DamageNote", "Damage Note");
            }
        }
        private void LoadCustomizePackageDetails(int customizePackageID)
        {
            string query = @"SELECT cp.PackageID, cp.PackageName, cp.CasketName, c.Price AS CasketPrice, 
                            cp.VehicleName, v.Price AS VehiclePrice, cp.EmbalmingDays, cp.TotalPrice,
                            cp.CasketID, cp.VehicleID
                     FROM CustomizePackage cp
                     LEFT JOIN Casket c ON cp.CasketID = c.CasketID
                     LEFT JOIN Vehicle v ON cp.VehicleID = v.VehicleID
                     WHERE cp.CustomizePackageID = @CustomizePackageID";

            string flowerQuery = @"SELECT ArrangementID, FlowerArrangementName, Quantity, PricePerUnit 
                           FROM CustomizePackageFlowerArrangements 
                           WHERE CustomizePackageID = @CustomizePackageID";

            string equipmentQuery = @"SELECT EquipmentID, EquipmentName, EquipmentType, EquipmentQualityID, 
                             EquipmentConditionID, EquipmentQuality, EquipmentCondition, Quantity, DamageNote
                      FROM CustomizePackageEquipments
                      WHERE CustomizePackageID = @CustomizePackageID";

            try
            {
                db.Open();

                // Load main package details
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@CustomizePackageID", customizePackageID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Load main package details
                            selectedPackageId = reader["PackageID"] != DBNull.Value ? Convert.ToInt32(reader["PackageID"]) : -1;
                            cmb_Package.SelectedValue = selectedPackageId;

                            txt_Casket.Text = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                            txt_Vehicle.Text = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                            txt_EmbalmingDays.Text = reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A";

                            decimal totalPrice = reader["TotalPrice"] != DBNull.Value ? Convert.ToDecimal(reader["TotalPrice"]) : 0;
                            txt_PackagePrice.Text = totalPrice.ToString("F2");
                            decimal casketPrice = reader["CasketPrice"] != DBNull.Value ? Convert.ToDecimal(reader["CasketPrice"]) : 0;
                            txt_CasketPrice.Text = casketPrice.ToString("F2");

                            // Display Vehicle Price
                            decimal vehiclePrice = reader["VehiclePrice"] != DBNull.Value ? Convert.ToDecimal(reader["VehiclePrice"]) : 0;
                            txt_VehiclePrice.Text = vehiclePrice.ToString("F2");

                            SelectedCasketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                            SelectedVehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                        }
                    }
                }

                // Load flower arrangements
                using (SqlCommand flowerCommand = new SqlCommand(flowerQuery, db))
                {
                    flowerCommand.Parameters.AddWithValue("@CustomizePackageID", customizePackageID);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(flowerCommand))
                    {
                        DataTable flowerTable = new DataTable();
                        adapter.Fill(flowerTable);

                        dgv_FlowerArrangement.Rows.Clear();
                        foreach (DataRow row in flowerTable.Rows)
                        {
                            dgv_FlowerArrangement.Rows.Add(
                                row["ArrangementID"],
                                row["FlowerArrangementName"],
                                row["PricePerUnit"],
                                row["Quantity"]
                            );
                        }
                    }
                }
                // Load equipment details
                using (SqlCommand equipmentCommand = new SqlCommand(equipmentQuery, db))
                {
                    equipmentCommand.Parameters.AddWithValue("@CustomizePackageID", customizePackageID);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(equipmentCommand))
                    {
                        DataTable equipmentTable = new DataTable();
                        adapter.Fill(equipmentTable);

                        dgv_Equipments.Rows.Clear();
                        foreach (DataRow row in equipmentTable.Rows)
                        {
                            equipmentID = row["EquipmentID"] != DBNull.Value ? Convert.ToInt32(row["EquipmentID"]) : 0;
                            equipmentQualityID = row["EquipmentQualityID"] != DBNull.Value ? Convert.ToInt32(row["EquipmentQualityID"]) : 0;
                            equipmentConditionID = row["EquipmentConditionID"] != DBNull.Value ? Convert.ToInt32(row["EquipmentConditionID"]) : 0;

                            dgv_Equipments.Rows.Add(
                                row["EquipmentName"],
                                row["EquipmentType"],
                                row["EquipmentQuality"],
                                row["EquipmentCondition"],
                                row["Quantity"],
                                row["DamageNote"] != DBNull.Value ? row["DamageNote"].ToString() : "None"
                            );

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading customize package details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadEmbalmingPrices()
        {
            string query = "SELECT IncludedDays, BasePrice, AdditionalDayCharge FROM EmbalmingPrice";

            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    includedDays = reader.GetInt32(0);
                    baseEmbalmingPrice = reader.GetDecimal(1);
                    additionalDayCharge = reader.GetDecimal(2);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading embalming prices: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadPackage()
        {
            cmb_Package.Items.Clear();
            string query = "SELECT PackageID, PackageName FROM Package";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable packageTable = new DataTable();
                adapter.Fill(packageTable);

                cmb_Package.DataSource = packageTable;
                cmb_Package.DisplayMember = "PackageName";
                cmb_Package.ValueMember = "PackageID";

                cmb_Package.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading packages: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void cmb_Package_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CustomizePackageID == 0)
            {
                if (cmb_Package.SelectedValue != null && cmb_Package.SelectedValue is int)
                {
                    selectedPackageId = (int)cmb_Package.SelectedValue;
                    LoadPackageDetails(selectedPackageId);
                }
                else
                {
                    ClearCustomSelections();
                    UpdateEmbalmingPrice();
                }
            }
        }
        private void ClearCustomSelections()
        {
            txt_Casket.Text = txt_Vehicle.Text = txt_EmbalmingDays.Text = "";
            dgv_FlowerArrangement.Rows.Clear();
            casketPrice = vehiclePrice = flowerPrice = 0.0M;
            baseEmbalmingPrice = additionalDayCharge = 0.0M;
            includedDays = 0;
            txt_PackagePrice.Text = "0.00";
        }

        private void LoadPackageDetails(int packageId)
        {
            string query = @"SELECT p.PackageName, c.CasketID, c.CasketName, c.Price AS CasketPrice, 
                            v.VehicleID, v.VehicleName, v.Price AS VehiclePrice, p.EmbalmingDays, p.TotalPrice 
                     FROM Package p
                     LEFT JOIN Casket c ON p.CasketID = c.CasketID
                     LEFT JOIN Vehicle v ON p.VehicleID = v.VehicleID
                     WHERE p.PackageID = @PackageID";

            string flowersQuery = @"SELECT pf.ArrangementID, pf.FlowerArrangementName, pf.Quantity,  pf.PricePerUnit 
                                            FROM PackageFlowerArrangements pf
                                            WHERE pf.PackageID = @PackageID";

            string equipmentQuery = @"SELECT pe.PackageEquipmentID, pe.EquipmentID, pe.EquipmentQualityID, pe.EquipmentConditionID, 
                                     pe.EquipmentName, pe.EquipmentType, pe.EquipmentQuality, 
                                     pe.EquipmentCondition, pe.Quantity, pe.DamageNote 
                              FROM PackageEquipments pe
                              WHERE pe.PackageID = @PackageID";

            try
            {
                db.Open();

                // Load package details
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@PackageID", packageId);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    // Populate package details
                    txt_Casket.Text = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                    txt_Vehicle.Text = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                    txt_EmbalmingDays.Text = reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A";

                    decimal totalPrice = reader["TotalPrice"] != DBNull.Value ? Convert.ToDecimal(reader["TotalPrice"]) : 0;
                    txt_PackagePrice.Text = totalPrice.ToString("F2");

                    SelectedCasketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                    SelectedVehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;

                    casketPrice = reader["CasketPrice"] != DBNull.Value ? Convert.ToDecimal(reader["CasketPrice"]) : 0;
                    vehiclePrice = reader["VehiclePrice"] != DBNull.Value ? Convert.ToDecimal(reader["VehiclePrice"]) : 0;

                    txt_VehiclePrice.Text = vehiclePrice.ToString("F2");
                    txt_CasketPrice.Text = casketPrice.ToString("F2");
                }
                reader.Close();

                // Load flower arrangements
                using (SqlCommand flowersCommand = new SqlCommand(flowersQuery, db))
                {
                    flowersCommand.Parameters.AddWithValue("@PackageID", packageId);
                    using (SqlDataReader flowersReader = flowersCommand.ExecuteReader())
                    {
                        flowerPricedisplaying = 0.0M; 
                        dgv_FlowerArrangement.Rows.Clear();
                        while (flowersReader.Read())
                        {
                            
                           
                            SelectedFlowerID = Convert.ToInt32(flowersReader["ArrangementID"]);
                            flowerName = flowersReader["FlowerArrangementName"].ToString();
                            flowerQuantity = Convert.ToInt32(flowersReader["Quantity"]);
                            flowerPrice = Convert.ToDecimal(flowersReader["PricePerUnit"]);
                            flowerPricedisplaying += flowerPrice * flowerQuantity;

                            
                            dgv_FlowerArrangement.Rows.Add(
                                SelectedFlowerID,
                                flowerName,
                                flowerPrice.ToString("F2"),
                                flowerQuantity
                            );
                            
                            
                        }
                        
                        txt_FlowerPrice.Text = flowerPricedisplaying.ToString("N2");
                    }
                }
                
                // Load equipment details
                using (SqlCommand equipmentCommand = new SqlCommand(equipmentQuery, db))
                {
                    equipmentCommand.Parameters.AddWithValue("@PackageID", packageId);
                    using (SqlDataReader equipmentReader = equipmentCommand.ExecuteReader())
                    {
                        dgv_Equipments.Rows.Clear();
                        while (equipmentReader.Read())
                        {
                            
                            equipmentID = Convert.ToInt32(equipmentReader["EquipmentID"]);
                            equipmentQualityID = Convert.ToInt32(equipmentReader["EquipmentQualityID"]);
                            equipmentConditionID = Convert.ToInt32(equipmentReader["EquipmentConditionID"]);
                            equipmentName = equipmentReader["EquipmentName"].ToString();
                            equipmentQuantity = Convert.ToInt32(equipmentReader["Quantity"]);

                            
                            dgv_Equipments.Rows.Add(
                                equipmentName,
                                equipmentReader["EquipmentType"].ToString(),
                                equipmentReader["EquipmentQuality"].ToString(),
                                equipmentReader["EquipmentCondition"].ToString(),
                                equipmentQuantity,
                                equipmentReader["DamageNote"].ToString() ?? "N/A"
                            );
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading package details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                SelectedCasketID = selectCasketForm.SelectedCasketID;

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                SelectedVehicleID = selectVehicleForm.SelectedVehicleID;

                UpdateEmbalmingPrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                var selectedFlowers = selectFlowerForm.SelectedFlowers;
                dgv_FlowerArrangement.Rows.Clear();
                flowerPrice = 0.0M; 
                foreach (var flower in selectedFlowers)
                {
                    dgv_FlowerArrangement.Rows.Add(flower.FlowerID, flower.FlowerName, flower.FlowerPrice.ToString("F2"), flower.Quantity);

                    flowerPrice += flower.FlowerPrice * flower.Quantity;
                    SelectedFlowerID = flower.FlowerID;
                    flowerName = flower.FlowerName;
                    flowerQuantity = flower.Quantity;
                }

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectEquipment_Click(object sender, EventArgs e)
        {
            SelectEquipments selectEquipmentForm = new SelectEquipments();
            if (selectEquipmentForm.ShowDialog() == DialogResult.OK)
            {
                var selectedEquipments = selectEquipmentForm.SelectedEquipments;
                dgv_Equipments.Rows.Clear();

                foreach (var equipment in selectedEquipments)
                {
                    dgv_Equipments.Rows.Add(equipment.EquipmentName, equipment.EquipmentType, 
                                            equipment.EquipmentQuality,
                                            equipment.EquipmentCondition, equipment.Quantity,
                                            equipment.DamageNote);


                    equipmentID = equipment.EquipmentID;
                    equipmentName = equipment.EquipmentName;
                    equipmentQuantity = equipment.Quantity;
                    equipmentQualityID = equipment.EquipmentQualityID;
                    equipmentConditionID = equipment.EquipmentConditionID;
                    damageNote = equipment.DamageNote;

                }
            }
        }
        private void btn_ClearCasket_Click(object sender, EventArgs e)
        {
            // Clear the casket text field
            txt_Casket.Text = string.Empty;

            // Reset the selected casket ID and price
            SelectedCasketID = 0;
            casketPrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearVehicle_Click(object sender, EventArgs e)
        {
            // Clear the vehicle text field
            txt_Vehicle.Text = string.Empty;

            // Reset the selected vehicle ID and price
            SelectedVehicleID = 0;
            vehiclePrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearArrangement_Click(object sender, EventArgs e)
        {
            if (dgv_FlowerArrangement.Rows.Count > 0)
            {
                dgv_FlowerArrangement.Rows.RemoveAt(0);

                if (dgv_FlowerArrangement.Rows.Count > 0)
                {
                    flowerPrice = 0.0M;
                    SelectedFlowerID = 0;
                    flowerName = string.Empty;
                    flowerQuantity = 0;

                    foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                    {
                        flowerPrice += Convert.ToDecimal(row.Cells[2].Value) * Convert.ToInt32(row.Cells[3].Value);
                    }
                }
                else
                {
                    flowerPrice = 0.0M;
                    SelectedFlowerID = 0;
                    flowerName = string.Empty;
                    flowerQuantity = 0;
                }
                UpdateEmbalmingPrice();
            }
        }
        private void btn_ClearEquipment_Click(object sender, EventArgs e)
        {
            if (dgv_Equipments.Rows.Count > 0)
            {
                dgv_Equipments.Rows.RemoveAt(0);

                if (dgv_Equipments.Rows.Count > 0)
                {
                    equipmentID = 0;
                    equipmentName = string.Empty;
                    equipmentQuantity = 0;
                }
                else
                {
                    equipmentID = 0;
                    equipmentName = string.Empty;
                    equipmentQuantity = 0;
                }
            }
        }

        private void txt_EmbalmingDays_TextChanged(object sender, EventArgs e)
        {
            UpdateEmbalmingPrice();
        }
        private void UpdateEmbalmingPrice()
        {
            if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
            {
                txt_CasketPrice.Text = casketPrice.ToString("N2");
                txt_VehiclePrice.Text = vehiclePrice.ToString("N2");
                txt_FlowerPrice.Text = flowerPrice.ToString("N2");

                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice).ToString("F2");
                return; 
            }
            int embalmingDays = 0;
            if (int.TryParse(txt_EmbalmingDays.Text, out embalmingDays))
            {
                decimal embalmingPrice = 0;
                if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
                {
                    
                    embalmingPrice = baseEmbalmingPrice;
                }
                if (embalmingDays > 0)
                {
                    
                    embalmingPrice = baseEmbalmingPrice;

                    if (embalmingDays > includedDays)
                    {
                        // Calculate additional charges if days exceed the included days
                        int additionalDays = embalmingDays - includedDays;
                        embalmingPrice += additionalDays * additionalDayCharge;
                    }
                }

                
                decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + embalmingPrice;

                // Update the total price in the text box
                txt_CasketPrice.Text = casketPrice.ToString("N2");
                txt_VehiclePrice.Text = vehiclePrice.ToString("N2");
                txt_FlowerPrice.Text = flowerPrice.ToString("N2");
                txt_PackagePrice.Text = totalPrice.ToString("N2");
            }
            else
            {
                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice + baseEmbalmingPrice).ToString("F2");
            }
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmb_Package.SelectedValue == null)
                {
                    MessageBox.Show("Please select a valid package before saving.", "Invalid Package", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; 
                }
                if (CustomizePackageID == 0) 
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to save this package customization?",
                                                         "Confirm Save",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.Yes)
                    {
                        SavePackage();
                        SaveFlowerArrangements();
                        SaveEquipments();
                        MessageBox.Show("Customization saved successfully!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
                else
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to update this package customization?",
                                                         "Confirm Update",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.Yes)
                    {
                        UpdatePackage(); 
                        MessageBox.Show("Customization updated successfully!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving: " + ex.Message);
            }
        }
        private void SavePackage()
        {
            
            decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);
            string packageName = cmb_Package.Text; 

            string query = @"INSERT INTO CustomizePackage (PackageID, CasketID, VehicleID, PackageName,
                             CasketName, VehicleName, EmbalmingDays, TotalPrice, CreatedDate)
                             VALUES (@PackageID, @CasketID, @VehicleID, @PackageName, @CasketName, @VehicleName,
                                     @EmbalmingDays, @TotalPrice, GETDATE());
                             SELECT SCOPE_IDENTITY();";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@PackageID", selectedPackageId > 0 ? (object)selectedPackageId : DBNull.Value);
                command.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                command.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                command.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                command.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(txt_Casket.Text) ? DBNull.Value : (object)txt_Casket.Text);
                command.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(txt_Vehicle.Text) ? DBNull.Value : (object)txt_Vehicle.Text);
                command.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? DBNull.Value : (object)txt_EmbalmingDays.Text);
                command.Parameters.AddWithValue("@TotalPrice", totalPrice);

                try
                {
                    db.Open();
                    CustomizePackageID = Convert.ToInt32(command.ExecuteScalar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving package: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }

        private void SaveFlowerArrangements()
        {
            string query = @"INSERT INTO CustomizePackageFlowerArrangements 
                     (CustomizePackageID, ArrangementID, FlowerArrangementName, Quantity, PricePerUnit)
                     VALUES (@CustomizePackageID, @ArrangementID, @FlowerArrangementName, @Quantity, @PricePerUnit)";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                {
                    if (row.Cells["FlowerID"].Value != null)
                    {
                        command.Parameters.Clear();
                        command.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                        command.Parameters.AddWithValue("@ArrangementID", row.Cells["FlowerID"].Value);
                        command.Parameters.AddWithValue("@FlowerArrangementName", row.Cells["FlowerName"].Value);
                        command.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                        command.Parameters.AddWithValue("@PricePerUnit", row.Cells["FlowerPrice"].Value);

                        try
                        {
                            db.Open();
                            command.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving flower arrangements: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            db.Close();
                        }
                    }
                }
            }
        }
        private void SaveEquipments()
        {
            string query = @"INSERT INTO CustomizePackageEquipments 
                     (CustomizePackageID, EquipmentID, EquipmentQualityID, EquipmentConditionID, 
                      EquipmentName, EquipmentType, EquipmentQuality, EquipmentCondition, Quantity, DamageNote)
                     VALUES 
                     (@CustomizePackageID, @EquipmentID, @EquipmentQualityID, @EquipmentConditionID, 
                      @EquipmentName, @EquipmentType, @EquipmentQuality, @EquipmentCondition, @Quantity, @DamageNote)";



            using (SqlCommand command = new SqlCommand(query, db))
            {
                foreach (DataGridViewRow row in dgv_Equipments.Rows)
                {
                    if (row.Cells["EquipmentName"].Value != null)
                    {
                        command.Parameters.Clear();
                        command.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                        command.Parameters.AddWithValue("@EquipmentID", equipmentID);
                        command.Parameters.AddWithValue("@EquipmentQualityID", equipmentQualityID);
                        command.Parameters.AddWithValue("@EquipmentConditionID", equipmentConditionID);
                        command.Parameters.AddWithValue("@EquipmentName", row.Cells["EquipmentName"].Value);
                        command.Parameters.AddWithValue("@EquipmentType", row.Cells["EquipmentType"].Value);
                        command.Parameters.AddWithValue("@EquipmentQuality", row.Cells["EquipmentQuality"].Value);
                        command.Parameters.AddWithValue("@EquipmentCondition", row.Cells["EquipmentCondition"].Value);
                        command.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                        command.Parameters.AddWithValue("@DamageNote", row.Cells["DamageNote"].Value ?? DBNull.Value);


                        try
                        {
                            db.Open();
                            command.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving equipment: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            db.Close();
                        }
                    }
                }
            }
        }
        private void UpdatePackage()
        {
            
            decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);
            string packageName = cmb_Package.Text;

            string updatePackageQuery = @"UPDATE CustomizePackage 
                                  SET PackageID = @PackageID,
                                      CasketID = @CasketID,
                                      VehicleID = @VehicleID,
                                      PackageName = @PackageName,
                                      CasketName = @CasketName,
                                      VehicleName = @VehicleName,
                                      EmbalmingDays = @EmbalmingDays,
                                      TotalPrice = @TotalPrice
                                  WHERE CustomizePackageID = @CustomizePackageID";

            string deleteFlowerArrangementsQuery = @"DELETE FROM CustomizePackageFlowerArrangements 
                                             WHERE CustomizePackageID = @CustomizePackageID";

            string insertFlowerArrangementsQuery = @"INSERT INTO CustomizePackageFlowerArrangements 
                                             (CustomizePackageID, ArrangementID, FlowerArrangementName, Quantity, PricePerUnit)
                                             VALUES (@CustomizePackageID, @ArrangementID, @FlowerArrangementName, @Quantity, @PricePerUnit)";
           
            string deleteEquipmentsQuery = @"DELETE FROM CustomizePackageEquipments 
                                     WHERE CustomizePackageID = @CustomizePackageID";

            string insertEquipmentsQuery = @"INSERT INTO CustomizePackageEquipments 
                                     (CustomizePackageID, EquipmentID, EquipmentName, EquipmentType, EquipmentQualityID, 
                                      EquipmentConditionID, EquipmentQuality, EquipmentCondition, Quantity, DamageNote)
                                     VALUES (@CustomizePackageID, @EquipmentID, @EquipmentName, @EquipmentType, 
                                             @EquipmentQualityID, @EquipmentConditionID, @EquipmentQuality, 
                                             @EquipmentCondition, @Quantity, @DamageNote)";

            try
            {
                db.Open();

               
                using (SqlCommand updateCommand = new SqlCommand(updatePackageQuery, db))
                {
                    updateCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                    updateCommand.Parameters.AddWithValue("@PackageID", selectedPackageId > 0 ? (object)selectedPackageId : DBNull.Value);
                    updateCommand.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                    updateCommand.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                    updateCommand.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                    updateCommand.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(txt_Casket.Text) ? DBNull.Value : (object)txt_Casket.Text);
                    updateCommand.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(txt_Vehicle.Text) ? DBNull.Value : (object)txt_Vehicle.Text);
                    updateCommand.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? DBNull.Value : (object)txt_EmbalmingDays.Text);
                    updateCommand.Parameters.AddWithValue("@TotalPrice", totalPrice);
                    updateCommand.ExecuteNonQuery();
                }

                // Delete existing flower arrangements
                using (SqlCommand deleteCommand = new SqlCommand(deleteFlowerArrangementsQuery, db))
                {
                    deleteCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                    deleteCommand.ExecuteNonQuery();
                }

                // Insert updated flower arrangements
                using (SqlCommand insertCommand = new SqlCommand(insertFlowerArrangementsQuery, db))
                {
                    foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                    {
                        if (row.Cells["FlowerID"].Value != null)
                        {
                            insertCommand.Parameters.Clear();
                            insertCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                            insertCommand.Parameters.AddWithValue("@ArrangementID", row.Cells["FlowerID"].Value);
                            insertCommand.Parameters.AddWithValue("@FlowerArrangementName", row.Cells["FlowerName"].Value);
                            insertCommand.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                            insertCommand.Parameters.AddWithValue("@PricePerUnit", row.Cells["FlowerPrice"].Value);
                            insertCommand.ExecuteNonQuery();
                        }
                    }
                }
                // Delete existing equipment
                using (SqlCommand deleteEquipmentCommand = new SqlCommand(deleteEquipmentsQuery, db))
                {
                    deleteEquipmentCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                    deleteEquipmentCommand.ExecuteNonQuery();
                }

                // Insert updated equipment
                using (SqlCommand insertEquipmentCommand = new SqlCommand(insertEquipmentsQuery, db))
                {
                    foreach (DataGridViewRow row in dgv_Equipments.Rows)
                    {
                        if (row.Cells["EquipmentName"].Value != null)
                        {
                            insertEquipmentCommand.Parameters.Clear();
                            insertEquipmentCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentID", equipmentID);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentName", row.Cells["EquipmentName"].Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentType", row.Cells["EquipmentType"].Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentQualityID", equipmentQualityID);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentConditionID", equipmentConditionID);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentQuality", row.Cells["EquipmentQuality"].Value ?? DBNull.Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentCondition", row.Cells["EquipmentCondition"].Value ?? DBNull.Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value ?? DBNull.Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@DamageNote", row.Cells["DamageNote"].Value ?? DBNull.Value);

                            insertEquipmentCommand.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating package: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
