﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class DisplayServices : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        private List<DataGridViewRow> selectedRows;

        public DisplayServices(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            LoadSelectedPackages();
            LoadSelectedFlowerArrangements();
            LoadSelectedChapelDetails();
            LoadSelectedEquipment();
        }
        private void LoadSelectedPackages()
        {
            if (selectedRows == null || selectedRows.Count == 0)
            {
                MessageBox.Show("No rows selected.");
                dgv_PackageDetails.DataSource = null;
                return;
            }

            
            DataTable packageDetailsTable = new DataTable();
            packageDetailsTable.Columns.Add("Package Name", typeof(string));
            packageDetailsTable.Columns.Add("Casket Name", typeof(string));
            packageDetailsTable.Columns.Add("Casket Price", typeof(decimal));
            packageDetailsTable.Columns.Add("Vehicle Name", typeof(string));
            packageDetailsTable.Columns.Add("Vehicle Price", typeof(decimal));
            packageDetailsTable.Columns.Add("Playlist Name", typeof(string));
            packageDetailsTable.Columns.Add("Embalming Days", typeof(int)); 

            try
            {
                foreach (DataGridViewRow row in selectedRows)
                {
                    int serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);

                    
                    string query = @"SELECT PackageName, ISNULL(CasketName, 'None') AS CasketName,
                                                        ISNULL((SELECT Price FROM Casket WHERE Casket.CasketName = ServiceRequests.CasketName), 0) AS CasketPrice,
                                                        ISNULL(VehicleName, 'None') AS VehicleName,
                                                        ISNULL((SELECT Price FROM Vehicle WHERE Vehicle.VehicleName = ServiceRequests.VehicleName), 0) AS VehiclePrice,
                                                        ISNULL(EmbalmingDays, 0) AS EmbalmingDays
                                                    FROM ServiceRequests
                                                    WHERE ServiceRequestID = @ServiceRequestID";

                    using (SqlCommand cmd = new SqlCommand(query, db))
                    {
                        cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                        if (db.State == ConnectionState.Closed)
                            db.Open();

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                DataRow packageRow = packageDetailsTable.NewRow();
                                packageRow["Package Name"] = reader["PackageName"].ToString();
                                packageRow["Casket Name"] = reader["CasketName"].ToString();
                                packageRow["Casket Price"] = Convert.ToDecimal(reader["CasketPrice"]);
                                packageRow["Vehicle Name"] = reader["VehicleName"].ToString();
                                packageRow["Vehicle Price"] = Convert.ToDecimal(reader["VehiclePrice"]);
                                packageRow["Embalming Days"] = Convert.ToInt32(reader["EmbalmingDays"]);

                                packageDetailsTable.Rows.Add(packageRow);
                            }
                        }
                    }
                }

                
                dgv_PackageDetails.DataSource = packageDetailsTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading selected packages: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadSelectedFlowerArrangements()
        {
            if (selectedRows == null || selectedRows.Count == 0)
            {
                MessageBox.Show("No rows selected.");
                dgv_FlowerArrangement.DataSource = null;
                return;
            }

            DataTable flowerArrangementTable = new DataTable();
            flowerArrangementTable.Columns.Add("Flower Arrangement Name", typeof(string));
            flowerArrangementTable.Columns.Add("Quantity", typeof(int));
            flowerArrangementTable.Columns.Add("Price", typeof(decimal));

            try
            {
                foreach (DataGridViewRow row in selectedRows)
                {
                    int serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);

                    // Query to get FlowerArrangement details for the ServiceRequestID
                    string query = @"SELECT FlowerArrangementName, Quantity, PricePerUnit 
                                     FROM ServiceRequestsFlowerArrangements 
                                     WHERE ServiceRequestID = @ServiceRequestID";

                    using (SqlCommand cmd = new SqlCommand(query, db))
                    {
                        cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                        if (db.State == ConnectionState.Closed)
                            db.Open();

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                DataRow flowerRow = flowerArrangementTable.NewRow();
                                flowerRow["Flower Arrangement Name"] = reader["FlowerArrangementName"].ToString();
                                flowerRow["Quantity"] = Convert.ToInt32(reader["Quantity"]);
                                flowerRow["Price"] = Convert.ToDecimal(reader["PricePerUnit"]);

                                flowerArrangementTable.Rows.Add(flowerRow);
                            }
                        }
                    }
                }

                dgv_FlowerArrangement.DataSource = flowerArrangementTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading flower arrangements: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadSelectedChapelDetails()
        {
            if (selectedRows == null || selectedRows.Count == 0)
            {
                MessageBox.Show("No rows selected.");
                dgv_ChapelDetails.DataSource = null;
                return;
            }

            DataTable locationDetailsTable = new DataTable();
            locationDetailsTable.Columns.Add("Chapel Name", typeof(string));
            locationDetailsTable.Columns.Add("Price", typeof(decimal));

            try
            {
                foreach (DataGridViewRow row in selectedRows)
                {
                    int serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);

                    // Query to get Chapel Reservation details for the ServiceRequestID
                    string query = @"SELECT Chapel.ChapelName, Chapel.Price
                                     FROM ChapelReservation
                                     INNER JOIN Chapel ON ChapelReservation.ChapelID = Chapel.ChapelID
                                     WHERE ChapelReservation.ReservationID = (SELECT ReservationID FROM ServiceRequests WHERE ServiceRequestID = @ServiceRequestID)";

                    using (SqlCommand cmd = new SqlCommand(query, db))
                    {
                        cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                        if (db.State == ConnectionState.Closed)
                            db.Open();

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                DataRow locationRow = locationDetailsTable.NewRow();
                                locationRow["Chapel Name"] = reader["ChapelName"].ToString();
                                locationRow["Price"] = Convert.ToDecimal(reader["Price"]);

                                locationDetailsTable.Rows.Add(locationRow);
                            }
                        }
                    }
                }

                dgv_ChapelDetails.DataSource = locationDetailsTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading chapel details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadSelectedEquipment()
        {
            if (selectedRows == null || selectedRows.Count == 0)
            {
                MessageBox.Show("No rows selected.");
                dgv_EquipmentDetails.DataSource = null;
                return;
            }

            DataTable equipmentDetailsTable = new DataTable();
            equipmentDetailsTable.Columns.Add("Equipment Name", typeof(string));
            equipmentDetailsTable.Columns.Add("Equipment Type", typeof(string));
            equipmentDetailsTable.Columns.Add("Equipment Quality", typeof(string));
            equipmentDetailsTable.Columns.Add("Equipment Condition", typeof(string));
            equipmentDetailsTable.Columns.Add("Quantity", typeof(int));
            equipmentDetailsTable.Columns.Add("Damage Note", typeof(string));

            try
            {
                foreach (DataGridViewRow row in selectedRows)
                {
                    int serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);

                    // Query to get equipment details for the ServiceRequestID
                    string query = @"SELECT EquipmentName,
                                            EquipmentType,
                                            EquipmentQuality,
                                            EquipmentCondition,
                                            ISNULL(Quantity, 0) AS Quantity,
                                            ISNULL(DamageNote, '') AS DamageNote
                                        FROM ServiceRequestsPackageEquipments
                                        WHERE ServiceRequestID = @ServiceRequestID";

                    using (SqlCommand cmd = new SqlCommand(query, db))
                    {
                        cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                        if (db.State == ConnectionState.Closed)
                            db.Open();

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                DataRow equipmentRow = equipmentDetailsTable.NewRow();
                                equipmentRow["Equipment Name"] = reader["EquipmentName"].ToString();
                                equipmentRow["Equipment Type"] = reader["EquipmentType"].ToString();
                                equipmentRow["Equipment Quality"] = reader["EquipmentQuality"].ToString();
                                equipmentRow["Equipment Condition"] = reader["EquipmentCondition"].ToString();
                                equipmentRow["Quantity"] = Convert.ToInt32(reader["Quantity"]);
                                equipmentRow["Damage Note"] = reader["DamageNote"].ToString();

                                equipmentDetailsTable.Rows.Add(equipmentRow);
                            }
                        }
                    }
                }

                dgv_EquipmentDetails.DataSource = equipmentDetailsTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
