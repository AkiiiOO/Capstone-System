﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class DamageEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public DamageEquipmentForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadDamageEquipment();
            LoadEquipmentQuality();
        }
        private void LoadEquipmentQuality()
        {
            try
            {
                db.Open();

                // Query to fetch equipment quality
                string query = "SELECT EquipmentQualityID, Quality FROM EquipmentQuality";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Bind data to ComboBox
                cmb_EquipmentQuality.DisplayMember = "Quality"; 
                cmb_EquipmentQuality.ValueMember = "EquipmentQualityID"; 
                cmb_EquipmentQuality.DataSource = dataTable;

                cmb_EquipmentQuality.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment quality: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
        private void LoadDamageEquipment()
        {
            try
            {
                db.Open();

                // Query to fetch damaged equipment data
                string query = @"
                    SELECT de.DamageEquipmentID AS [Damage ID],
                           sr.ServiceRequestID AS [Service Request ID],
                           e.EquipmentName AS [Equipment Name],
                           e.EquipmentType AS [Equipment Type],
                           de.Quantity AS [Damaged Quantity],
                           ds.StatusName AS [Damage Status],
                           de.DamageNote AS [Damage Note],
                           e.EquipmentQualityID,
                           de.EquipmentID
                    FROM DamageEquipment de
                    LEFT JOIN ServiceRequests sr ON de.ServiceRequestID = sr.ServiceRequestID
                    LEFT JOIN Equipment e ON de.EquipmentID = e.EquipmentID
                    LEFT JOIN DamageStatus ds ON de.DamageStatusID = ds.DamageStatusID
                    WHERE de.DamageStatusID IN (1, 2)";


                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                
                
                dgv_DamageEquipment.DataSource = dataTable;

                dgv_DamageEquipment.Columns["Service Request ID"].Visible = false;
                dgv_DamageEquipment.Columns["EquipmentQualityID"].Visible = false;
                dgv_DamageEquipment.Columns["EquipmentID"].Visible = false;
                
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading damaged equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void btn_Dispose_Click(object sender, EventArgs e)
        {
            if (dgv_DamageEquipment.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a damaged equipment to dispose.");
                return;
            }
            if (string.IsNullOrEmpty(txt_DamageNote.Text))
            {
                MessageBox.Show("You must provide a damage note to proceed with disposal.");
                return;
            }

            // Ask for confirmation
            DialogResult confirmation = MessageBox.Show(
                "Are you sure you want to dispose of the selected equipment?",
                "Confirm Disposal",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            // If user selects "No," exit the method
            if (confirmation == DialogResult.No)
            {
                return;
            }

            try
            {
                db.Open();

                foreach (DataGridViewRow row in dgv_DamageEquipment.SelectedRows)
                {
                    int damageEquipmentID = Convert.ToInt32(row.Cells["Damage ID"].Value);

                    // Update DamageStatusID to 4 (Disposed)
                    string updateQuery = @"UPDATE DamageEquipment
                                            SET DamageStatusID = 4, 
                                                DamageNote = @DamageNote
                                            WHERE DamageEquipmentID = @DamageEquipmentID";

                    SqlCommand command = new SqlCommand(updateQuery, db);
                    command.Parameters.AddWithValue("@DamageEquipmentID", damageEquipmentID);
                    command.Parameters.AddWithValue("@DamageNote", txt_DamageNote.Text);
                    command.ExecuteNonQuery();

                }

                MessageBox.Show("Selected equipment has been disposed successfully.");

                // Reload DataGridView to show only pending items
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error disposing damaged equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
                LoadDamageEquipment();
            }
        }

        private void dgv_DamageEquipment_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_DamageEquipment.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dgv_DamageEquipment.SelectedRows[0];

                // Populate the fields based on the selected row
                txt_EquipmentName.Text = selectedRow.Cells["Equipment Name"].Value.ToString();
                txt_EquipmentType.Text = selectedRow.Cells["Equipment Type"].Value.ToString();
                txt_EquipmentQuantity.Text = selectedRow.Cells["Damaged Quantity"].Value.ToString();

                if (selectedRow.Cells["EquipmentQualityID"].Value != null)
                {
                    int qualityID = Convert.ToInt32(selectedRow.Cells["EquipmentQualityID"].Value);
                    cmb_EquipmentQuality.SelectedValue = qualityID;
                }
                else
                {
                    cmb_EquipmentQuality.SelectedIndex = -1; // Clear selection if no value
                }
            }
        }

        private void btn_Repair_Click(object sender, EventArgs e)
        {
            if (dgv_DamageEquipment.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a damaged equipment to repair.");
                return;
            }
            DialogResult confirmation = MessageBox.Show(
           "Are you sure you want to mark the selected equipment as under repair?",
           "Confirm Repair",
           MessageBoxButtons.YesNo,
           MessageBoxIcon.Warning);

            // If user selects "No," exit the method
            if (confirmation == DialogResult.No)
            {
                return;
            }

            try
            {
                db.Open();

                foreach (DataGridViewRow row in dgv_DamageEquipment.SelectedRows)
                {
                    int damageEquipmentID = Convert.ToInt32(row.Cells["Damage ID"].Value);

                    string updateQuery = @"UPDATE DamageEquipment
                                           SET DamageStatusID = 2
                                           WHERE DamageEquipmentID = @DamageEquipmentID";

                    SqlCommand command = new SqlCommand(updateQuery, db);
                    command.Parameters.AddWithValue("@DamageEquipmentID", damageEquipmentID);
                    command.ExecuteNonQuery();
                }

                MessageBox.Show("Selected equipment has been marked as under repair.");

                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error marking equipment as under repair: " + ex.Message);
            }
            finally
            {
                db.Close();
                LoadDamageEquipment();
            }
        }

        private void btn_Reuse_Click(object sender, EventArgs e)
        {
            if (dgv_DamageEquipment.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a damaged equipment to reuse.");
                return;
            }

            // Ensure a damage note is provided
            if (string.IsNullOrEmpty(txt_DamageNote.Text))
            {
                MessageBox.Show("You must provide a damage note to proceed with reuse.");
                return;
            }

            // Ensure quantity is provided
            if (string.IsNullOrEmpty(txt_EquipmentQuantity.Text) || Convert.ToInt32(txt_EquipmentQuantity.Text) <= 0)
            {
                MessageBox.Show("You must provide a valid quantity.");
                return;
            }

            // Ask for confirmation before proceeding
            DialogResult confirmation = MessageBox.Show(
                "Are you sure you want to mark the selected equipment as reused?",
                "Confirm Reuse",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning
            );

            // If user selects "No," exit the method
            if (confirmation == DialogResult.No)
            {
                return;
            }

            try
            {
                db.Open();

                foreach (DataGridViewRow row in dgv_DamageEquipment.SelectedRows)
                {
                    int damageEquipmentID = Convert.ToInt32(row.Cells["Damage ID"].Value);
                    int equipmentID = Convert.ToInt32(row.Cells["EquipmentID"].Value); // You should have EquipmentID in the grid

                    // Update DamageStatusID to 3 (Repaired)
                    string updateDamageStatusQuery = @"
                UPDATE DamageEquipment
                SET DamageStatusID = 3,  -- 3 represents Repaired
                    DamageNote = @DamageNote
                WHERE DamageEquipmentID = @DamageEquipmentID";

                    SqlCommand command = new SqlCommand(updateDamageStatusQuery, db);
                    command.Parameters.AddWithValue("@DamageEquipmentID", damageEquipmentID);
                    command.Parameters.AddWithValue("@DamageNote", txt_DamageNote.Text);
                    command.ExecuteNonQuery();

                    // Insert the reused equipment into the Equipment table
                    string insertEquipmentQuery = @"
                INSERT INTO Equipment (EquipmentQualityID, EquipmentConditionID, EquipmentName, EquipmentType, EquipmentQuality, EquipmentCondition, Quantity, DamageNote)
                VALUES (@EquipmentQualityID, @EquipmentConditionID, @EquipmentName, @EquipmentType, @EquipmentQuality, @EquipmentCondition, @Quantity, @DamageNote)";

                    SqlCommand insertCommand = new SqlCommand(insertEquipmentQuery, db);
                    insertCommand.Parameters.AddWithValue("@EquipmentQualityID", cmb_EquipmentQuality.SelectedValue);
                    insertCommand.Parameters.AddWithValue("@EquipmentConditionID", 3); // Condition ID for "Damaged"
                    insertCommand.Parameters.AddWithValue("@EquipmentName", txt_EquipmentName.Text);
                    insertCommand.Parameters.AddWithValue("@EquipmentType", txt_EquipmentType.Text);
                    insertCommand.Parameters.AddWithValue("@EquipmentQuality", cmb_EquipmentQuality.Text);
                    insertCommand.Parameters.AddWithValue("@EquipmentCondition", "Damaged");
                    insertCommand.Parameters.AddWithValue("@Quantity", Convert.ToInt32(txt_EquipmentQuantity.Text));
                    insertCommand.Parameters.AddWithValue("@DamageNote", txt_DamageNote.Text);
                    insertCommand.ExecuteNonQuery();
                }

                MessageBox.Show("Selected equipment has been marked as reused and added to the inventory.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reusing damaged equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
                LoadDamageEquipment();
            }
        }
    }
}
