﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ReturnEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler ClientAdded;

        private List<DataGridViewRow> selectedRows;
        int serviceRequestID;

        public ReturnEquipmentForm(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            PopulateRelease();
            LoadEmployees();
        }
        private void PopulateRelease()
        {
            if (selectedRows.Count == 1)
            {
                var row = selectedRows[0];
                if (row.Cells["ServiceRequestID"].Value == null)
                {
                    MessageBox.Show("Invalid Service Request ID.");
                    return;
                }

                serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);
                LoadReleasedEquipment();
            }
            else
            {
                MessageBox.Show("Please select only one service request.");
            }
        }
        private void LoadReleasedEquipment()
        {
            try
            {
                if (db == null || db.State != ConnectionState.Open)
                {
                    db.Open();
                }

                // Updated Query to fetch equipment based on the selected ServiceRequestID
                string query = @"
            SELECT 
                er.EquipmentReleaseID,
                e.EquipmentID,
                e.EquipmentName, 
                e.EquipmentType, 
                er.Quantity,
                es.StatusName AS EquipmentStatus, 
                er.ReleaseDate,
                er.ReturnDate,
                (emp1.FirstName + ' ' + emp1.LastName) AS ReleasedByName,
                (emp2.FirstName + ' ' + emp2.LastName) AS ReturnedByName
            FROM EquipmentRelease er
            JOIN Equipment e ON er.EquipmentID = e.EquipmentID
            JOIN EquipmentStatus es ON er.EquipmentStatusID = es.EquipmentStatusID
            LEFT JOIN Employees emp1 ON er.ReleasedBy = emp1.EmployeeID
            LEFT JOIN Employees emp2 ON er.ReturnedBy = emp2.EmployeeID
            WHERE er.ServiceRequestID = @ServiceRequestID";


                SqlCommand cmd = new SqlCommand(query, db);
                cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Bind data to DataGridView
                dgv_EquipmentsReturnDisplay.DataSource = dataTable;

                // Ensure relevant columns are visible and correct
                dgv_EquipmentsReturnDisplay.Columns["SelectColumn"].Visible = true;
                dgv_EquipmentsReturnDisplay.Columns["txt_DamageQuantity"].Visible = true;


                dgv_EquipmentsReturnDisplay.Columns["EquipmentName"].HeaderText = "Equipment Name";
                dgv_EquipmentsReturnDisplay.Columns["EquipmentType"].HeaderText = "Type";
                dgv_EquipmentsReturnDisplay.Columns["Quantity"].HeaderText = "Quantity";
                dgv_EquipmentsReturnDisplay.Columns["EquipmentStatus"].HeaderText = "Status";
                dgv_EquipmentsReturnDisplay.Columns["ReleaseDate"].HeaderText = "Release Date";
                dgv_EquipmentsReturnDisplay.Columns["ReturnDate"].HeaderText = "Return Date";
                dgv_EquipmentsReturnDisplay.Columns["ReleasedByName"].HeaderText = "Released By";
                dgv_EquipmentsReturnDisplay.Columns["ReturnedByName"].HeaderText = "Returned By";

                // Hide unnecessary columns
                dgv_EquipmentsReturnDisplay.Columns["EquipmentReleaseID"].Visible = false;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentID"].Visible = false;

                dgv_EquipmentsReturnDisplay.Columns["SelectColumn"].DisplayIndex = 0;
                dgv_EquipmentsReturnDisplay.Columns["txt_DamageQuantity"].DisplayIndex = 1;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentName"].DisplayIndex = 2;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentType"].DisplayIndex = 3;
                dgv_EquipmentsReturnDisplay.Columns["Quantity"].DisplayIndex = 4;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentStatus"].DisplayIndex = 5;
                dgv_EquipmentsReturnDisplay.Columns["ReleaseDate"].DisplayIndex = 6;
                dgv_EquipmentsReturnDisplay.Columns["ReturnDate"].DisplayIndex = 7;
                dgv_EquipmentsReturnDisplay.Columns["ReleasedByName"].DisplayIndex = 8;
                dgv_EquipmentsReturnDisplay.Columns["ReturnedByName"].DisplayIndex = 9;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment: " + ex.Message);
            }
            finally
            {
                if (db != null && db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
        private void LoadEmployees()
        {
            try
            {
                // Open the database connection
                db.Open();

                // Query to select EmployeeID, FirstName, and LastName from Employees table
                string query = "SELECT EmployeeID, FirstName, LastName FROM Employees";

                SqlCommand cmd = new SqlCommand(query, db);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataTable.Columns.Add("FullName", typeof(string), "FirstName + ' ' + LastName");

                // Bind the data to the ComboBox
                cmb_Employees.DataSource = dataTable;
                cmb_Employees.DisplayMember = "FullName";
                cmb_Employees.ValueMember = "EmployeeID";

                cmb_Employees.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading employees: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void btn_Return_Click(object sender, EventArgs e)
        {
            // Ensure an employee is selected
            if (cmb_Employees.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an employee to process the return.");
                return;
            }

            // Confirm return action
            DialogResult result = MessageBox.Show(
                "Are you sure you want to return the selected equipment?",
                "Confirm Return",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                return;
            }

            int employeeID = Convert.ToInt32(cmb_Employees.SelectedValue);

            try
            {
                db.Open();

                foreach (DataGridViewRow row in dgv_EquipmentsReturnDisplay.Rows)
                {
                    // Ensure the row is selected
                    DataGridViewCheckBoxCell selectCell = row.Cells["SelectColumn"] as DataGridViewCheckBoxCell;
                    if (selectCell != null && Convert.ToBoolean(selectCell.Value))
                    {
                        // Validate required fields
                        if (row.Cells["EquipmentName"].Value == null || row.Cells["Quantity"].Value == null)
                        {
                            MessageBox.Show("Invalid data. Ensure all selected rows have Equipment Name and Quantity.");
                            continue;
                        }

                        string equipmentName = row.Cells["EquipmentName"].Value.ToString();
                        int releasedQuantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                        int damageQuantity = 0;

                        // Retrieve EquipmentID from Equipment table
                        string equipmentQuery = "SELECT EquipmentID FROM Equipment WHERE EquipmentName = @EquipmentName";
                        SqlCommand equipmentCmd = new SqlCommand(equipmentQuery, db);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentName", equipmentName);
                        int equipmentID = Convert.ToInt32(equipmentCmd.ExecuteScalar());

                        // Check if there is a damage quantity
                        if (row.Cells["txt_DamageQuantity"].Value != null &&
                            int.TryParse(row.Cells["txt_DamageQuantity"].Value.ToString(), out damageQuantity) &&
                            damageQuantity > 0)
                        {
                            if (damageQuantity > releasedQuantity)
                            {
                                MessageBox.Show("Damage quantity cannot exceed the released quantity.");
                                continue;
                            }

                            // Insert damaged equipment into the DamageEquipment table one by one
                            for (int i = 0; i < damageQuantity; i++)
                            {
                                string insertDamageQuery = @"
                            INSERT INTO DamageEquipment (ServiceRequestID, EquipmentStatusID, DamageStatusID, EquipmentID, Quantity)
                            VALUES (@ServiceRequestID, @EquipmentStatusID, @DamageStatusID, @EquipmentID, @Quantity)";
                                SqlCommand insertDamageCmd = new SqlCommand(insertDamageQuery, db);
                                insertDamageCmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                                insertDamageCmd.Parameters.AddWithValue("@EquipmentStatusID", 5); // Assuming "5" means damaged
                                insertDamageCmd.Parameters.AddWithValue("@DamageStatusID", 1);  // Assuming "1" means newly damaged
                                insertDamageCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                                insertDamageCmd.Parameters.AddWithValue("@Quantity", 1); // Insert each damaged item one by one
                                insertDamageCmd.ExecuteNonQuery();
                            }

                            // Reduce the returned quantity by the total damage quantity
                            releasedQuantity -= damageQuantity;
                        }

                        // Return the undamaged quantity to the Equipment table
                        if (releasedQuantity > 0)
                        {
                            string updateReturnQuery = @"
                        UPDATE Equipment
                        SET Quantity = Quantity + @ReturnedQuantity
                        WHERE EquipmentID = @EquipmentID";
                            SqlCommand updateReturnCmd = new SqlCommand(updateReturnQuery, db);
                            updateReturnCmd.Parameters.AddWithValue("@ReturnedQuantity", releasedQuantity);
                            updateReturnCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                            updateReturnCmd.ExecuteNonQuery();
                        }

                        // Update the EquipmentRelease table to mark as returned
                        string updateReleaseQuery = @"
                    UPDATE EquipmentRelease
                    SET EquipmentStatusID = 4, -- Returned status
                        ReturnDate = GETDATE(),
                        ReturnedBy = @ReturnedBy
                    WHERE EquipmentID = @EquipmentID AND ServiceRequestID = @ServiceRequestID";
                        SqlCommand updateReleaseCmd = new SqlCommand(updateReleaseQuery, db);
                        updateReleaseCmd.Parameters.AddWithValue("@ReturnedBy", employeeID);
                        updateReleaseCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                        updateReleaseCmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                        updateReleaseCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Equipment return process completed successfully.");
                ClientAdded.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error processing equipment return: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
