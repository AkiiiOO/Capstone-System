﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ServiceRequest : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public ServiceRequest()
        {
            InitializeComponent();
            db = y.GetConnection();
            customizeDesign();
            LoadServiceRequests();
            showSubMenu(panelServiceSubMenu);
            btn_ServiceRequest.BackColor = Color.LightSkyBlue;
            UserAccessLevel();
        }
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
            panelTransactionSubMenu.Visible = false;
            panelInventorySubMenu.Visible = false;
            panelReportsSubMenu.Visible = false;
            panelSettingsSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            //user
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            //service
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
            //transaction
            if (panelTransactionSubMenu.Visible == true)
                panelTransactionSubMenu.Visible = false;
            //inventory
            if (panelInventorySubMenu.Visible == true)
                panelInventorySubMenu.Visible = false;
            //reports
            if (panelReportsSubMenu.Visible == true)
                panelReportsSubMenu.Visible = false;
            //setting
            if (panelSettingsSubMenu.Visible == true)
                panelSettingsSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        //Home Nav
        private void btn_Home_Click(object sender, EventArgs e)
        {
            Home form2 = new Home();
            form2.Show();
            this.Hide();
        }

        //UserSubMenu
        private void btn_User_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            UsersLog form1 = new UsersLog();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            ServiceRequest form3 = new ServiceRequest();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }


        //TransactionSubMenu
        private void btn_Transaction_Click(object sender, EventArgs e)
        {
            showSubMenu(panelTransactionSubMenu);
        }
        //TheSubMenus
        private void btn_Payment_Click(object sender, EventArgs e)
        {
            Payment form3 = new Payment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_InstallmentPayment_Click_1(object sender, EventArgs e)
        {
            InstallmentPayment form3 = new InstallmentPayment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //InventorySubMenus
        private void btn_Inventory_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelInventorySubMenu);
        }
        private void btn_Release_Click(object sender, EventArgs e)
        {
            ReleaseEquipment form3 = new ReleaseEquipment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ReturnEquipment_Click(object sender, EventArgs e)
        {
            ReturnEquipment form3 = new ReturnEquipment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //ReportsSubMenus
        private void btn_Reports_Click(object sender, EventArgs e)
        {
            showSubMenu(panelReportsSubMenu);
        }
        private void btn_ServiceHistory_Click(object sender, EventArgs e)
        {
            ServiceHistory form3 = new ServiceHistory();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_EquipmentReleaseLog_Click(object sender, EventArgs e)
        {
            EquipmentReleaseLogReport form3 = new EquipmentReleaseLogReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Inventory_Click(object sender, EventArgs e)
        {
            InventoryMasterListReport form3 = new InventoryMasterListReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Sales_Click(object sender, EventArgs e)
        {
            SalesReport form3 = new SalesReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }


        //SettingsSubMenus
        private void btn_Settings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSettingsSubMenu);
        }

        private void btn_AccountDetails_Click(object sender, EventArgs e)
        {
            AccountDetails form3 = new AccountDetails();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_AddEquipment_Click(object sender, EventArgs e)
        {
            AddEquipment form3 = new AddEquipment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_EmployeeList_Click(object sender, EventArgs e)
        {
            EmployeeList form3 = new EmployeeList();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Package_Click(object sender, EventArgs e)
        {
            CreatePackage form2 = new CreatePackage();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ServiceFileMaintenance_Click(object sender, EventArgs e)
        {
            ServiceMaintenance form2 = new ServiceMaintenance();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_TransactionMaintenance_Click(object sender, EventArgs e)
        {
            TransactionMaintenance form3 = new TransactionMaintenance();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }



        private void AddClientForm_ClientAdded(object sender, EventArgs e)
        {
            LoadServiceRequests();
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            CreateNewServiceRequestForm form3 = new CreateNewServiceRequestForm();
            form3.ClientAdded += AddClientForm_ClientAdded;
            form3.ShowDialog();
        }


        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks Yes log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LogUserLogout();
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
        private void LogUserLogout()
        {
            try
            {
                if (CurrentUser.LogID > 0)
                {
                    string logoutQuery = "UPDATE UserLog SET LogoutDateTime = GETDATE() WHERE LogID = @LogID";
                    SqlCommand logoutCommand = new SqlCommand(logoutQuery, db);
                    logoutCommand.Parameters.AddWithValue("@LogID", CurrentUser.LogID);

                    y.Open();
                    logoutCommand.ExecuteNonQuery();
                    y.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while logging out: " + ex.Message);
            }
        }
        private void UserAccessLevel()
        {
            int userID = CurrentUser.UserID;

            //what buttons admin can access
            if (CurrentUser.AccessLevel == "1")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = true;
                btn_AddUser.Visible = true;
                btn_UserLog.Visible = true;
                //service
                btn_Service.Visible = true;
                btn_AddClient.Visible = true;
                btn_ServiceRequest.Visible = true;
                btn_Package.Visible = true;
                btn_ServiceFileMaintenance.Visible = true;
                //transaction
                btn_Transaction.Visible = true;
                btn_Payment.Visible = true;
                btn_InstallmentPayment.Visible = true;
                btn_TransactionMaintenance.Visible = true;
                //Inventory
                btn_Inventory.Visible = true;
                btn_AddEquipment.Visible = true;
                btn_Release.Visible = true;
                btn_ReturnEquipment.Visible = true;
                //report
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = true;
                btn_EquipmentReleaseLog.Visible = true;
                btn_InventoryMasterList.Visible = true;
                btn_Sales.Visible = true;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = true;
                btn_AccountDetails.Visible = true;
            }
            //what buttons Service Staff can access
            else if (CurrentUser.AccessLevel == "2")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = false;
                btn_AddUser.Visible = false;
                btn_UserLog.Visible = false;
                //service
                btn_Service.Visible = true;
                btn_AddClient.Visible = true;
                btn_ServiceRequest.Visible = true;
                btn_Package.Visible = true;
                btn_ServiceFileMaintenance.Visible = true;
                //transaction
                btn_Transaction.Visible = true;
                btn_Payment.Visible = true;
                btn_InstallmentPayment.Visible = true;
                btn_TransactionMaintenance.Visible = true;
                //Inventory
                btn_Inventory.Visible = false;
                btn_AddEquipment.Visible = false;
                btn_Release.Visible = false;
                btn_ReturnEquipment.Visible = false;
                //report
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = true;
                btn_EquipmentReleaseLog.Visible = false;
                btn_Inventory.Visible = false;
                btn_Sales.Visible = true;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = false;
                btn_AccountDetails.Visible = true;
            }
            //what buttons Inventory Staff can access
            else if (CurrentUser.AccessLevel == "3")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = false;
                btn_AddUser.Visible = false;
                btn_UserLog.Visible = false;
                //service 
                btn_Service.Visible = false;
                btn_AddClient.Visible = false;
                btn_ServiceRequest.Visible = false;
                btn_Package.Visible = false;
                btn_ServiceFileMaintenance.Visible = false;
                //transaction
                btn_Transaction.Visible = false;
                btn_Payment.Visible = false;
                btn_InstallmentPayment.Visible = false;
                btn_TransactionMaintenance.Visible = false;
                //Inventory
                btn_Inventory.Visible = true;
                btn_AddEquipment.Visible = true;
                btn_Release.Visible = true;
                btn_ReturnEquipment.Visible = true;
                //report module
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = false;
                btn_EquipmentReleaseLog.Visible = true;
                btn_Inventory.Visible = true;
                btn_Sales.Visible = false;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = false;
                btn_AccountDetails.Visible = true;
            }
        }
        private void LoadServiceRequests()
        {
            string query = @"SELECT sr.ServiceRequestID, sr.ClientName,   sr.DeceasedFName, 
                            sr.DeceasedMName, 
                            sr.DeceasedLName, 
                            sr.DeceasedFName + ' ' + 
                            CASE 
                                WHEN sr.DeceasedMName IS NOT NULL AND sr.DeceasedMName <> '' 
                                THEN sr.DeceasedMName + ' ' 
                                ELSE '' 
                            END + sr.DeceasedLName AS DeceasedFullName, 
                            sr.PackageName, sr.CemeteryLocation, sr.DateBurial,sr.TimeBurial,sr.TotalPrice, 
                            ss.StatusName AS ServiceStatus, cr.ReservationID
                     FROM ServiceRequests sr
                     LEFT JOIN ChapelReservation cr ON sr.ReservationID = cr.ReservationID
                     JOIN ServiceStatus ss ON sr.ServiceStatusID = ss.ServiceStatusID
                     WHERE sr.ServiceStatusID IN (1, 2)";


            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                // Assuming db is your SqlConnection object
                DataTable dt = new DataTable();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                try
                {
                    db.Open();
                    adapter.Fill(dt);
                    dgv_ServiceRequestRecords.DataSource = dt; // Bind to DataGridView
                    dgv_ServiceRequestRecords.Columns["ReservationID"].Visible = false;
                    dgv_ServiceRequestRecords.Columns["DeceasedFName"].Visible = false;
                    dgv_ServiceRequestRecords.Columns["DeceasedMName"].Visible = false;
                    dgv_ServiceRequestRecords.Columns["DeceasedLName"].Visible = false;
                    dgv_ServiceRequestRecords.Columns["Complete_Service"].Visible = true;
                    SetButtonColumnColor();

                    // Set column headers
                    dgv_ServiceRequestRecords.Columns["ServiceRequestID"].HeaderText = "Request ID";
                    dgv_ServiceRequestRecords.Columns["ClientName"].HeaderText = "Client";
                    dgv_ServiceRequestRecords.Columns["DeceasedFullName"].HeaderText = "Deceased Name";
                    dgv_ServiceRequestRecords.Columns["PackageName"].HeaderText = "Package";
                    dgv_ServiceRequestRecords.Columns["ServiceStatus"].HeaderText = "Status";
                    dgv_ServiceRequestRecords.Columns["TotalPrice"].HeaderText = "Total Price";
                    dgv_ServiceRequestRecords.Columns["DateBurial"].HeaderText = "Burial Date";
                    dgv_ServiceRequestRecords.Columns["TimeBurial"].HeaderText = "Burial Time";
                    dgv_ServiceRequestRecords.Columns["CemeteryLocation"].HeaderText = "Cemetery Location";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading service requests: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }
        }
        private void SetButtonColumnColor()
        {
            dgv_ServiceRequestRecords.Columns["Complete_Service"].DefaultCellStyle.BackColor = Color.RoyalBlue; // Change to your desired color
            dgv_ServiceRequestRecords.Columns["Complete_Service"].DefaultCellStyle.ForeColor = Color.White; 
        }
        private void dgv_ServiceRequestRecords_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgv_ServiceRequestRecords.Columns["Complete_Service"].Index && e.RowIndex >= 0)
            {
                btnComplete_Click(sender, e);
            }
        }
        private void btnComplete_Click(object sender, EventArgs e)
        {
            if (dgv_ServiceRequestRecords.SelectedRows.Count > 0)
            {
                var selectedServiceRequestRow = dgv_ServiceRequestRecords.SelectedRows[0];
                int serviceRequestID = Convert.ToInt32(selectedServiceRequestRow.Cells["ServiceRequestID"].Value);

                // Check if a ChapelReservation exists (ReservationID could be null or empty)
                int reservationID = dgv_ServiceRequestRecords.SelectedRows[0].Cells["ReservationID"].Value != DBNull.Value
                                    ? Convert.ToInt32(selectedServiceRequestRow.Cells["ReservationID"].Value)
                                    : 0; // Set reservationID to 0 if no reservation
                int serviceRequestStatusID = 0;
                int reservationStatusID = 0;

                string statusQuery = @"
            SELECT 
                (SELECT ServiceStatusID FROM ServiceRequests WHERE ServiceRequestID = @ServiceRequestID) AS ServiceRequestStatusID,
                (SELECT ReservationStatusID FROM ChapelReservation WHERE ReservationID = @ReservationID) AS ReservationStatusID";

                using (SqlCommand cmd = new SqlCommand(statusQuery, db))
                {
                    cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                    cmd.Parameters.AddWithValue("@ReservationID", reservationID);

                    try
                    {
                        db.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                serviceRequestStatusID = reader["ServiceRequestStatusID"] != DBNull.Value ? Convert.ToInt32(reader["ServiceRequestStatusID"]) : 0;
                                reservationStatusID = reader["ReservationStatusID"] != DBNull.Value ? Convert.ToInt32(reader["ReservationStatusID"]) : 0;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching statuses: " + ex.Message);
                        return; // Exit early if there's an error
                    }
                    finally
                    {
                        db.Close();
                    }
                }
                if (serviceRequestStatusID == 1 || reservationStatusID == 1) // Assuming 1 = Pending
                {
                    MessageBox.Show("Cannot complete the service request or reservation while still in a pending state.");
                    return;
                }

                // Confirmation dialog
                DialogResult dialogResult = MessageBox.Show("Are you sure you want to mark both the service request and reservation as complete?", "Confirm Completion", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    // Mark service request as complete
                    using (SqlCommand cmd = new SqlCommand("UPDATE ServiceRequests SET ServiceStatusID = @ServiceStatusID WHERE ServiceRequestID = @ServiceRequestID", db))
                    {
                        cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);
                        cmd.Parameters.AddWithValue("@ServiceStatusID", 3); // 3 means 'completed'

                        try
                        {
                            db.Open();
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Service request marked as complete.");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error completing service request: " + ex.Message);
                        }
                        finally
                        {
                            db.Close();
                        }
                    }

                    // If ReservationID is not 0, update ChapelReservation
                    if (reservationID > 0)
                    {
                        using (SqlCommand cmd2 = new SqlCommand("UPDATE ChapelReservation SET ReservationStatusID = @ReservationStatusID WHERE ReservationID = @ReservationID", db))
                        {
                            cmd2.Parameters.AddWithValue("@ReservationID", reservationID);
                            cmd2.Parameters.AddWithValue("@ReservationStatusID", 4); // 4 means 'completed'

                            try
                            {
                                db.Open();
                                cmd2.ExecuteNonQuery();
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error completing chapel reservation: " + ex.Message);
                            }
                            finally
                            {
                                db.Close();
                            }
                        }
                    }

                    // Refresh the service request data
                    LoadServiceRequests();
                }
            }
            else
            {
                MessageBox.Show("Please select both a service request and a chapel reservation to complete.");
            }
        }
        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtsearch.Text.Trim();

            // If the search text is empty, reload the pending and ongoing service requests
            if (string.IsNullOrEmpty(searchText))
            {
                LoadServiceRequests();
                return;
            }

            // SQL query to search service requests
            string query = @"SELECT sr.ServiceRequestID, sr.ClientName, 
                            sr.DeceasedFName + ' ' + 
                            CASE 
                                WHEN sr.DeceasedMName IS NOT NULL AND sr.DeceasedMName <> '' 
                                THEN sr.DeceasedMName + ' ' 
                                ELSE '' 
                            END + sr.DeceasedLName AS DeceasedFullName, 
                            sr.PackageName, sr.TotalPrice, 
                            ss.StatusName AS ServiceStatus
                     FROM ServiceRequests sr
                     JOIN ServiceStatus ss ON sr.ServiceStatusID = ss.ServiceStatusID
                     WHERE sr.ServiceStatusID IN (1, 2) AND 
                           (sr.ClientName LIKE @SearchText OR 
                            sr.DeceasedFName + ' ' + 
                            CASE 
                                WHEN sr.DeceasedMName IS NOT NULL AND sr.DeceasedMName <> '' 
                                THEN sr.DeceasedMName + ' ' 
                                ELSE '' 
                            END + sr.DeceasedLName LIKE @SearchText OR
                            CAST(sr.ServiceRequestID AS NVARCHAR) LIKE @SearchText)";


            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                // Add search text parameter
                cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();

                try
                {
                    db.Open();
                    adapter.Fill(dataTable);

                    // Bind results to DataGridView or handle empty results
                    if (dataTable.Rows.Count > 0)
                    {
                        dgv_ServiceRequestRecords.DataSource = dataTable;
                    }
                    else
                    {
                        MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dgv_ServiceRequestRecords.DataSource = null; // Clear the DataGridView if no records found
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }

        private void dgv_ServiceRequestRecords_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_EditServiceRequest_Click(object sender, EventArgs e)
        {
          
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_ServiceRequestRecords.SelectedRows.Count > 0) // Ensure a row is selected
            {
                // Get data from the selected row
                DataGridViewRow selectedRow = dgv_ServiceRequestRecords.SelectedRows[0];
                string serviceIDToDelete = selectedRow.Cells["ServiceRequestID"].Value.ToString(); // Use ClientID as the key

                // Confirm delete
                DialogResult deleteresult = MessageBox.Show("Are you sure you want to delete this record?",
                                                            "Confirm Delete",
                                                            MessageBoxButtons.YesNo,
                                                            MessageBoxIcon.Warning);

                if (deleteresult == DialogResult.Yes)
                {
                    try
                    {
                        db.Open();

                        string queryDeleteUser = @"DELETE FROM ServiceRequests WHERE ServiceRequestID = @ServiceRequestID";
                        using (SqlCommand commandUser = new SqlCommand(queryDeleteUser, db))
                        {
                            commandUser.Parameters.AddWithValue("@ServiceRequestID", serviceIDToDelete);

                            int result = commandUser.ExecuteNonQuery();
                            if (result > 0)
                            {
                                MessageBox.Show("Record deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                dgv_ServiceRequestRecords.Rows.Remove(selectedRow); // Remove row from DataGridView
                            }
                            else
                            {
                                MessageBox.Show("Record not found or deletion failed.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while deleting the record: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        if (db.State == ConnectionState.Open)
                        {
                            db.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a record to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (dgv_ServiceRequestRecords.SelectedRows.Count > 0) // Ensure a row is selected
            {

                DataGridViewRow selectedRow = dgv_ServiceRequestRecords.SelectedRows[0];

                string serviceRequestID = selectedRow.Cells["ServiceRequestID"].Value.ToString();
                string clientName = selectedRow.Cells["ClientName"].Value.ToString();
                string deceasedFName = selectedRow.Cells["DeceasedFName"].Value.ToString();
                string deceasedMName = selectedRow.Cells["DeceasedMName"].Value != DBNull.Value ? selectedRow.Cells["DeceasedMName"].Value.ToString() : string.Empty; // Handle optional MName
                string deceasedLName = selectedRow.Cells["DeceasedLName"].Value.ToString();
                string packageName = selectedRow.Cells["PackageName"].Value.ToString();
                string totalPrice = selectedRow.Cells["TotalPrice"].Value.ToString();
                string statusName = selectedRow.Cells["ServiceStatus"].Value.ToString();
                string burialDate = selectedRow.Cells["DateBurial"].Value.ToString();
                string timeBurial = selectedRow.Cells["TimeBurial"].Value.ToString();
                string cemeteryLocation = selectedRow.Cells["CemeteryLocation"].Value.ToString();



                EditServiceRequest editForm = new EditServiceRequest
                {
                    ServiceRequestID = serviceRequestID,
                    ClientName = clientName,
                    DeceasedFName = deceasedFName,
                    DeceasedMName = deceasedMName,
                    DeceasedLName = deceasedLName,
                    PackageName = packageName,
                    TotalPrice = totalPrice,
                    StatusName = statusName,
                    DateBurial = burialDate,
                    TimeBurial = timeBurial,
                    CemeteryLocation = cemeteryLocation
                };
                editForm.ServiceRequestUpdated += AddClientForm_ClientAdded;

                // editForm.ServiceRequestUpdated += (s, args) => LoadServiceRequests();

                editForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a client to edit.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
