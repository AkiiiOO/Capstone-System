﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ViewSales : Form
    {
        public string PaymentID { get; set; }
        public string ClientName { get; set; }
        public string Subtotal { get; set; }
        public string DiscountApplied { get; set; }
        public string DiscountAmount { get; set; }
        public string FinalPrice { get; set; }
        public string PaymentOption { get; set; }
        public string RemainingBalance { get; set; }
        public string PaymentStatus { get; set; }

        public ViewSales()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_PaymentID.Text = PaymentID;
            lbl_ClientName.Text = ClientName;
            lbl_Subtotal.Text = Subtotal;
            lbl_DiscountApplied.Text = DiscountApplied;
            lbl_DiscountAmount.Text = DiscountAmount;
            lbl_FinalPrice.Text = FinalPrice;
            lbl_PaymentOption.Text = PaymentOption;
            lbl_RemainingBalance.Text = RemainingBalance;
            lbl_PaymentStatus.Text = PaymentStatus;
            
        }

        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_ViewSalesHistory = pnl;
            getprintarea(pnl_ViewSalesHistory);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();


        }

        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }


        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_ViewSalesHistory);
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_ViewSalesHistory.Width / 2), this.pnl_ViewSalesHistory.Location.Y);
        }
    }
}
