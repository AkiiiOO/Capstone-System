﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ForgotUsername : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public ForgotUsername()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btn_Verify_Click(object sender, EventArgs e)
        {
            string contactNumber = txt_PhoneNumber.Text.Trim();

            if (string.IsNullOrEmpty(contactNumber))
            {
                MessageBox.Show("Please enter your contact number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string query = "SELECT Username FROM Users WHERE Contact_No = @Contact_No";

            try
            {
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@Contact_No", contactNumber);

                    db.Open();
                    object result = command.ExecuteScalar();

                    if (result != null)
                    {
                        // Display the username
                        MessageBox.Show("Success");
                        lbl_Username.Text = result.ToString();
                    }
                    else
                    {
                        MessageBox.Show("The contact number is not registered. Please try again.", "Invalid Contact Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txt_PhoneNumber.Focus();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while verifying your contact number: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
