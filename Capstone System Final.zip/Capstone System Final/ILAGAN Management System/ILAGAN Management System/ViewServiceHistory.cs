﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ViewServiceHistory : Form
    {

        public string ClientName { get; set; }
        public string DeceasedFullName { get; set; }
        public string DeceasedFName { get; set; }
        public string DeceasedMName { get; set; }
        public string DeceasedLName { get; set; }
        public string PackageName { get; set; }
        public string CasketName { get; set; }
        public string VehicleName { get; set; }
        public string PlaylistName { get; set; }
        public string CemeteryLocation { get; set; }
        public string DateBurial { get; set; }
        public string TimeBurial { get; set; }
        public string TotalPrice { get; set; }
        public string ServiceStatus { get; set; }

        

        public ViewServiceHistory()
        {
            InitializeComponent();
        }

        private void ViewServiceHistory_Load(object sender, EventArgs e)
        {

        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_CName.Text = ClientName;
            lbl_DFName.Text = DeceasedFName;
            lbl_DMName.Text = DeceasedMName;
            lbl_DLName.Text = DeceasedLName;
            lbl_CemeteryLocation.Text = CemeteryLocation;
            lbl_DateBurial.Text = DateBurial;
            lbl_TimeBurial.Text = TimeBurial;
            lbl_TotalPrice.Text = TotalPrice;
            lbl_ServiceStatus.Text = ServiceStatus;
            lbl_PackageName.Text = PackageName;
            lbl_CasketName.Text = CasketName;
            lbl_VehicleName.Text = VehicleName;

        }

        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_ViewServiceHistory = pnl;
            getprintarea(pnl_ViewServiceHistory);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();


        }

        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_ViewServiceHistory.Width / 2), this.pnl_ViewServiceHistory.Location.Y);
        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_ViewServiceHistory);
        }
    }
}
