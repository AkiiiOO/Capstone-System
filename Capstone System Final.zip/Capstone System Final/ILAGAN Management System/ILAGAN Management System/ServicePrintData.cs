﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ILAGAN_Management_System
{
    partial class ServicePrintData
    {
    }
}
