﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewPackageForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler ClientAdded;

        //casket
        public int SelectedCasketID { get; set; }
        private decimal casketPrice = 0.0M;
        //Vehicle
        public int SelectedVehicleID { get; set; }
        private decimal vehiclePrice = 0.0M;
        //Flower Arrangment
        public List<SelectFlowerArrangement.Flower> SelectedFlowers { get; set; } 
        public int SelectedFlowerID { get; set; }
        private string flowerName;
        private int flowerQuantity;
        private decimal flowerPrice = 0.0M;
        //Equipments
        public int equipmentID { get; set; }
        string equipmentName;
        int equipmentQuantity;
        int equipmentQualityID;
        int equipmentConditionID;
        string damageNote;

        // Embalming Prices
        private decimal baseEmbalmingPrice = 0.0M;
        private decimal additionalDayCharge = 0.0M;
        private int includedDays = 0;

        public AddNewPackageForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadEmbalmingPrices();
            InitializeDataGridView();
        }
        private void InitializeDataGridView()
        {
            // Check if columns are already added to prevent adding duplicates
            if (dgv_FlowerArrangement.Columns.Count == 0)
            {
                dgv_FlowerArrangement.Columns.Add("FlowerID", "Flower ID");
                dgv_FlowerArrangement.Columns.Add("FlowerName", "Flower");
                dgv_FlowerArrangement.Columns.Add("FlowerPrice", "Price");
                dgv_FlowerArrangement.Columns.Add("Quantity", "Quantity");
            }
            if (dgv_Equipments.Columns.Count == 0)
            {
                dgv_Equipments.Columns.Add("EquipmentName", "Equipment Name");
                dgv_Equipments.Columns.Add("EquipmentType", "Equipment Type");
                dgv_Equipments.Columns.Add("EquipmentQuality", "Quality");
                dgv_Equipments.Columns.Add("EquipmentCondition", "Condition");
                dgv_Equipments.Columns.Add("Quantity", "Quantity");
                dgv_Equipments.Columns.Add("DamageNote", "Damage Note");
            }
        }
        private void LoadEmbalmingPrices()
        {
            string query = "SELECT IncludedDays, BasePrice, AdditionalDayCharge FROM EmbalmingPrice";

            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    includedDays = reader.GetInt32(0);
                    baseEmbalmingPrice = reader.GetDecimal(1);
                    additionalDayCharge = reader.GetDecimal(2);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading embalming prices: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                SelectedCasketID = selectCasketForm.SelectedCasketID;

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                SelectedVehicleID = selectVehicleForm.SelectedVehicleID;

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                var selectedFlowers = selectFlowerForm.SelectedFlowers;
                dgv_FlowerArrangement.Rows.Clear();

                foreach (var flower in selectedFlowers)
                {
                    dgv_FlowerArrangement.Rows.Add(flower.FlowerID, flower.FlowerName, flower.FlowerPrice.ToString("F2"), flower.Quantity);

                    flowerPrice += flower.FlowerPrice * flower.Quantity;
                    SelectedFlowerID = flower.FlowerID;
                    flowerName = flower.FlowerName;
                    flowerQuantity = flower.Quantity;
                }

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectEquipment_Click(object sender, EventArgs e)
        {
            SelectEquipments selectEquipmentForm = new SelectEquipments();
            if (selectEquipmentForm.ShowDialog() == DialogResult.OK)
            {
                var selectedEquipments = selectEquipmentForm.SelectedEquipments;
                dgv_Equipments.Rows.Clear();

                foreach (var equipment in selectedEquipments)
                {
                    dgv_Equipments.Rows.Add(equipment.EquipmentName, equipment.EquipmentType,
                                            equipment.EquipmentQuality,
                                            equipment.EquipmentCondition, equipment.Quantity,
                                            equipment.DamageNote);

                    equipmentID = equipment.EquipmentID;
                    equipmentName = equipment.EquipmentName;
                    equipmentQuantity = equipment.Quantity;
                    equipmentQualityID = equipment.EquipmentQualityID;
                    equipmentConditionID = equipment.EquipmentConditionID;
                    damageNote = equipment.DamageNote;
                }
            }
        }
        private void btn_ClearCasket_Click(object sender, EventArgs e)
        {
            // Clear the casket text field
            txt_Casket.Text = string.Empty;

            // Reset the selected casket ID and price
            SelectedCasketID = 0;
            casketPrice = 0.0M;
            UpdateEmbalmingPrice();
        }
        private void btn_ClearVehicle_Click(object sender, EventArgs e)
        {
            // Clear the vehicle text field
            txt_Vehicle.Text = string.Empty;

            // Reset the selected vehicle ID and price
            SelectedVehicleID = 0;
            vehiclePrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearArrangement_Click(object sender, EventArgs e)
        {
            if (dgv_FlowerArrangement.Rows.Count > 0)
            {
                dgv_FlowerArrangement.Rows.RemoveAt(0);

                if (dgv_FlowerArrangement.Rows.Count > 0)
                {
                    flowerPrice = 0.0M;
                    SelectedFlowerID = 0;
                    flowerName = string.Empty;
                    flowerQuantity = 0;

                    foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                    {
                        flowerPrice += Convert.ToDecimal(row.Cells[2].Value) * Convert.ToInt32(row.Cells[3].Value);
                    }
                }
                else
                {
                    flowerPrice = 0.0M;
                    SelectedFlowerID = 0;
                    flowerName = string.Empty;
                    flowerQuantity = 0;
                }
                UpdateEmbalmingPrice();
            }
        }
        private void btn_ClearEquipment_Click(object sender, EventArgs e)
        {
            if (dgv_Equipments.Rows.Count > 0)
            {
                dgv_Equipments.Rows.RemoveAt(0);

                if (dgv_Equipments.Rows.Count > 0)
                {
                    equipmentID = 0;
                    equipmentName = string.Empty;
                    equipmentQuantity = 0;
                }
                else
                {
                    equipmentID = 0;
                    equipmentName = string.Empty;
                    equipmentQuantity = 0;
                }
            }
        }
        private void txt_EmbalmingDays_TextChanged(object sender, EventArgs e)
        {
            UpdateEmbalmingPrice();
        }
        private void UpdateEmbalmingPrice()
        {
            if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
            {
                lbl_VehiclePrice.Text = vehiclePrice.ToString("F2");
                lbl_CasketPrice.Text = casketPrice.ToString("F2");
                lbl_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice).ToString("F2");
                return; // Exit the method early
            }
            int embalmingDays = 0;
            if (int.TryParse(txt_EmbalmingDays.Text, out embalmingDays))
            {
                decimal embalmingPrice = 0;
                if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
                {
                    // Input is empty, so use the base embalming price
                    embalmingPrice = baseEmbalmingPrice;
                }
                if (embalmingDays > 0)
                {
                    // Start with the base embalming price
                    embalmingPrice = baseEmbalmingPrice;

                    if (embalmingDays > includedDays)
                    {
                        // Calculate additional charges if days exceed the included days
                        int additionalDays = embalmingDays - includedDays;
                        embalmingPrice += additionalDays * additionalDayCharge;
                    }
                }

                // Calculate the total price with or without embalming
                decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + embalmingPrice;

                lbl_VehiclePrice.Text = vehiclePrice.ToString("F2");
                lbl_CasketPrice.Text = casketPrice.ToString("F2");
                lbl_PackagePrice.Text = totalPrice.ToString("F2");
            }
            else
            {
                lbl_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice + baseEmbalmingPrice).ToString("F2");
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_PackageName.Text))
            {
                MessageBox.Show("Please enter a package name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                db.Open();

                // Insert into Package table
                string insertPackageQuery = @"INSERT INTO Package 
                               (CasketID, VehicleID, PackageName, 
                               CasketName, VehicleName, EmbalmingDays, TotalPrice) 
                               OUTPUT INSERTED.PackageID
                               VALUES 
                               (@CasketID, @VehicleID, @PackageName, 
                               @CasketName, @VehicleName, @EmbalmingDays, @TotalPrice)";
                SqlCommand packageCmd = new SqlCommand(insertPackageQuery, db);

                // Add parameters including PackageName
                packageCmd.Parameters.AddWithValue("@PackageName", txt_PackageName.Text.Trim());
                packageCmd.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                packageCmd.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                packageCmd.Parameters.AddWithValue("@CasketName", txt_Casket.Text.Trim());
                packageCmd.Parameters.AddWithValue("@VehicleName", txt_Vehicle.Text.Trim());
                packageCmd.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? (object)DBNull.Value : int.Parse(txt_EmbalmingDays.Text));
                packageCmd.Parameters.AddWithValue("@TotalPrice", decimal.Parse(lbl_PackagePrice.Text));

                int packageID = (int)packageCmd.ExecuteScalar();

                // Insert into PackageFlowerArrangements table
                foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        string insertFlowerQuery = @"INSERT INTO PackageFlowerArrangements 
                                             (PackageID, ArrangementID, FlowerArrangementName, Quantity, PricePerUnit) 
                                             VALUES 
                                             (@PackageID, @ArrangementID, @FlowerArrangementName, @Quantity, @PricePerUnit)";
                        SqlCommand flowerCmd = new SqlCommand(insertFlowerQuery, db);
                        flowerCmd.Parameters.AddWithValue("@PackageID", packageID);
                        flowerCmd.Parameters.AddWithValue("@ArrangementID", row.Cells["FlowerID"].Value);
                        flowerCmd.Parameters.AddWithValue("@FlowerArrangementName", row.Cells["FlowerName"].Value);
                        flowerCmd.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                        flowerCmd.Parameters.AddWithValue("@PricePerUnit", row.Cells["FlowerPrice"].Value);
                        flowerCmd.ExecuteNonQuery();
                    }
                }

                // Insert into PackageEquipments table
                foreach (DataGridViewRow row in dgv_Equipments.Rows)
                {
                    if (!row.IsNewRow)
                    {
                        string insertEquipmentQuery = @"INSERT INTO PackageEquipments 
                     (PackageID, EquipmentID, EquipmentQualityID, EquipmentConditionID, 
                      EquipmentName, EquipmentType, EquipmentQuality, EquipmentCondition, Quantity, DamageNote)
                     VALUES 
                     (@PackageID, @EquipmentID, @EquipmentQualityID, @EquipmentConditionID, 
                      @EquipmentName, @EquipmentType, @EquipmentQuality, @EquipmentCondition, @Quantity, @DamageNote)";


                        SqlCommand equipmentCmd = new SqlCommand(insertEquipmentQuery, db);
                        equipmentCmd.Parameters.AddWithValue("@PackageID", packageID);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentID", equipmentID);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentQualityID", equipmentQualityID);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentConditionID", equipmentConditionID);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentName", row.Cells["EquipmentName"].Value);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentType", row.Cells["EquipmentType"].Value);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentQuality", row.Cells["EquipmentQuality"].Value);
                        equipmentCmd.Parameters.AddWithValue("@EquipmentCondition", row.Cells["EquipmentCondition"].Value);
                        equipmentCmd.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                        equipmentCmd.Parameters.AddWithValue("@DamageNote", row.Cells["DamageNote"].Value ?? DBNull.Value);
                        equipmentCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Package and details added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClientAdded.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding package: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
