﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ViewInventoryMasterList : Form
    {

        public string EquipmentName { get; set; }
        public string EquipmentType { get; set; }
        public string Quantity { get; set; }
        public string EquipmentQuality { get; set; }
        public string EquipmentCondition { get; set; }
        public string DamageNote { get; set; }
        public string EquipmentID { get; set; }
        public ViewInventoryMasterList()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_EquipmentName.Text = EquipmentName;
            lbl_EquipmentType.Text = EquipmentType;
            lbl_Quantity.Text = Quantity;
            lbl_EquipmentQuality.Text = EquipmentQuality;
            lbl_EquipmentCondition.Text = EquipmentCondition;
            lbl_DamageNote.Text = DamageNote;
            lbl_EquipmentID.Text = EquipmentID;

        }

        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_InvetoryMasterList = pnl;
            getprintarea(pnl_InvetoryMasterList);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();

        }

        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_InvetoryMasterList.Width / 2), this.pnl_InvetoryMasterList.Location.Y);
        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_InvetoryMasterList);
        }
    }
}
