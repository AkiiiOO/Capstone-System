﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler ClientAdded;

        public AddNewEquipmentForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadEquipmentQuality();
            LoadEquipmentCondition();
        }
        private void LoadEquipmentQuality()
        {
            string query = "SELECT EquipmentQualityID, Quality FROM EquipmentQuality";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable qualityTable = new DataTable();
                adapter.Fill(qualityTable);

                cmb_EquipmentQuality.DataSource = qualityTable;
                cmb_EquipmentQuality.DisplayMember = "Quality";
                cmb_EquipmentQuality.ValueMember = "EquipmentQualityID";

                cmb_EquipmentQuality.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment quality: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void LoadEquipmentCondition()
        {
            string query = "SELECT EquipmentConditionID, Condition FROM EquipmentCondition";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable conditionTable = new DataTable();
                adapter.Fill(conditionTable);

                cmb_EquipmentCondition.DataSource = conditionTable;
                cmb_EquipmentCondition.DisplayMember = "Condition";
                cmb_EquipmentCondition.ValueMember = "EquipmentConditionID";

                cmb_EquipmentCondition.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment condition: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_EquipmentName.Text) || string.IsNullOrEmpty(txt_EquipmentType.Text) || string.IsNullOrEmpty(txt_Quantity.Text) || cmb_EquipmentQuality.SelectedIndex == -1 || cmb_EquipmentCondition.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                
                string equipmentName = txt_EquipmentName.Text;
                string equipmentType = txt_EquipmentType.Text;
                int quantity = int.Parse(txt_Quantity.Text);
                int equipmentQualityID = (int)cmb_EquipmentQuality.SelectedValue;
                int equipmentConditionID = (int)cmb_EquipmentCondition.SelectedValue;
                string equipmentQuality = cmb_EquipmentQuality.SelectedItem.ToString();
                string equipmentCondition = cmb_EquipmentCondition.SelectedItem.ToString();

                
                string insertQuery = @"INSERT INTO Equipment (EquipmentQualityID, EquipmentConditionID, EquipmentName, EquipmentType, EquipmentQuality, EquipmentCondition, Quantity) VALUES 
                                                             (@EquipmentQualityID, @EquipmentConditionID, @EquipmentName, @EquipmentType, @EquipmentQuality, @EquipmentCondition, @Quantity)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@EquipmentQualityID", equipmentQualityID);
                    command.Parameters.AddWithValue("@EquipmentConditionID", equipmentConditionID);
                    command.Parameters.AddWithValue("@EquipmentName", equipmentName);
                    command.Parameters.AddWithValue("@EquipmentType", equipmentType);
                    command.Parameters.AddWithValue("@EquipmentQuality", equipmentQuality);
                    command.Parameters.AddWithValue("@EquipmentCondition", equipmentCondition);
                    command.Parameters.AddWithValue("@Quantity", quantity);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Equipment added successfully.");
                        ClientAdded.Invoke(this, EventArgs.Empty);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Error adding equipment.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
