﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewClientForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler ClientAdded;

        public AddNewClientForm()
        {
            InitializeComponent();
            db = y.GetConnection();

        }
        public void SetClientDetails(string firstName, string middleName, string lastName, string address)
        {
            txtFName.Text = firstName;
            txtMName.Text = middleName;
            txtLName.Text = lastName;
            if (address != null)
            {
                txtAddress.Text = address;
            }
            else
            {
                txtAddress.Text = ""; // Optionally clear the text box or set it to empty
            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            //validations
            //first name textbox
            if (string.IsNullOrEmpty(txtFName.Text) || !txtFName.Text.All(char.IsLetter))
            {
                MessageBox.Show("First Name cannot be empty and must only contain alphabetic characters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFName.Focus();
                return;
            }
            //Middle Initial textbox
            if (string.IsNullOrEmpty(txtMName.Text) || !txtMName.Text.All(char.IsLetter))
            {
                MessageBox.Show("Middle Name cannot be empty and must only contain alphabetic characters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //Last Name textbox
            if (string.IsNullOrEmpty(txtLName.Text) || !txtLName.Text.All(char.IsLetter))
            {
                MessageBox.Show("Last Name cannot be empty and must only contain alphabetic characters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLName.Focus();
                return;
            }
            //address textbox
            if (string.IsNullOrEmpty(txtAddress.Text))
            {
                MessageBox.Show("Address cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddress.Focus();
                return;
            }
            //contact number textbox
            if (string.IsNullOrEmpty(txtContact_no.Text) || txtContact_no.Text.Length != 11 || !txtContact_no.Text.All(char.IsDigit))
            {
                MessageBox.Show("Contact Number must be exactly 11 digits.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtContact_no.Focus();
                return;
            }
            if (ClientExists(txtFName.Text, txtMName.Text, txtLName.Text, txtAddress.Text, txtContact_no.Text))
            {
                DialogResult result = MessageBox.Show("This appears to be the same person. Do you want to add this client anyway?",
                                                      "Duplicate Client", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.No)
                {
                    return; // Do nothing if the user chooses not to proceed
                }
            }


            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            db.Open();
            string query = @"INSERT INTO Clients (UserID, FirstName, MiddleName, LastName, Address, Contact_No, CreatedBy)
                             VALUES (@UserID, @FirstName, @MiddleName, @LastName, @Address, @Contact_No, @CreatedBy)";
            try
            {
                SqlCommand command = new SqlCommand(query, db);

                command.Parameters.AddWithValue("@UserID", currentUserId);
                command.Parameters.AddWithValue("@FirstName", txtFName.Text);
                command.Parameters.AddWithValue("@MiddleName", txtMName.Text);
                command.Parameters.AddWithValue("@LastName", txtLName.Text);
                command.Parameters.AddWithValue("@Address", txtAddress.Text);
                command.Parameters.AddWithValue("@Contact_No", txtContact_no.Text);
                command.Parameters.AddWithValue("@CreatedBy", createdBy);

                
                command.ExecuteNonQuery();
                db.Close();

                ClearFormFields();
                MessageBox.Show("Client added successfully.");
                ClientAdded.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while adding the client: " + ex.Message);
            }
        }
        private bool ClientExists(string firstName, string middleName, string lastName, string address, string contactNo)
        {
            string query = @"SELECT COUNT(*) FROM Clients 
                     WHERE FirstName = @FirstName 
                     AND MiddleName = @MiddleName 
                     AND LastName = @LastName 
                     AND Address = @Address 
                     AND Contact_No = @Contact_No";

            SqlCommand command = new SqlCommand(query, db);
            command.Parameters.AddWithValue("@FirstName", firstName);
            command.Parameters.AddWithValue("@MiddleName", middleName);
            command.Parameters.AddWithValue("@LastName", lastName);
            command.Parameters.AddWithValue("@Address", address);
            command.Parameters.AddWithValue("@Contact_No", contactNo);

            db.Open();
            int clientCount = (int)command.ExecuteScalar();
            db.Close();

            return clientCount > 0; // Returns true if a matching client exists
        }


        /*email textbox validation
        if (string.IsNullOrEmpty(txtEmail.Text) || !IsValidEmail(txtEmail.Text))
        {
            MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtEmail.Focus();
            return;
        }

        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return false;
            }

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                // Check if the email address ends with @gmail.com
                return addr.Address.Equals(email, StringComparison.OrdinalIgnoreCase) && email.EndsWith("@gmail.com", StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }

        }*/

        private void ClearFormFields()
        {
            txtFName.Clear();
            txtMName.Clear();
            txtLName.Clear();
            txtAddress.Clear();
            txtContact_no.Clear();
        }
    }

}
