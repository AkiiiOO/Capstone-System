﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class EditClientForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler ClientUpdated;
        public event EventHandler ClientRemoved;

        public EditClientForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLName.Text))
            {
                MessageBox.Show("First Name and Last Name are required.", "Validation Error");
                return;
            }

            if (!txtFName.Text.All(char.IsLetter) || !txtLName.Text.All(char.IsLetter))
            {
                MessageBox.Show("First Name and Last Name must contain only alphabetic letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!char.IsUpper(txtFName.Text[0]) || !char.IsUpper(txtLName.Text[0]))
            {
                MessageBox.Show("First Name and Last Name must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!string.IsNullOrEmpty(txtMName.Text))
            {

                if (txtMName.Text.Length == 1)
                {
                    MessageBox.Show("Middle Name cannot be a single character.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMName.Focus();
                    return;
                }

                if (txtMName.Text.Any(ch => !char.IsLetter(ch)))
                {
                    MessageBox.Show("Middle Name must contain only letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMName.Focus();
                    return;
                }

                if (!char.IsUpper(txtMName.Text[0]))
                {
                    MessageBox.Show("Middle Name must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMName.Focus();
                    return;
                }
            }

            if (string.IsNullOrEmpty(txtContact_no.Text) || txtContact_no.Text.Length != 11 || !txtContact_no.Text.All(char.IsDigit))
            {
                MessageBox.Show("Contact Number must be exactly 11 digits.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtContact_no.Focus();
                return;
            }

            if (string.IsNullOrEmpty(txtAddress.Text))
            {
                MessageBox.Show("Address cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddress.Focus();
                return;
            }

            if (!char.IsUpper(txtAddress.Text[0]))
            {
                MessageBox.Show("Address must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddress.Focus();
                return;
            }

    

            db.Open();
            string queryUpdate = @"UPDATE Clients SET FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName,Address = @Address, Contact_No = @Contact_No WHERE ClientID = @ClientID";
            SqlCommand command = new SqlCommand(queryUpdate, db);
            command.Parameters.AddWithValue("@ClientID", ClientID);
            command.Parameters.AddWithValue("@FirstName", txtFName.Text);
            command.Parameters.AddWithValue("@MiddleName", txtMName.Text);
            command.Parameters.AddWithValue("@LastName", txtLName.Text);
            command.Parameters.AddWithValue("@Address", txtAddress.Text);
            command.Parameters.AddWithValue("@Contact_No", txtContact_no.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("Client details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ClientUpdated.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            else
            {
                MessageBox.Show("Update failed. Client not found.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void ClearUserFields()
        {
            txtMName.Clear();
            txtLName.Clear();
            txtAddress.Clear();
            txtContact_no.Clear();
        }

        public string ClientID { get; set; }
        public string CasketName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }


        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            txtFName.Text = FirstName;
            txtMName.Text = MiddleName;
            txtLName.Text = LastName;
            txtAddress.Text = Address;
            txtContact_no.Text = ContactNo;

        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLName.Text) ||
              string.IsNullOrEmpty(txtContact_no.Text) || string.IsNullOrEmpty(txtAddress.Text))
            {
                MessageBox.Show("First Name, Last Name, Contact Number, and Address are required fields.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!string.IsNullOrEmpty(txtMName.Text))
            {

                if (txtMName.Text.Length == 1)
                {
                    MessageBox.Show("Middle Name cannot be a single character.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMName.Focus();
                    return;
                }

                if (txtMName.Text.Any(ch => !char.IsLetter(ch)))
                {
                    MessageBox.Show("Middle Name must contain only letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMName.Focus();
                    return;
                }

                if (!char.IsUpper(txtMName.Text[0]))
                {
                    MessageBox.Show("Middle Name must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtMName.Focus();
                    return;
                }
            }

            DialogResult deleteresult = MessageBox.Show("Are you sure you want to delete this user?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (deleteresult == DialogResult.Yes)
            {
                try
                {
                    db.Open();


                    string queryDeleteUser = @"DELETE FROM Clients WHERE FirstName = @FirstName";
                    using (SqlCommand commandUser = new SqlCommand(queryDeleteUser, db))
                    {

                        commandUser.Parameters.AddWithValue("@FirstName", txtFName.Text);


                        int result = commandUser.ExecuteNonQuery();

                        if (result > 0)
                        {

                            MessageBox.Show("Client deleted successfully.", "Delete Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearUserFields();
                            txtFName.Clear();
                            ClientRemoved.Invoke(this, EventArgs.Empty);
                            this.Close();
                        }
                        else
                        {

                            MessageBox.Show("Delete failed! Client not found.", "Delete Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show("An error occurred while deleting the user: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {

                    if (db.State == ConnectionState.Open)
                    {
                        db.Close();
                    }
                }
            }
        }

        
    }
}
