﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class PrintEquipmentReleaseLog : Form
    {

        public string EquipmentName { get; set; }
        public string EquipmentType { get; set; }
        public string Quantity { get; set; }
        public string ReleaseDate { get; set; }
        public string ReturnDate { get; set; }
        public string ReleasedBy { get; set; }
        public string ReturnedBy { get; set; }
        public PrintEquipmentReleaseLog()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_EquipmentName.Text = EquipmentName;
            lbl_EquipmentType.Text = EquipmentType;
            lbl_Quantity.Text = Quantity;
            lbl_ReleaseDate.Text = ReleaseDate;
            lbl_ReturnDate.Text = ReturnDate;
            lbl_ReleasedBy.Text = ReleasedBy;
            lbl_ReturnedBy.Text = ReturnedBy;
        }

        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_PrintEquipmentReleaseLog = pnl;
            getprintarea(pnl_PrintEquipmentReleaseLog);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();

        }

        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }


        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_PrintEquipmentReleaseLog);
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_PrintEquipmentReleaseLog.Width / 2), this.pnl_PrintEquipmentReleaseLog.Location.Y);
        }
    }
}
