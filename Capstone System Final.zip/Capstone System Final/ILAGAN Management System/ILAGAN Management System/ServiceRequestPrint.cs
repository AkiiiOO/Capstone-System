﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ServiceRequestPrint : Form
    {

        public int ServiceRequestID { get; set; }
 

        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;


        public ServiceRequestPrint(int serviceRequestID)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.ServiceRequestID = serviceRequestID;
            PopulateServiceRequestDetails();

        }
        private void PopulateServiceRequestDetails()
        {
            try
            {
                db.Open();

                string query = @"
                    SELECT 
                        ClientName,
                        Address,
                        DeceasedFName,
                        DeceasedMName,
                        DeceasedLName,
                        PackageName,
                        CasketName,
                        VehicleName,
                        ServiceLocation,
                        CemeteryLocation,
                        DateBurial,
                        TimeBurial,
                        EmbalmingDays,
                        SubTotal,
                        Discount,
                        DiscountRate,
                        DiscountTotal,
                        TotalPrice,
                        CreationDate
                    FROM ServiceRequests
                    WHERE ServiceRequestID = @ServiceRequestID";

                SqlCommand cmd = new SqlCommand(query, db);
                cmd.Parameters.AddWithValue("@ServiceRequestID", ServiceRequestID);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        lbl_ChargeTo.Text = reader["ClientName"] != DBNull.Value ? reader["ClientName"].ToString() : "N/A";
                        lbl_Address.Text = reader["Address"] != DBNull.Value ? reader["Address"].ToString() : "N/A";

                        string deceasedFName = reader["DeceasedFName"] != DBNull.Value ? reader["DeceasedFName"].ToString() : "";
                        string deceasedMName = reader["DeceasedMName"] != DBNull.Value ? reader["DeceasedMName"].ToString() : "";
                        string deceasedLName = reader["DeceasedLName"] != DBNull.Value ? reader["DeceasedLName"].ToString() : "";
                        lbl_DeceasedName.Text = deceasedFName + deceasedMName + deceasedLName.Trim();

                        lbl_PackageName.Text = reader["PackageName"] != DBNull.Value ? reader["PackageName"].ToString() : "N/A";
                        lbl_CasketName.Text = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                        lbl_VehicleName.Text = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                        lbl_ServiceLocation.Text = reader["ServiceLocation"] != DBNull.Value ? reader["ServiceLocation"].ToString() : "N/A";
                        lbl_Cemetery.Text = reader["CemeteryLocation"] != DBNull.Value ? reader["CemeteryLocation"].ToString() : "N/A";

                        lbl_DateofBurial.Text = reader["DateBurial"] != DBNull.Value ? Convert.ToDateTime(reader["DateBurial"]).ToString("MMMM dd, yyyy") : "N/A";
                        lbl_TimeofBurial.Text = reader["TimeBurial"] != DBNull.Value ? reader["TimeBurial"].ToString() : "N/A";

                        lbl_EmbalmingDays.Text = reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A";
                        lbl_SubTotal.Text = reader["SubTotal"] != DBNull.Value ? Convert.ToDecimal(reader["SubTotal"]).ToString("C2") : "N/A";
                        lbl_Discount.Text = reader["Discount"] != DBNull.Value ? reader["Discount"].ToString() : "N/A";
                        lbl_Discounttotal.Text = reader["DiscountTotal"] != DBNull.Value ? Convert.ToDecimal(reader["DiscountTotal"]).ToString("C2") : "N/A";
                        lbl_TotalPrice.Text = reader["TotalPrice"] != DBNull.Value ? Convert.ToDecimal(reader["TotalPrice"]).ToString("C2") : "N/A";
                        lbl_Date.Text = reader["CreationDate"] != DBNull.Value ? Convert.ToDateTime(reader["CreationDate"]).ToString("MMMM dd, yyyy hh:mm tt") : "N/A";
                    }
                    else
                    {
                        MessageBox.Show("No service request found with the specified ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading service request details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_ServiceRequestPrint);
        }

        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_ServiceRequestPrint = pnl;
            getprintarea(pnl_ServiceRequestPrint);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();
           
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            /*
            lbl_ChargeTo.Text = ClientName;
            lbl_DateofBurial.Text = DateBurial;
            lbl_TimeofBurial.Text = TimeBurial;
            lbl_TotalPrice.Text = TotalPrice;
             */
        }



        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_ServiceRequestPrint.Width / 2), this.pnl_ServiceRequestPrint.Location.Y);
        }
    }
}
