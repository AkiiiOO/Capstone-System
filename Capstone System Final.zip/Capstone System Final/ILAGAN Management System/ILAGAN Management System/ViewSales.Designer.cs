﻿namespace ILAGAN_Management_System
{
    partial class ViewSales
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewSales));
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_DiscountAmount = new System.Windows.Forms.Label();
            this.lbl_DiscountApplied = new System.Windows.Forms.Label();
            this.lbl_ClientName = new System.Windows.Forms.Label();
            this.lbl_PaymentStatus = new System.Windows.Forms.Label();
            this.lbl_RemainingBalance = new System.Windows.Forms.Label();
            this.lbl_PaymentOption = new System.Windows.Forms.Label();
            this.lbl_FinalPrice = new System.Windows.Forms.Label();
            this.lbl_Subtotal = new System.Windows.Forms.Label();
            this.lbl_PaymentID = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.btn_Print = new ILAGAN_Management_System.RoundedButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnl_ViewSalesHistory = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_ViewSalesHistory.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(22, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 16);
            this.label6.TabIndex = 135;
            this.label6.Text = "Discount Applied:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(22, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 16);
            this.label3.TabIndex = 134;
            this.label3.Text = "Discount Amount:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(25, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 15);
            this.label14.TabIndex = 130;
            this.label14.Text = "Sales Information";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 80);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(82, 16);
            this.label12.TabIndex = 128;
            this.label12.Text = "Client Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(105, 16);
            this.label5.TabIndex = 127;
            this.label5.Text = "Payment Status:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 126;
            this.label4.Text = "Final Price:";
            // 
            // lbl_DiscountAmount
            // 
            this.lbl_DiscountAmount.AutoSize = true;
            this.lbl_DiscountAmount.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DiscountAmount.Location = new System.Drawing.Point(155, 216);
            this.lbl_DiscountAmount.Name = "lbl_DiscountAmount";
            this.lbl_DiscountAmount.Size = new System.Drawing.Size(67, 16);
            this.lbl_DiscountAmount.TabIndex = 125;
            this.lbl_DiscountAmount.Text = "---------------";
            // 
            // lbl_DiscountApplied
            // 
            this.lbl_DiscountApplied.AutoSize = true;
            this.lbl_DiscountApplied.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DiscountApplied.Location = new System.Drawing.Point(155, 181);
            this.lbl_DiscountApplied.Name = "lbl_DiscountApplied";
            this.lbl_DiscountApplied.Size = new System.Drawing.Size(67, 16);
            this.lbl_DiscountApplied.TabIndex = 124;
            this.lbl_DiscountApplied.Text = "---------------";
            // 
            // lbl_ClientName
            // 
            this.lbl_ClientName.AutoSize = true;
            this.lbl_ClientName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ClientName.Location = new System.Drawing.Point(155, 80);
            this.lbl_ClientName.Name = "lbl_ClientName";
            this.lbl_ClientName.Size = new System.Drawing.Size(67, 16);
            this.lbl_ClientName.TabIndex = 123;
            this.lbl_ClientName.Text = "---------------";
            // 
            // lbl_PaymentStatus
            // 
            this.lbl_PaymentStatus.AutoSize = true;
            this.lbl_PaymentStatus.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PaymentStatus.Location = new System.Drawing.Point(155, 145);
            this.lbl_PaymentStatus.Name = "lbl_PaymentStatus";
            this.lbl_PaymentStatus.Size = new System.Drawing.Size(67, 16);
            this.lbl_PaymentStatus.TabIndex = 120;
            this.lbl_PaymentStatus.Text = "---------------";
            // 
            // lbl_RemainingBalance
            // 
            this.lbl_RemainingBalance.AutoSize = true;
            this.lbl_RemainingBalance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RemainingBalance.Location = new System.Drawing.Point(155, 280);
            this.lbl_RemainingBalance.Name = "lbl_RemainingBalance";
            this.lbl_RemainingBalance.Size = new System.Drawing.Size(67, 16);
            this.lbl_RemainingBalance.TabIndex = 118;
            this.lbl_RemainingBalance.Text = "---------------";
            // 
            // lbl_PaymentOption
            // 
            this.lbl_PaymentOption.AutoSize = true;
            this.lbl_PaymentOption.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PaymentOption.Location = new System.Drawing.Point(155, 113);
            this.lbl_PaymentOption.Name = "lbl_PaymentOption";
            this.lbl_PaymentOption.Size = new System.Drawing.Size(67, 16);
            this.lbl_PaymentOption.TabIndex = 117;
            this.lbl_PaymentOption.Text = "---------------";
            // 
            // lbl_FinalPrice
            // 
            this.lbl_FinalPrice.AutoSize = true;
            this.lbl_FinalPrice.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FinalPrice.Location = new System.Drawing.Point(155, 312);
            this.lbl_FinalPrice.Name = "lbl_FinalPrice";
            this.lbl_FinalPrice.Size = new System.Drawing.Size(67, 16);
            this.lbl_FinalPrice.TabIndex = 116;
            this.lbl_FinalPrice.Text = "---------------";
            // 
            // lbl_Subtotal
            // 
            this.lbl_Subtotal.AutoSize = true;
            this.lbl_Subtotal.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Subtotal.Location = new System.Drawing.Point(155, 247);
            this.lbl_Subtotal.Name = "lbl_Subtotal";
            this.lbl_Subtotal.Size = new System.Drawing.Size(67, 16);
            this.lbl_Subtotal.TabIndex = 115;
            this.lbl_Subtotal.Text = "---------------";
            // 
            // lbl_PaymentID
            // 
            this.lbl_PaymentID.AutoSize = true;
            this.lbl_PaymentID.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PaymentID.Location = new System.Drawing.Point(155, 49);
            this.lbl_PaymentID.Name = "lbl_PaymentID";
            this.lbl_PaymentID.Size = new System.Drawing.Size(67, 16);
            this.lbl_PaymentID.TabIndex = 114;
            this.lbl_PaymentID.Text = "---------------";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(22, 280);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(123, 16);
            this.label11.TabIndex = 112;
            this.label11.Text = "Remaining Balance:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(22, 247);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 16);
            this.label9.TabIndex = 111;
            this.label9.Text = "Sub Total:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 16);
            this.label7.TabIndex = 109;
            this.label7.Text = "Payment Option:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 108;
            this.label2.Text = "Payment ID:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Location = new System.Drawing.Point(25, 34);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(350, 2);
            this.panel7.TabIndex = 103;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // btn_Print
            // 
            this.btn_Print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Print.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Print.BorderRadius = 5;
            this.btn_Print.BorderSize = 0;
            this.btn_Print.FlatAppearance.BorderSize = 0;
            this.btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Print.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Print.ForeColor = System.Drawing.Color.White;
            this.btn_Print.Location = new System.Drawing.Point(322, 28);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(70, 30);
            this.btn_Print.TabIndex = 136;
            this.btn_Print.Text = "Print";
            this.btn_Print.TextColor = System.Drawing.Color.White;
            this.btn_Print.UseVisualStyleBackColor = false;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.btn_Print);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(395, 68);
            this.panel1.TabIndex = 63;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Sales History";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pnl_ViewSalesHistory
            // 
            this.pnl_ViewSalesHistory.Controls.Add(this.label6);
            this.pnl_ViewSalesHistory.Controls.Add(this.label3);
            this.pnl_ViewSalesHistory.Controls.Add(this.label14);
            this.pnl_ViewSalesHistory.Controls.Add(this.label12);
            this.pnl_ViewSalesHistory.Controls.Add(this.label5);
            this.pnl_ViewSalesHistory.Controls.Add(this.label4);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_DiscountAmount);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_DiscountApplied);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_ClientName);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_PaymentStatus);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_RemainingBalance);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_PaymentOption);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_FinalPrice);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_Subtotal);
            this.pnl_ViewSalesHistory.Controls.Add(this.lbl_PaymentID);
            this.pnl_ViewSalesHistory.Controls.Add(this.label11);
            this.pnl_ViewSalesHistory.Controls.Add(this.label9);
            this.pnl_ViewSalesHistory.Controls.Add(this.label7);
            this.pnl_ViewSalesHistory.Controls.Add(this.label2);
            this.pnl_ViewSalesHistory.Controls.Add(this.panel7);
            this.pnl_ViewSalesHistory.Location = new System.Drawing.Point(0, 74);
            this.pnl_ViewSalesHistory.Name = "pnl_ViewSalesHistory";
            this.pnl_ViewSalesHistory.Size = new System.Drawing.Size(395, 368);
            this.pnl_ViewSalesHistory.TabIndex = 64;
            // 
            // ViewSales
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 445);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_ViewSalesHistory);
            this.Name = "ViewSales";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewSales";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_ViewSalesHistory.ResumeLayout(false);
            this.pnl_ViewSalesHistory.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_DiscountAmount;
        private System.Windows.Forms.Label lbl_DiscountApplied;
        private System.Windows.Forms.Label lbl_ClientName;
        private System.Windows.Forms.Label lbl_PaymentStatus;
        private System.Windows.Forms.Label lbl_RemainingBalance;
        private System.Windows.Forms.Label lbl_PaymentOption;
        private System.Windows.Forms.Label lbl_FinalPrice;
        private System.Windows.Forms.Label lbl_Subtotal;
        private System.Windows.Forms.Label lbl_PaymentID;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private RoundedButton btn_Print;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnl_ViewSalesHistory;
    }
}