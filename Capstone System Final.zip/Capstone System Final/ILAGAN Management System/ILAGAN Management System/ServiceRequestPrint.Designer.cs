﻿namespace ILAGAN_Management_System
{
    partial class ServiceRequestPrint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServiceRequestPrint));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnl_ServiceRequestPrint = new System.Windows.Forms.Panel();
            this.lbl_PackageName = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.lbl_Cemetery = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lbl_TimeofBurial = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.lbl_DateofBurial = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.lbl_DeceasedName = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lbl_CasketName = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_Discount = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbl_TotalPrice = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_SubTotal = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_VehicleName = new System.Windows.Forms.Label();
            this.lbl_EmbalmingDays = new System.Windows.Forms.Label();
            this.lbl_ChargeTo = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.lbl_Discounttotal = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lbl_ServiceLocation = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btn_Print = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_ServiceRequestPrint.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.btn_Print);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(834, 68);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Service Contract";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pnl_ServiceRequestPrint
            // 
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_ServiceLocation);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label15);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Discounttotal);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label20);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_PackageName);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label12);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label42);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Cemetery);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label35);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_TimeofBurial);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label37);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_DateofBurial);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label39);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Date);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label41);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_DeceasedName);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label31);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Address);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label28);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_CasketName);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label27);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label25);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label26);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label24);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label22);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Discount);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label23);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_TotalPrice);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label19);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label18);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label17);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label16);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_SubTotal);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label14);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_VehicleName);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_EmbalmingDays);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_ChargeTo);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label13);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label10);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label9);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label8);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label7);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label6);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label5);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label4);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label3);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label2);
            this.pnl_ServiceRequestPrint.Location = new System.Drawing.Point(0, 74);
            this.pnl_ServiceRequestPrint.Name = "pnl_ServiceRequestPrint";
            this.pnl_ServiceRequestPrint.Size = new System.Drawing.Size(834, 702);
            this.pnl_ServiceRequestPrint.TabIndex = 6;
            // 
            // lbl_PackageName
            // 
            this.lbl_PackageName.AutoSize = true;
            this.lbl_PackageName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PackageName.Location = new System.Drawing.Point(230, 291);
            this.lbl_PackageName.Name = "lbl_PackageName";
            this.lbl_PackageName.Size = new System.Drawing.Size(92, 16);
            this.lbl_PackageName.TabIndex = 52;
            this.lbl_PackageName.Text = "---------------------";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(62, 291);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 16);
            this.label12.TabIndex = 51;
            this.label12.Text = "PACKAGE";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(347, 251);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(149, 22);
            this.label42.TabIndex = 50;
            this.label42.Text = "PARTICULARS";
            // 
            // lbl_Cemetery
            // 
            this.lbl_Cemetery.AutoSize = true;
            this.lbl_Cemetery.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cemetery.Location = new System.Drawing.Point(622, 198);
            this.lbl_Cemetery.Name = "lbl_Cemetery";
            this.lbl_Cemetery.Size = new System.Drawing.Size(92, 16);
            this.lbl_Cemetery.TabIndex = 49;
            this.lbl_Cemetery.Text = "---------------------";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(531, 198);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(64, 16);
            this.label35.TabIndex = 48;
            this.label35.Text = "Cemetery";
            // 
            // lbl_TimeofBurial
            // 
            this.lbl_TimeofBurial.AutoSize = true;
            this.lbl_TimeofBurial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TimeofBurial.Location = new System.Drawing.Point(622, 182);
            this.lbl_TimeofBurial.Name = "lbl_TimeofBurial";
            this.lbl_TimeofBurial.Size = new System.Drawing.Size(92, 16);
            this.lbl_TimeofBurial.TabIndex = 47;
            this.lbl_TimeofBurial.Text = "---------------------";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(530, 182);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(87, 16);
            this.label37.TabIndex = 46;
            this.label37.Text = "Time of Burial";
            // 
            // lbl_DateofBurial
            // 
            this.lbl_DateofBurial.AutoSize = true;
            this.lbl_DateofBurial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DateofBurial.Location = new System.Drawing.Point(622, 165);
            this.lbl_DateofBurial.Name = "lbl_DateofBurial";
            this.lbl_DateofBurial.Size = new System.Drawing.Size(92, 16);
            this.lbl_DateofBurial.TabIndex = 45;
            this.lbl_DateofBurial.Text = "---------------------";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(531, 165);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(86, 16);
            this.label39.TabIndex = 44;
            this.label39.Text = "Date of Burial";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.Location = new System.Drawing.Point(622, 149);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(92, 16);
            this.lbl_Date.TabIndex = 43;
            this.lbl_Date.Text = "---------------------";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(531, 150);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(33, 15);
            this.label41.TabIndex = 42;
            this.label41.Text = "Date";
            // 
            // lbl_DeceasedName
            // 
            this.lbl_DeceasedName.AutoSize = true;
            this.lbl_DeceasedName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DeceasedName.Location = new System.Drawing.Point(170, 182);
            this.lbl_DeceasedName.Name = "lbl_DeceasedName";
            this.lbl_DeceasedName.Size = new System.Drawing.Size(92, 16);
            this.lbl_DeceasedName.TabIndex = 39;
            this.lbl_DeceasedName.Text = "---------------------";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(61, 182);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(66, 16);
            this.label31.TabIndex = 38;
            this.label31.Text = "Deceased";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(170, 166);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(92, 16);
            this.lbl_Address.TabIndex = 37;
            this.lbl_Address.Text = "---------------------";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(60, 166);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(56, 16);
            this.label28.TabIndex = 36;
            this.label28.Text = "Address";
            // 
            // lbl_CasketName
            // 
            this.lbl_CasketName.AutoSize = true;
            this.lbl_CasketName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CasketName.Location = new System.Drawing.Point(230, 327);
            this.lbl_CasketName.Name = "lbl_CasketName";
            this.lbl_CasketName.Size = new System.Drawing.Size(92, 16);
            this.lbl_CasketName.TabIndex = 35;
            this.lbl_CasketName.Text = "---------------------";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(62, 327);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(60, 16);
            this.label27.TabIndex = 34;
            this.label27.Text = "CASKET";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(530, 585);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(180, 16);
            this.label25.TabIndex = 33;
            this.label25.Text = "-------------------------------------------";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(572, 618);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(106, 16);
            this.label26.TabIndex = 32;
            this.label26.Text = "Manager/Cashier";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(98, 585);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(180, 16);
            this.label24.TabIndex = 31;
            this.label24.Text = "-------------------------------------------";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(152, 618);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(63, 16);
            this.label22.TabIndex = 30;
            this.label22.Text = "Conforme";
            // 
            // lbl_Discount
            // 
            this.lbl_Discount.AutoSize = true;
            this.lbl_Discount.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Discount.Location = new System.Drawing.Point(643, 493);
            this.lbl_Discount.Name = "lbl_Discount";
            this.lbl_Discount.Size = new System.Drawing.Size(92, 16);
            this.lbl_Discount.TabIndex = 29;
            this.lbl_Discount.Text = "---------------------";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(496, 493);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(98, 16);
            this.label23.TabIndex = 28;
            this.label23.Text = "DISCOUNT    ₱";
            // 
            // lbl_TotalPrice
            // 
            this.lbl_TotalPrice.AutoSize = true;
            this.lbl_TotalPrice.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPrice.Location = new System.Drawing.Point(643, 458);
            this.lbl_TotalPrice.Name = "lbl_TotalPrice";
            this.lbl_TotalPrice.Size = new System.Drawing.Size(92, 16);
            this.lbl_TotalPrice.TabIndex = 25;
            this.lbl_TotalPrice.Text = "---------------------";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(496, 458);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 16);
            this.label19.TabIndex = 22;
            this.label19.Text = "TOTAL           ₱";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(86, 509);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(192, 16);
            this.label18.TabIndex = 21;
            this.label18.Text = " balance on or before the Burial.";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(114, 493);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(271, 16);
            this.label17.TabIndex = 20;
            this.label17.Text = "I hereby agree to pay the total charges on the";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(28, 418);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(784, 22);
            this.label16.TabIndex = 19;
            this.label16.Text = "---------------------------------------------------------------------------------" +
                "------------------------------------------------";
            // 
            // lbl_SubTotal
            // 
            this.lbl_SubTotal.AutoSize = true;
            this.lbl_SubTotal.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SubTotal.Location = new System.Drawing.Point(230, 467);
            this.lbl_SubTotal.Name = "lbl_SubTotal";
            this.lbl_SubTotal.Size = new System.Drawing.Size(92, 16);
            this.lbl_SubTotal.TabIndex = 18;
            this.lbl_SubTotal.Text = "---------------------";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(60, 467);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(115, 16);
            this.label14.TabIndex = 17;
            this.label14.Text = "TOTAL CHARGES";
            // 
            // lbl_VehicleName
            // 
            this.lbl_VehicleName.AutoSize = true;
            this.lbl_VehicleName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VehicleName.Location = new System.Drawing.Point(230, 368);
            this.lbl_VehicleName.Name = "lbl_VehicleName";
            this.lbl_VehicleName.Size = new System.Drawing.Size(92, 16);
            this.lbl_VehicleName.TabIndex = 16;
            this.lbl_VehicleName.Text = "---------------------";
            // 
            // lbl_EmbalmingDays
            // 
            this.lbl_EmbalmingDays.AutoSize = true;
            this.lbl_EmbalmingDays.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EmbalmingDays.Location = new System.Drawing.Point(678, 291);
            this.lbl_EmbalmingDays.Name = "lbl_EmbalmingDays";
            this.lbl_EmbalmingDays.Size = new System.Drawing.Size(92, 16);
            this.lbl_EmbalmingDays.TabIndex = 13;
            this.lbl_EmbalmingDays.Text = "---------------------";
            // 
            // lbl_ChargeTo
            // 
            this.lbl_ChargeTo.AutoSize = true;
            this.lbl_ChargeTo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChargeTo.Location = new System.Drawing.Point(170, 149);
            this.lbl_ChargeTo.Name = "lbl_ChargeTo";
            this.lbl_ChargeTo.Size = new System.Drawing.Size(92, 16);
            this.lbl_ChargeTo.TabIndex = 12;
            this.lbl_ChargeTo.Text = "---------------------";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(62, 368);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 16);
            this.label13.TabIndex = 11;
            this.label13.Text = "FUNERAL CAR";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(509, 291);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(125, 16);
            this.label10.TabIndex = 8;
            this.label10.Text = "EMBALMING DAYS";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(61, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 15);
            this.label9.TabIndex = 7;
            this.label9.Text = "CHARGE TO ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(310, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 22);
            this.label8.TabIndex = 6;
            this.label8.Text = "---------------------------------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(308, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 22);
            this.label7.TabIndex = 5;
            this.label7.Text = "SERVICE CONTRACT";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(324, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 14);
            this.label6.TabIndex = 4;
            this.label6.Text = "NON-VAT REG. TIN; 114-940-383-000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(325, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "CLODY A. ILAGAN --- Manager";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(348, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 14);
            this.label4.TabIndex = 2;
            this.label4.Text = " TEL. NO. (045)982-1440";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(298, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 14);
            this.label3.TabIndex = 1;
            this.label3.Text = "F.TANEDO ST. SAN NICOLAS, TARLAC CITY";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(229, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(366, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "CLODY A. ILAGAN MEMORIAL HOMES";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // lbl_Discounttotal
            // 
            this.lbl_Discounttotal.AutoSize = true;
            this.lbl_Discounttotal.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Discounttotal.Location = new System.Drawing.Point(643, 528);
            this.lbl_Discounttotal.Name = "lbl_Discounttotal";
            this.lbl_Discounttotal.Size = new System.Drawing.Size(92, 16);
            this.lbl_Discounttotal.TabIndex = 54;
            this.lbl_Discounttotal.Text = "---------------------";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(496, 528);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(141, 16);
            this.label20.TabIndex = 53;
            this.label20.Text = "DISCOUNT TOTAL    ₱";
            // 
            // lbl_ServiceLocation
            // 
            this.lbl_ServiceLocation.AutoSize = true;
            this.lbl_ServiceLocation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServiceLocation.Location = new System.Drawing.Point(170, 198);
            this.lbl_ServiceLocation.Name = "lbl_ServiceLocation";
            this.lbl_ServiceLocation.Size = new System.Drawing.Size(92, 16);
            this.lbl_ServiceLocation.TabIndex = 56;
            this.lbl_ServiceLocation.Text = "---------------------";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(61, 198);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 16);
            this.label15.TabIndex = 55;
            this.label15.Text = "Service Location";
            // 
            // btn_Print
            // 
            this.btn_Print.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Print.BorderRadius = 5;
            this.btn_Print.BorderSize = 0;
            this.btn_Print.FlatAppearance.BorderSize = 0;
            this.btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Print.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Print.ForeColor = System.Drawing.Color.White;
            this.btn_Print.Location = new System.Drawing.Point(742, 20);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(70, 30);
            this.btn_Print.TabIndex = 77;
            this.btn_Print.Text = "Print";
            this.btn_Print.TextColor = System.Drawing.Color.White;
            this.btn_Print.UseVisualStyleBackColor = false;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // ServiceRequestPrint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 746);
            this.Controls.Add(this.pnl_ServiceRequestPrint);
            this.Controls.Add(this.panel1);
            this.Name = "ServiceRequestPrint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ServiceRequestPrint";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_ServiceRequestPrint.ResumeLayout(false);
            this.pnl_ServiceRequestPrint.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private RoundedButton btn_Print;
        private System.Windows.Forms.Panel pnl_ServiceRequestPrint;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lbl_Cemetery;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lbl_TimeofBurial;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lbl_DateofBurial;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label lbl_DeceasedName;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lbl_CasketName;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbl_Discount;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbl_TotalPrice;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_SubTotal;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl_VehicleName;
        private System.Windows.Forms.Label lbl_EmbalmingDays;
        private System.Windows.Forms.Label lbl_ChargeTo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Label lbl_PackageName;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lbl_Discounttotal;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbl_ServiceLocation;
        private System.Windows.Forms.Label label15;
    }
}