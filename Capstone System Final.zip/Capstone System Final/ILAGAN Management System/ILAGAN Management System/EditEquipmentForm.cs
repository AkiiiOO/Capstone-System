﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class EditEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler EquipmentUpdated;

        public string EquipmentID { get; set; }
        public string EquipmentName { get; set; }
        public string EquipmentType { get; set; }
        public string CreatedDate { get; set; }
        public string Quantity { get; set; }

        public EditEquipmentForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            lbl_EquipmentID.Text = EquipmentID;
            txt_EquipName.Text = EquipmentName;
            txt_EquipType.Text = EquipmentType;
            lbl_Quantity.Text = Quantity;

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_EquipName.Text) || string.IsNullOrEmpty(txt_EquipType.Text))
            {
                MessageBox.Show("Equipment Name and Equipment Type are required.", "Validation Error");
                return;
            }

            if (!char.IsUpper(txt_EquipName.Text[0]) || !char.IsUpper(txt_EquipType.Text[0]))
            {
                MessageBox.Show("Equipment Name and Equipment Type must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            db.Open();
            string queryUpdate = @"UPDATE Equipment SET EquipmentName = @EquipmentName, EquipmentType = @EquipmentType, Quantity = @Quantity WHERE EquipmentID = @EquipmentID";
            SqlCommand command = new SqlCommand(queryUpdate, db);
            command.Parameters.AddWithValue("@EquipmentID", lbl_EquipmentID.Text);
            command.Parameters.AddWithValue("@EquipmentName", txt_EquipName.Text);
            command.Parameters.AddWithValue("@EquipmentType", txt_EquipType.Text);
            command.Parameters.AddWithValue("@Quantity", lbl_Quantity.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("Employee details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                EquipmentUpdated.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            else
            {
                MessageBox.Show("Update failed. Employee not found.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
