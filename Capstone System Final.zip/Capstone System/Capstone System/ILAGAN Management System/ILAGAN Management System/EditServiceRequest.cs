﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class EditServiceRequest : Form
    {
        public event EventHandler ServiceRequestUpdated;

        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public string ServiceRequestID {get;set;}
        public string ClientName { get; set; }
        public string DeceasedFullName { get; set; }
        public string DeceasedFName { get; set; }
        public string DeceasedMName { get; set; }
        public string DeceasedLName { get; set; }
        public string PackageName { get; set; }
        public string TotalPrice { get; set; }
        public string StatusName { get; set; }
        public string DateBurial { get; set; }
        public string TimeBurial { get; set; }
        public string CemeteryLocation { get; set; }

        public EditServiceRequest()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_ServiceRequest.Text = ServiceRequestID;
            txt_ClientName.Text = ClientName;
            txt_DFName.Text = DeceasedFName;
            txt_DMName.Text = DeceasedMName;
            txt_DLName.Text = DeceasedLName;
            lbl_PackageName.Text = PackageName;
            lbl_TotalPrice.Text = TotalPrice;
            lbl_Status.Text = StatusName;
            dtp_BurialTime.Text = DateBurial;
            dtp_DateBurial.Text = TimeBurial;
            cmb_CemeteryLocation.Text = CemeteryLocation;

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void EditServiceRequest_Load(object sender, EventArgs e)
        {

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_ClientName.Text) || string.IsNullOrEmpty(txt_DFName.Text) || string.IsNullOrEmpty(txt_DMName.Text) || string.IsNullOrEmpty(txt_DLName.Text))
            {
                MessageBox.Show("First Name and Last Name are required.", "Validation Error");
                return;
            }


            if (!char.IsUpper(txt_ClientName.Text[0]) || !char.IsUpper(txt_DFName.Text[0]) || !char.IsUpper(txt_DMName.Text[0]) || !char.IsUpper(txt_DLName.Text[0]) )
            {
                MessageBox.Show("First Name and Last Name must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            db.Open();
            string queryUpdate = @"UPDATE ServiceRequests SET
                                        ClientName = @ClientName,
                                        DeceasedFName = @DeceasedFName,
                                        DeceasedMName = @DeceasedMName,
                                        DeceasedLName = @DeceasedLName,
                                        DateBurial = @DateBurial,
                                        TimeBurial = @TimeBurial,
                                        CemeteryLocation = @CemeteryLocation
                                 WHERE ServiceRequestID = @ServiceRequestID";
            SqlCommand command = new SqlCommand(queryUpdate, db);
            command.Parameters.AddWithValue("@ServiceRequestID", ServiceRequestID);
            command.Parameters.AddWithValue("@ClientName", txt_ClientName.Text);
            command.Parameters.AddWithValue("@DeceasedFName", txt_DFName.Text);
            command.Parameters.AddWithValue("@DeceasedMName", txt_DMName.Text);
            command.Parameters.AddWithValue("@DeceasedLName", txt_DLName.Text);
            command.Parameters.AddWithValue("@ServiceStatus", lbl_Status.Text);
            command.Parameters.AddWithValue("@PackageName", PackageName);
            command.Parameters.AddWithValue("@TotalPrice", TotalPrice);
            command.Parameters.AddWithValue("@DateBurial", dtp_DateBurial.Value.ToString("yyyy-MM-dd")); 
            command.Parameters.AddWithValue("@TimeBurial", dtp_BurialTime.Value.ToString("HH:mm:ss"));
            command.Parameters.AddWithValue("@CemeteryLocation", cmb_CemeteryLocation.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("Service Request details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ServiceRequestUpdated?.Invoke(this, EventArgs.Empty);

                this.Close();
            }
            else
            {
                MessageBox.Show("Update failed.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
