﻿namespace ILAGAN_Management_System
{
    partial class ServiceRequestPrint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServiceRequestPrint));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Print = new ILAGAN_Management_System.RoundedButton();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnl_ServiceRequestPrint = new System.Windows.Forms.Panel();
            this.label42 = new System.Windows.Forms.Label();
            this.lbl_Cemetery = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.lbl_TimeofBurial = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.lbl_DateofBurial = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.lbl_ServiceLocation = new System.Windows.Forms.Label();
            this.lblAddress2 = new System.Windows.Forms.Label();
            this.lbl_DeceasedName = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.lbl_Casket = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_Discount = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lbl_Balance = new System.Windows.Forms.Label();
            this.lbl_Advance = new System.Windows.Forms.Label();
            this.lbl_TotalPrice = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbl_TotalCharges = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lbl_FuneralCar = new System.Windows.Forms.Label();
            this.lbl_Delivery = new System.Windows.Forms.Label();
            this.lbl_ServiceLights = new System.Windows.Forms.Label();
            this.lbl_Embalming = new System.Windows.Forms.Label();
            this.lbl_ChargeTo = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnl_ServiceRequestPrint.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.btn_Print);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(834, 68);
            this.panel1.TabIndex = 4;
            // 
            // btn_Print
            // 
            this.btn_Print.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Print.BorderRadius = 5;
            this.btn_Print.BorderSize = 0;
            this.btn_Print.FlatAppearance.BorderSize = 0;
            this.btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Print.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Print.ForeColor = System.Drawing.Color.White;
            this.btn_Print.Location = new System.Drawing.Point(742, 20);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(70, 30);
            this.btn_Print.TabIndex = 77;
            this.btn_Print.Text = "Print";
            this.btn_Print.TextColor = System.Drawing.Color.White;
            this.btn_Print.UseVisualStyleBackColor = false;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Service Contract";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pnl_ServiceRequestPrint
            // 
            this.pnl_ServiceRequestPrint.Controls.Add(this.label42);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Cemetery);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label35);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_TimeofBurial);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label37);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_DateofBurial);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label39);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Date);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label41);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_ServiceLocation);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lblAddress2);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_DeceasedName);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label31);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Address);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label28);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Casket);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label27);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label25);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label26);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label24);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label22);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Discount);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label23);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Balance);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Advance);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_TotalPrice);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label21);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label20);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label19);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label18);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label17);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label16);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_TotalCharges);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label14);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_FuneralCar);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Delivery);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_ServiceLights);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_Embalming);
            this.pnl_ServiceRequestPrint.Controls.Add(this.lbl_ChargeTo);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label13);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label12);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label11);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label10);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label9);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label8);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label7);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label6);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label5);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label4);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label3);
            this.pnl_ServiceRequestPrint.Controls.Add(this.label2);
            this.pnl_ServiceRequestPrint.Location = new System.Drawing.Point(0, 74);
            this.pnl_ServiceRequestPrint.Name = "pnl_ServiceRequestPrint";
            this.pnl_ServiceRequestPrint.Size = new System.Drawing.Size(834, 903);
            this.pnl_ServiceRequestPrint.TabIndex = 6;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(347, 251);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(149, 22);
            this.label42.TabIndex = 50;
            this.label42.Text = "PARTICULARS";
            // 
            // lbl_Cemetery
            // 
            this.lbl_Cemetery.AutoSize = true;
            this.lbl_Cemetery.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Cemetery.Location = new System.Drawing.Point(660, 198);
            this.lbl_Cemetery.Name = "lbl_Cemetery";
            this.lbl_Cemetery.Size = new System.Drawing.Size(91, 16);
            this.lbl_Cemetery.TabIndex = 49;
            this.lbl_Cemetery.Text = "---------------------";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(569, 198);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(63, 16);
            this.label35.TabIndex = 48;
            this.label35.Text = "Cemetery";
            // 
            // lbl_TimeofBurial
            // 
            this.lbl_TimeofBurial.AutoSize = true;
            this.lbl_TimeofBurial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TimeofBurial.Location = new System.Drawing.Point(660, 182);
            this.lbl_TimeofBurial.Name = "lbl_TimeofBurial";
            this.lbl_TimeofBurial.Size = new System.Drawing.Size(91, 16);
            this.lbl_TimeofBurial.TabIndex = 47;
            this.lbl_TimeofBurial.Text = "---------------------";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(568, 182);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(86, 16);
            this.label37.TabIndex = 46;
            this.label37.Text = "Time of Burial";
            // 
            // lbl_DateofBurial
            // 
            this.lbl_DateofBurial.AutoSize = true;
            this.lbl_DateofBurial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DateofBurial.Location = new System.Drawing.Point(660, 165);
            this.lbl_DateofBurial.Name = "lbl_DateofBurial";
            this.lbl_DateofBurial.Size = new System.Drawing.Size(91, 16);
            this.lbl_DateofBurial.TabIndex = 45;
            this.lbl_DateofBurial.Text = "---------------------";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(569, 165);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(85, 16);
            this.label39.TabIndex = 44;
            this.label39.Text = "Date of Burial";
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.Location = new System.Drawing.Point(660, 149);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(91, 16);
            this.lbl_Date.TabIndex = 43;
            this.lbl_Date.Text = "---------------------";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(569, 150);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(33, 15);
            this.label41.TabIndex = 42;
            this.label41.Text = "Date";
            // 
            // lbl_ServiceLocation
            // 
            this.lbl_ServiceLocation.AutoSize = true;
            this.lbl_ServiceLocation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServiceLocation.Location = new System.Drawing.Point(152, 198);
            this.lbl_ServiceLocation.Name = "lbl_ServiceLocation";
            this.lbl_ServiceLocation.Size = new System.Drawing.Size(91, 16);
            this.lbl_ServiceLocation.TabIndex = 41;
            this.lbl_ServiceLocation.Text = "---------------------";
            // 
            // lblAddress2
            // 
            this.lblAddress2.AutoSize = true;
            this.lblAddress2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress2.Location = new System.Drawing.Point(62, 198);
            this.lblAddress2.Name = "lblAddress2";
            this.lblAddress2.Size = new System.Drawing.Size(55, 16);
            this.lblAddress2.TabIndex = 40;
            this.lblAddress2.Text = "Address";
            // 
            // lbl_DeceasedName
            // 
            this.lbl_DeceasedName.AutoSize = true;
            this.lbl_DeceasedName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DeceasedName.Location = new System.Drawing.Point(152, 182);
            this.lbl_DeceasedName.Name = "lbl_DeceasedName";
            this.lbl_DeceasedName.Size = new System.Drawing.Size(91, 16);
            this.lbl_DeceasedName.TabIndex = 39;
            this.lbl_DeceasedName.Text = "---------------------";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(62, 182);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 16);
            this.label31.TabIndex = 38;
            this.label31.Text = "Deceased";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(152, 166);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(91, 16);
            this.lbl_Address.TabIndex = 37;
            this.lbl_Address.Text = "---------------------";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(61, 166);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 16);
            this.label28.TabIndex = 36;
            this.label28.Text = "Address";
            // 
            // lbl_Casket
            // 
            this.lbl_Casket.AutoSize = true;
            this.lbl_Casket.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Casket.Location = new System.Drawing.Point(230, 315);
            this.lbl_Casket.Name = "lbl_Casket";
            this.lbl_Casket.Size = new System.Drawing.Size(91, 16);
            this.lbl_Casket.TabIndex = 35;
            this.lbl_Casket.Text = "---------------------";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(62, 315);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 16);
            this.label27.TabIndex = 34;
            this.label27.Text = "CASKET";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(546, 794);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(179, 16);
            this.label25.TabIndex = 33;
            this.label25.Text = "-------------------------------------------";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(593, 810);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(105, 16);
            this.label26.TabIndex = 32;
            this.label26.Text = "Manager/Cashier";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(114, 794);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(179, 16);
            this.label24.TabIndex = 31;
            this.label24.Text = "-------------------------------------------";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(173, 810);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(62, 16);
            this.label22.TabIndex = 30;
            this.label22.Text = "Conforme";
            // 
            // lbl_Discount
            // 
            this.lbl_Discount.AutoSize = true;
            this.lbl_Discount.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Discount.Location = new System.Drawing.Point(634, 668);
            this.lbl_Discount.Name = "lbl_Discount";
            this.lbl_Discount.Size = new System.Drawing.Size(91, 16);
            this.lbl_Discount.TabIndex = 29;
            this.lbl_Discount.Text = "---------------------";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(512, 668);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(97, 16);
            this.label23.TabIndex = 28;
            this.label23.Text = "DISCOUNT    ₱";
            // 
            // lbl_Balance
            // 
            this.lbl_Balance.AutoSize = true;
            this.lbl_Balance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Balance.Location = new System.Drawing.Point(634, 701);
            this.lbl_Balance.Name = "lbl_Balance";
            this.lbl_Balance.Size = new System.Drawing.Size(91, 16);
            this.lbl_Balance.TabIndex = 27;
            this.lbl_Balance.Text = "---------------------";
            // 
            // lbl_Advance
            // 
            this.lbl_Advance.AutoSize = true;
            this.lbl_Advance.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Advance.Location = new System.Drawing.Point(634, 635);
            this.lbl_Advance.Name = "lbl_Advance";
            this.lbl_Advance.Size = new System.Drawing.Size(91, 16);
            this.lbl_Advance.TabIndex = 26;
            this.lbl_Advance.Text = "---------------------";
            // 
            // lbl_TotalPrice
            // 
            this.lbl_TotalPrice.AutoSize = true;
            this.lbl_TotalPrice.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPrice.Location = new System.Drawing.Point(634, 600);
            this.lbl_TotalPrice.Name = "lbl_TotalPrice";
            this.lbl_TotalPrice.Size = new System.Drawing.Size(91, 16);
            this.lbl_TotalPrice.TabIndex = 25;
            this.lbl_TotalPrice.Text = "---------------------";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(512, 701);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(97, 16);
            this.label21.TabIndex = 24;
            this.label21.Text = "BALANCE     ₱";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(512, 635);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(98, 16);
            this.label20.TabIndex = 23;
            this.label20.Text = "ADVANCE     ₱";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(512, 600);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 16);
            this.label19.TabIndex = 22;
            this.label19.Text = "TOTAL           ₱";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(102, 651);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(191, 16);
            this.label18.TabIndex = 21;
            this.label18.Text = " balance on or before the Burial.";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(130, 635);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(270, 16);
            this.label17.TabIndex = 20;
            this.label17.Text = "I hereby agree to pay the total charges on the";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(28, 567);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(784, 22);
            this.label16.TabIndex = 19;
            this.label16.Text = "---------------------------------------------------------------------------------" +
    "------------------------------------------------";
            // 
            // lbl_TotalCharges
            // 
            this.lbl_TotalCharges.AutoSize = true;
            this.lbl_TotalCharges.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalCharges.Location = new System.Drawing.Point(246, 609);
            this.lbl_TotalCharges.Name = "lbl_TotalCharges";
            this.lbl_TotalCharges.Size = new System.Drawing.Size(91, 16);
            this.lbl_TotalCharges.TabIndex = 18;
            this.lbl_TotalCharges.Text = "---------------------";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(76, 609);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(114, 16);
            this.label14.TabIndex = 17;
            this.label14.Text = "TOTAL CHARGES";
            // 
            // lbl_FuneralCar
            // 
            this.lbl_FuneralCar.AutoSize = true;
            this.lbl_FuneralCar.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FuneralCar.Location = new System.Drawing.Point(230, 486);
            this.lbl_FuneralCar.Name = "lbl_FuneralCar";
            this.lbl_FuneralCar.Size = new System.Drawing.Size(91, 16);
            this.lbl_FuneralCar.TabIndex = 16;
            this.lbl_FuneralCar.Text = "---------------------";
            // 
            // lbl_Delivery
            // 
            this.lbl_Delivery.AutoSize = true;
            this.lbl_Delivery.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Delivery.Location = new System.Drawing.Point(230, 441);
            this.lbl_Delivery.Name = "lbl_Delivery";
            this.lbl_Delivery.Size = new System.Drawing.Size(91, 16);
            this.lbl_Delivery.TabIndex = 15;
            this.lbl_Delivery.Text = "---------------------";
            // 
            // lbl_ServiceLights
            // 
            this.lbl_ServiceLights.AutoSize = true;
            this.lbl_ServiceLights.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServiceLights.Location = new System.Drawing.Point(230, 398);
            this.lbl_ServiceLights.Name = "lbl_ServiceLights";
            this.lbl_ServiceLights.Size = new System.Drawing.Size(91, 16);
            this.lbl_ServiceLights.TabIndex = 14;
            this.lbl_ServiceLights.Text = "---------------------";
            // 
            // lbl_Embalming
            // 
            this.lbl_Embalming.AutoSize = true;
            this.lbl_Embalming.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Embalming.Location = new System.Drawing.Point(230, 354);
            this.lbl_Embalming.Name = "lbl_Embalming";
            this.lbl_Embalming.Size = new System.Drawing.Size(91, 16);
            this.lbl_Embalming.TabIndex = 13;
            this.lbl_Embalming.Text = "---------------------";
            // 
            // lbl_ChargeTo
            // 
            this.lbl_ChargeTo.AutoSize = true;
            this.lbl_ChargeTo.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChargeTo.Location = new System.Drawing.Point(152, 150);
            this.lbl_ChargeTo.Name = "lbl_ChargeTo";
            this.lbl_ChargeTo.Size = new System.Drawing.Size(91, 16);
            this.lbl_ChargeTo.TabIndex = 12;
            this.lbl_ChargeTo.Text = "---------------------";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(62, 486);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 16);
            this.label13.TabIndex = 11;
            this.label13.Text = "FUNERAL CAR";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(62, 441);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 16);
            this.label12.TabIndex = 10;
            this.label12.Text = "DELIVERY";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(61, 398);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(113, 16);
            this.label11.TabIndex = 9;
            this.label11.Text = "SERVICE LIGHTS";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(61, 354);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 16);
            this.label10.TabIndex = 8;
            this.label10.Text = "EMBALMING";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(61, 151);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 15);
            this.label9.TabIndex = 7;
            this.label9.Text = "CHARGE TO ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(310, 128);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 22);
            this.label8.TabIndex = 6;
            this.label8.Text = "---------------------------------";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(308, 106);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 22);
            this.label7.TabIndex = 5;
            this.label7.Text = "SERVICE CONTRACT";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(324, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(187, 14);
            this.label6.TabIndex = 4;
            this.label6.Text = "NON-VAT REG. TIN; 114-940-383-000";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(325, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(171, 12);
            this.label5.TabIndex = 3;
            this.label5.Text = "CLODY A. ILAGAN --- Manager";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(348, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 14);
            this.label4.TabIndex = 2;
            this.label4.Text = " TEL. NO. (045)982-1440";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(298, 32);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(220, 14);
            this.label3.TabIndex = 1;
            this.label3.Text = "F.TANEDO ST. SAN NICOLAS, TARLAC CITY";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(229, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(366, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "CLODY A. ILAGAN MEMORIAL HOMES";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // ServiceRequestPrint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 961);
            this.Controls.Add(this.pnl_ServiceRequestPrint);
            this.Controls.Add(this.panel1);
            this.Name = "ServiceRequestPrint";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ServiceRequestPrint";
            this.Load += new System.EventHandler(this.ServiceRequestPrint_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnl_ServiceRequestPrint.ResumeLayout(false);
            this.pnl_ServiceRequestPrint.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private RoundedButton btn_Print;
        private System.Windows.Forms.Panel pnl_ServiceRequestPrint;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label lbl_Cemetery;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lbl_TimeofBurial;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label lbl_DateofBurial;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label lbl_ServiceLocation;
        private System.Windows.Forms.Label lblAddress2;
        private System.Windows.Forms.Label lbl_DeceasedName;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label lbl_Address;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lbl_Casket;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbl_Discount;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lbl_Balance;
        private System.Windows.Forms.Label lbl_Advance;
        private System.Windows.Forms.Label lbl_TotalPrice;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_TotalCharges;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lbl_FuneralCar;
        private System.Windows.Forms.Label lbl_Delivery;
        private System.Windows.Forms.Label lbl_ServiceLights;
        private System.Windows.Forms.Label lbl_Embalming;
        private System.Windows.Forms.Label lbl_ChargeTo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}