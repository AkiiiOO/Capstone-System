﻿namespace ILAGAN_Management_System
{
    partial class PrintEquipmentReleaseLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrintEquipmentReleaseLog));
            this.btn_Print = new ILAGAN_Management_System.RoundedButton();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_ReturnDate = new System.Windows.Forms.Label();
            this.lbl_ReleaseDate = new System.Windows.Forms.Label();
            this.lbl_EquipmentType = new System.Windows.Forms.Label();
            this.pnl_PrintEquipmentReleaseLog = new System.Windows.Forms.Panel();
            this.lbl_ReturnedBy = new System.Windows.Forms.Label();
            this.lbl_ReleasedBy = new System.Windows.Forms.Label();
            this.lbl_Quantity = new System.Windows.Forms.Label();
            this.lbl_EquipmentName = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnl_PrintEquipmentReleaseLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_Print
            // 
            this.btn_Print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Print.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Print.BorderRadius = 5;
            this.btn_Print.BorderSize = 0;
            this.btn_Print.FlatAppearance.BorderSize = 0;
            this.btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Print.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Print.ForeColor = System.Drawing.Color.White;
            this.btn_Print.Location = new System.Drawing.Point(322, 28);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(70, 30);
            this.btn_Print.TabIndex = 136;
            this.btn_Print.Text = "Print";
            this.btn_Print.TextColor = System.Drawing.Color.White;
            this.btn_Print.UseVisualStyleBackColor = false;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(89, 16);
            this.label6.TabIndex = 135;
            this.label6.Text = "Release Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 16);
            this.label3.TabIndex = 134;
            this.label3.Text = "Return Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(25, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(155, 15);
            this.label14.TabIndex = 130;
            this.label14.Text = "Equipment Information";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(25, 80);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(104, 16);
            this.label12.TabIndex = 128;
            this.label12.Text = "Equipment Type:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(25, 213);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 126;
            this.label4.Text = "Released By:";
            // 
            // lbl_ReturnDate
            // 
            this.lbl_ReturnDate.AutoSize = true;
            this.lbl_ReturnDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ReturnDate.Location = new System.Drawing.Point(155, 180);
            this.lbl_ReturnDate.Name = "lbl_ReturnDate";
            this.lbl_ReturnDate.Size = new System.Drawing.Size(67, 16);
            this.lbl_ReturnDate.TabIndex = 125;
            this.lbl_ReturnDate.Text = "---------------";
            // 
            // lbl_ReleaseDate
            // 
            this.lbl_ReleaseDate.AutoSize = true;
            this.lbl_ReleaseDate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ReleaseDate.Location = new System.Drawing.Point(155, 145);
            this.lbl_ReleaseDate.Name = "lbl_ReleaseDate";
            this.lbl_ReleaseDate.Size = new System.Drawing.Size(67, 16);
            this.lbl_ReleaseDate.TabIndex = 124;
            this.lbl_ReleaseDate.Text = "---------------";
            // 
            // lbl_EquipmentType
            // 
            this.lbl_EquipmentType.AutoSize = true;
            this.lbl_EquipmentType.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipmentType.Location = new System.Drawing.Point(155, 80);
            this.lbl_EquipmentType.Name = "lbl_EquipmentType";
            this.lbl_EquipmentType.Size = new System.Drawing.Size(67, 16);
            this.lbl_EquipmentType.TabIndex = 123;
            this.lbl_EquipmentType.Text = "---------------";
            // 
            // pnl_PrintEquipmentReleaseLog
            // 
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label6);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label3);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label14);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label12);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label4);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.lbl_ReturnDate);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.lbl_ReleaseDate);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.lbl_EquipmentType);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.lbl_ReturnedBy);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.lbl_ReleasedBy);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.lbl_Quantity);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.lbl_EquipmentName);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label9);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label7);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.label2);
            this.pnl_PrintEquipmentReleaseLog.Controls.Add(this.panel7);
            this.pnl_PrintEquipmentReleaseLog.Location = new System.Drawing.Point(0, 64);
            this.pnl_PrintEquipmentReleaseLog.Name = "pnl_PrintEquipmentReleaseLog";
            this.pnl_PrintEquipmentReleaseLog.Size = new System.Drawing.Size(395, 295);
            this.pnl_PrintEquipmentReleaseLog.TabIndex = 64;
            // 
            // lbl_ReturnedBy
            // 
            this.lbl_ReturnedBy.AutoSize = true;
            this.lbl_ReturnedBy.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ReturnedBy.Location = new System.Drawing.Point(155, 249);
            this.lbl_ReturnedBy.Name = "lbl_ReturnedBy";
            this.lbl_ReturnedBy.Size = new System.Drawing.Size(67, 16);
            this.lbl_ReturnedBy.TabIndex = 117;
            this.lbl_ReturnedBy.Text = "---------------";
            // 
            // lbl_ReleasedBy
            // 
            this.lbl_ReleasedBy.AutoSize = true;
            this.lbl_ReleasedBy.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ReleasedBy.Location = new System.Drawing.Point(155, 213);
            this.lbl_ReleasedBy.Name = "lbl_ReleasedBy";
            this.lbl_ReleasedBy.Size = new System.Drawing.Size(67, 16);
            this.lbl_ReleasedBy.TabIndex = 116;
            this.lbl_ReleasedBy.Text = "---------------";
            // 
            // lbl_Quantity
            // 
            this.lbl_Quantity.AutoSize = true;
            this.lbl_Quantity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Quantity.Location = new System.Drawing.Point(155, 112);
            this.lbl_Quantity.Name = "lbl_Quantity";
            this.lbl_Quantity.Size = new System.Drawing.Size(67, 16);
            this.lbl_Quantity.TabIndex = 115;
            this.lbl_Quantity.Text = "---------------";
            // 
            // lbl_EquipmentName
            // 
            this.lbl_EquipmentName.AutoSize = true;
            this.lbl_EquipmentName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EquipmentName.Location = new System.Drawing.Point(155, 49);
            this.lbl_EquipmentName.Name = "lbl_EquipmentName";
            this.lbl_EquipmentName.Size = new System.Drawing.Size(67, 16);
            this.lbl_EquipmentName.TabIndex = 114;
            this.lbl_EquipmentName.Text = "---------------";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 16);
            this.label9.TabIndex = 111;
            this.label9.Text = "Quantity:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(25, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 16);
            this.label7.TabIndex = 109;
            this.label7.Text = "Returned By:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 16);
            this.label2.TabIndex = 108;
            this.label2.Text = "Equipment Name:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Location = new System.Drawing.Point(25, 34);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(350, 2);
            this.panel7.TabIndex = 103;
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Equipment Release Log";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.btn_Print);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(395, 68);
            this.panel1.TabIndex = 63;
            // 
            // PrintEquipmentReleaseLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 359);
            this.Controls.Add(this.pnl_PrintEquipmentReleaseLog);
            this.Controls.Add(this.panel1);
            this.Name = "PrintEquipmentReleaseLog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PrintEquipmentReleaseLog";
            this.pnl_PrintEquipmentReleaseLog.ResumeLayout(false);
            this.pnl_PrintEquipmentReleaseLog.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private RoundedButton btn_Print;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_ReturnDate;
        private System.Windows.Forms.Label lbl_ReleaseDate;
        private System.Windows.Forms.Label lbl_EquipmentType;
        private System.Windows.Forms.Panel pnl_PrintEquipmentReleaseLog;
        private System.Windows.Forms.Label lbl_ReturnedBy;
        private System.Windows.Forms.Label lbl_ReleasedBy;
        private System.Windows.Forms.Label lbl_Quantity;
        private System.Windows.Forms.Label lbl_EquipmentName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
    }
}