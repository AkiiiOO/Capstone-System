﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ViewUserLogs : Form
    {
        public string LogID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LoginDateTime { get; set; }
        public string LogoutDateTime { get; set; }


        public ViewUserLogs()
        {
            InitializeComponent();
        }


        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_FirstName.Text = FirstName;
            lbl_LastName.Text = LastName;
            lbl_LoginDate.Text = LoginDateTime;
            lbl_LogoutDate.Text = LogoutDateTime;
           
        }


        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_ViewUserLog = pnl;
            getprintarea(pnl_ViewUserLog);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();

        }

        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_ViewUserLog.Width / 2), this.pnl_ViewUserLog.Location.Y);
        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_ViewUserLog);
        }
    }
}
