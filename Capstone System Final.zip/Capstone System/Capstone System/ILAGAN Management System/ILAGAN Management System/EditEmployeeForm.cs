﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class EditEmployeeForm : Form
    {

        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler EmployeeUpdated;

        public string EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string HireDate { get; set; }
        public string ContactNo { get; set; }

       
        public EditEmployeeForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            lbl_EmployeeID.Text = EmployeeID;
            txtFName.Text = FirstName;
            txtLName.Text = LastName;
            lbl_HireDate.Text = HireDate;
            txtContact_no.Text = ContactNo;

        }

        private void EditEmployeeForm_Load(object sender, EventArgs e)
        {

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLName.Text))
            {
                MessageBox.Show("First Name and Last Name are required.", "Validation Error");
                return;
            }

            if (!txtFName.Text.All(char.IsLetter) || !txtLName.Text.All(char.IsLetter))
            {
                MessageBox.Show("First Name and Last Name must contain only alphabetic letters.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!char.IsUpper(txtFName.Text[0]) || !char.IsUpper(txtLName.Text[0]))
            {
                MessageBox.Show("First Name and Last Name must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(txtContact_no.Text) || txtContact_no.Text.Length != 11 || !txtContact_no.Text.All(char.IsDigit))
            {
                MessageBox.Show("Contact Number must be exactly 11 digits.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtContact_no.Focus();
                return;
            }


            db.Open();
            string queryUpdate = @"UPDATE Employees SET FirstName = @FirstName, LastName = @LastName, Contact_No = @Contact_No WHERE EmployeeID = @EmployeeID";
            SqlCommand command = new SqlCommand(queryUpdate, db);
            command.Parameters.AddWithValue("@EmployeeID", EmployeeID);
            command.Parameters.AddWithValue("@FirstName", txtFName.Text);
            command.Parameters.AddWithValue("@LastName", txtLName.Text);
            command.Parameters.AddWithValue("@Contact_No", txtContact_no.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("Employee details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                EmployeeUpdated?.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            else
            {
                MessageBox.Show("Update failed. Employee not found.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }
    }
}
