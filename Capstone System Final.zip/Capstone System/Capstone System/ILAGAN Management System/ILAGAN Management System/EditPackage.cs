﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class EditPackage : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler PackageUpdated;

        public string PackageName { get; set; }
        public string PackageID { get; set; }
        public string CasketName { get; set; }
        public string VehicleName { get; set; }
        public string EmbalmingDays { get; set; }
        public string TotalPrice { get; set; }
        public string CreatedDate { get; set; }

        public EditPackage()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_PackageName.Text = PackageName;
            txt_CasketName.Text = CasketName;
            txt_VehicleName.Text = VehicleName;
            txt_EmbalmingDays.Text = EmbalmingDays;
            lbl_TotalPrice.Text = TotalPrice;
            lbl_CreatedDate.Text = CreatedDate;

        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_CasketName.Text) || string.IsNullOrEmpty(txt_VehicleName.Text))
            {
                MessageBox.Show("Casket Name and Vehicle Name are required.", "Validation Error");
                return;
            }

            if (!char.IsUpper(txt_CasketName.Text[0]) || !char.IsUpper(txt_VehicleName.Text[0]))
            {
                MessageBox.Show("Casket Name and Last Vehicle must start with a capital letter.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
            {
                MessageBox.Show("Embalming days cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_EmbalmingDays.Focus();
                return;
            }

 
            if (!int.TryParse(txt_EmbalmingDays.Text, out int embalmingDays))
            {
                MessageBox.Show("Please enter a valid number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_EmbalmingDays.Focus();
                return;
            }

           
            if (embalmingDays > 30)
            {
                MessageBox.Show("The number of embalming days cannot exceed 30.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_EmbalmingDays.Focus();
                return;
            }

            db.Open();
            string queryUpdate = @"UPDATE Package SET CasketName = @CasketName, VehicleName = @VehicleName, CreatedDate = @CreatedDate, EmbalmingDays = @EmbalmingDays,PackageName = @PackageName, TotalPrice = @TotalPrice WHERE PackageID = @PackageID";
            SqlCommand command = new SqlCommand(queryUpdate, db);
            command.Parameters.AddWithValue("@PackageID", PackageID);
            command.Parameters.AddWithValue("@CasketName", txt_CasketName.Text);
            command.Parameters.AddWithValue("@VehicleName", txt_VehicleName.Text);
            command.Parameters.AddWithValue("@CreatedDate", lbl_CreatedDate.Text);
            command.Parameters.AddWithValue("@EmbalmingDays", txt_EmbalmingDays.Text);
            command.Parameters.AddWithValue("@PackageName", lbl_PackageName.Text);
            command.Parameters.AddWithValue("@TotalPrice", lbl_TotalPrice.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("Client details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                PackageUpdated?.Invoke(this, EventArgs.Empty);
                this.Close();
            }
            else
            {
                MessageBox.Show("Update failed. Client not found.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
