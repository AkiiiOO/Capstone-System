﻿namespace ILAGAN_Management_System
{
    partial class ViewServiceHistory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewServiceHistory));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.pnl_ViewServiceHistory = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_DLName = new System.Windows.Forms.Label();
            this.lbl_DMName = new System.Windows.Forms.Label();
            this.lbl_ServiceStatus = new System.Windows.Forms.Label();
            this.lbl_TotalPrice = new System.Windows.Forms.Label();
            this.lbl_TimeBurial = new System.Windows.Forms.Label();
            this.lbl_DateBurial = new System.Windows.Forms.Label();
            this.lbl_CemeteryLocation = new System.Windows.Forms.Label();
            this.lbl_VehicleName = new System.Windows.Forms.Label();
            this.lbl_CasketName = new System.Windows.Forms.Label();
            this.lbl_PackageName = new System.Windows.Forms.Label();
            this.lbl_DFName = new System.Windows.Forms.Label();
            this.lbl_CName = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btn_Print = new ILAGAN_Management_System.RoundedButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnl_ViewServiceHistory.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Service History";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.btn_Print);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(395, 68);
            this.panel1.TabIndex = 61;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // pnl_ViewServiceHistory
            // 
            this.pnl_ViewServiceHistory.Controls.Add(this.label6);
            this.pnl_ViewServiceHistory.Controls.Add(this.label3);
            this.pnl_ViewServiceHistory.Controls.Add(this.label17);
            this.pnl_ViewServiceHistory.Controls.Add(this.label16);
            this.pnl_ViewServiceHistory.Controls.Add(this.label15);
            this.pnl_ViewServiceHistory.Controls.Add(this.label14);
            this.pnl_ViewServiceHistory.Controls.Add(this.label13);
            this.pnl_ViewServiceHistory.Controls.Add(this.label12);
            this.pnl_ViewServiceHistory.Controls.Add(this.label5);
            this.pnl_ViewServiceHistory.Controls.Add(this.label4);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_DLName);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_DMName);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_ServiceStatus);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_TotalPrice);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_TimeBurial);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_DateBurial);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_CemeteryLocation);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_VehicleName);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_CasketName);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_PackageName);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_DFName);
            this.pnl_ViewServiceHistory.Controls.Add(this.lbl_CName);
            this.pnl_ViewServiceHistory.Controls.Add(this.label10);
            this.pnl_ViewServiceHistory.Controls.Add(this.label11);
            this.pnl_ViewServiceHistory.Controls.Add(this.panel6);
            this.pnl_ViewServiceHistory.Controls.Add(this.panel5);
            this.pnl_ViewServiceHistory.Controls.Add(this.panel4);
            this.pnl_ViewServiceHistory.Controls.Add(this.label9);
            this.pnl_ViewServiceHistory.Controls.Add(this.panel3);
            this.pnl_ViewServiceHistory.Controls.Add(this.label8);
            this.pnl_ViewServiceHistory.Controls.Add(this.label7);
            this.pnl_ViewServiceHistory.Controls.Add(this.label2);
            this.pnl_ViewServiceHistory.Controls.Add(this.panel7);
            this.pnl_ViewServiceHistory.Location = new System.Drawing.Point(0, 64);
            this.pnl_ViewServiceHistory.Name = "pnl_ViewServiceHistory";
            this.pnl_ViewServiceHistory.Size = new System.Drawing.Size(395, 595);
            this.pnl_ViewServiceHistory.TabIndex = 62;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(25, 182);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 16);
            this.label6.TabIndex = 135;
            this.label6.Text = "Middle Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 16);
            this.label3.TabIndex = 134;
            this.label3.Text = "Last Name:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(19, 406);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(124, 15);
            this.label17.TabIndex = 133;
            this.label17.Text = "Burial Information";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(25, 263);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(141, 15);
            this.label16.TabIndex = 132;
            this.label16.Text = "Package Information";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(25, 114);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(150, 15);
            this.label15.TabIndex = 131;
            this.label15.Text = "Deceased Information";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(25, 16);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(124, 15);
            this.label14.TabIndex = 130;
            this.label14.Text = "Client Information";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(25, 562);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 16);
            this.label13.TabIndex = 129;
            this.label13.Text = "Total Price:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(22, 80);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 16);
            this.label12.TabIndex = 128;
            this.label12.Text = "Service Status:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(22, 446);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 16);
            this.label5.TabIndex = 127;
            this.label5.Text = "Date of Burial:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 304);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 16);
            this.label4.TabIndex = 126;
            this.label4.Text = "Package:";
            // 
            // lbl_DLName
            // 
            this.lbl_DLName.AutoSize = true;
            this.lbl_DLName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DLName.Location = new System.Drawing.Point(152, 217);
            this.lbl_DLName.Name = "lbl_DLName";
            this.lbl_DLName.Size = new System.Drawing.Size(67, 16);
            this.lbl_DLName.TabIndex = 125;
            this.lbl_DLName.Text = "---------------";
            // 
            // lbl_DMName
            // 
            this.lbl_DMName.AutoSize = true;
            this.lbl_DMName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DMName.Location = new System.Drawing.Point(152, 182);
            this.lbl_DMName.Name = "lbl_DMName";
            this.lbl_DMName.Size = new System.Drawing.Size(67, 16);
            this.lbl_DMName.TabIndex = 124;
            this.lbl_DMName.Text = "---------------";
            // 
            // lbl_ServiceStatus
            // 
            this.lbl_ServiceStatus.AutoSize = true;
            this.lbl_ServiceStatus.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ServiceStatus.Location = new System.Drawing.Point(155, 80);
            this.lbl_ServiceStatus.Name = "lbl_ServiceStatus";
            this.lbl_ServiceStatus.Size = new System.Drawing.Size(67, 16);
            this.lbl_ServiceStatus.TabIndex = 123;
            this.lbl_ServiceStatus.Text = "---------------";
            // 
            // lbl_TotalPrice
            // 
            this.lbl_TotalPrice.AutoSize = true;
            this.lbl_TotalPrice.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPrice.Location = new System.Drawing.Point(138, 562);
            this.lbl_TotalPrice.Name = "lbl_TotalPrice";
            this.lbl_TotalPrice.Size = new System.Drawing.Size(67, 16);
            this.lbl_TotalPrice.TabIndex = 122;
            this.lbl_TotalPrice.Text = "---------------";
            // 
            // lbl_TimeBurial
            // 
            this.lbl_TimeBurial.AutoSize = true;
            this.lbl_TimeBurial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TimeBurial.Location = new System.Drawing.Point(152, 477);
            this.lbl_TimeBurial.Name = "lbl_TimeBurial";
            this.lbl_TimeBurial.Size = new System.Drawing.Size(67, 16);
            this.lbl_TimeBurial.TabIndex = 121;
            this.lbl_TimeBurial.Text = "---------------";
            // 
            // lbl_DateBurial
            // 
            this.lbl_DateBurial.AutoSize = true;
            this.lbl_DateBurial.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DateBurial.Location = new System.Drawing.Point(152, 446);
            this.lbl_DateBurial.Name = "lbl_DateBurial";
            this.lbl_DateBurial.Size = new System.Drawing.Size(67, 16);
            this.lbl_DateBurial.TabIndex = 120;
            this.lbl_DateBurial.Text = "---------------";
            // 
            // lbl_CemeteryLocation
            // 
            this.lbl_CemeteryLocation.AutoSize = true;
            this.lbl_CemeteryLocation.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CemeteryLocation.Location = new System.Drawing.Point(152, 513);
            this.lbl_CemeteryLocation.Name = "lbl_CemeteryLocation";
            this.lbl_CemeteryLocation.Size = new System.Drawing.Size(67, 16);
            this.lbl_CemeteryLocation.TabIndex = 119;
            this.lbl_CemeteryLocation.Text = "---------------";
            // 
            // lbl_VehicleName
            // 
            this.lbl_VehicleName.AutoSize = true;
            this.lbl_VehicleName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_VehicleName.Location = new System.Drawing.Point(155, 375);
            this.lbl_VehicleName.Name = "lbl_VehicleName";
            this.lbl_VehicleName.Size = new System.Drawing.Size(67, 16);
            this.lbl_VehicleName.TabIndex = 118;
            this.lbl_VehicleName.Text = "---------------";
            // 
            // lbl_CasketName
            // 
            this.lbl_CasketName.AutoSize = true;
            this.lbl_CasketName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CasketName.Location = new System.Drawing.Point(155, 340);
            this.lbl_CasketName.Name = "lbl_CasketName";
            this.lbl_CasketName.Size = new System.Drawing.Size(67, 16);
            this.lbl_CasketName.TabIndex = 117;
            this.lbl_CasketName.Text = "---------------";
            // 
            // lbl_PackageName
            // 
            this.lbl_PackageName.AutoSize = true;
            this.lbl_PackageName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PackageName.Location = new System.Drawing.Point(155, 304);
            this.lbl_PackageName.Name = "lbl_PackageName";
            this.lbl_PackageName.Size = new System.Drawing.Size(67, 16);
            this.lbl_PackageName.TabIndex = 116;
            this.lbl_PackageName.Text = "---------------";
            // 
            // lbl_DFName
            // 
            this.lbl_DFName.AutoSize = true;
            this.lbl_DFName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DFName.Location = new System.Drawing.Point(152, 149);
            this.lbl_DFName.Name = "lbl_DFName";
            this.lbl_DFName.Size = new System.Drawing.Size(67, 16);
            this.lbl_DFName.TabIndex = 115;
            this.lbl_DFName.Text = "---------------";
            // 
            // lbl_CName
            // 
            this.lbl_CName.AutoSize = true;
            this.lbl_CName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CName.Location = new System.Drawing.Point(155, 49);
            this.lbl_CName.Name = "lbl_CName";
            this.lbl_CName.Size = new System.Drawing.Size(67, 16);
            this.lbl_CName.TabIndex = 114;
            this.lbl_CName.Text = "---------------";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(22, 477);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(90, 16);
            this.label10.TabIndex = 113;
            this.label10.Text = "Time of Burial:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(22, 375);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 16);
            this.label11.TabIndex = 112;
            this.label11.Text = "Vehicle:";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DimGray;
            this.panel6.Location = new System.Drawing.Point(22, 547);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(350, 2);
            this.panel6.TabIndex = 106;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DimGray;
            this.panel5.Location = new System.Drawing.Point(22, 424);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(350, 2);
            this.panel5.TabIndex = 105;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Location = new System.Drawing.Point(22, 281);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(350, 2);
            this.panel4.TabIndex = 107;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 149);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 16);
            this.label9.TabIndex = 111;
            this.label9.Text = "First Name:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Location = new System.Drawing.Point(25, 132);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(350, 2);
            this.panel3.TabIndex = 104;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 513);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 16);
            this.label8.TabIndex = 110;
            this.label8.Text = "Cemetery Location:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(22, 340);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 16);
            this.label7.TabIndex = 109;
            this.label7.Text = "Casket:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(25, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 16);
            this.label2.TabIndex = 108;
            this.label2.Text = "Client Name:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Location = new System.Drawing.Point(25, 34);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(350, 2);
            this.panel7.TabIndex = 103;
            // 
            // btn_Print
            // 
            this.btn_Print.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_Print.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Print.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Print.BorderRadius = 5;
            this.btn_Print.BorderSize = 0;
            this.btn_Print.FlatAppearance.BorderSize = 0;
            this.btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Print.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Print.ForeColor = System.Drawing.Color.White;
            this.btn_Print.Location = new System.Drawing.Point(322, 28);
            this.btn_Print.Name = "btn_Print";
            this.btn_Print.Size = new System.Drawing.Size(70, 30);
            this.btn_Print.TabIndex = 136;
            this.btn_Print.Text = "Print";
            this.btn_Print.TextColor = System.Drawing.Color.White;
            this.btn_Print.UseVisualStyleBackColor = false;
            this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
            // 
            // ViewServiceHistory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 658);
            this.Controls.Add(this.pnl_ViewServiceHistory);
            this.Controls.Add(this.panel1);
            this.Name = "ViewServiceHistory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewServiceHistory";
            this.Load += new System.EventHandler(this.ViewServiceHistory_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.pnl_ViewServiceHistory.ResumeLayout(false);
            this.pnl_ViewServiceHistory.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Panel pnl_ViewServiceHistory;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_DLName;
        private System.Windows.Forms.Label lbl_DMName;
        private System.Windows.Forms.Label lbl_ServiceStatus;
        private System.Windows.Forms.Label lbl_TotalPrice;
        private System.Windows.Forms.Label lbl_TimeBurial;
        private System.Windows.Forms.Label lbl_DateBurial;
        private System.Windows.Forms.Label lbl_CemeteryLocation;
        private System.Windows.Forms.Label lbl_VehicleName;
        private System.Windows.Forms.Label lbl_CasketName;
        private System.Windows.Forms.Label lbl_PackageName;
        private System.Windows.Forms.Label lbl_DFName;
        private System.Windows.Forms.Label lbl_CName;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private RoundedButton btn_Print;
    }
}