﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class ServiceRequestPrint : Form
    {

        public string ServiceRequestID { get; set; }
        public string ClientName { get; set; }
        public string DateBurial { get; set; }
        public string TimeBurial { get; set; }
        public string TotalPrice { get; set; }
 

        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;


        public ServiceRequestPrint()
        {
            InitializeComponent();
            db = y.GetConnection();

        }

        private void btn_Print_Click(object sender, EventArgs e)
        {
            print(this.pnl_ServiceRequestPrint);
        }

        private void print(Panel pnl)
        {
            PrinterSettings ps = new PrinterSettings();
            pnl_ServiceRequestPrint = pnl;
            getprintarea(pnl_ServiceRequestPrint);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();
           
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            lbl_ChargeTo.Text = ClientName;
            lbl_DateofBurial.Text = DateBurial;
            lbl_TimeofBurial.Text = TimeBurial;
            lbl_TotalPrice.Text = TotalPrice;
            /*
            lbl_DiscountAmount.Text = DiscountAmount;
            lbl_FinalPrice.Text = FinalPrice;
            lbl_PaymentOption.Text = PaymentOption;
            lbl_RemainingBalance.Text = RemainingBalance;
            lbl_PaymentStatus.Text = PaymentStatus;
            */
        }



        private Bitmap memorying;

        private void getprintarea(Panel pnl)
        {
            memorying = new Bitmap(pnl.Width, pnl.Height);
            pnl.DrawToBitmap(memorying, new Rectangle(0, 0, pnl.Width, pnl.Height));
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(memorying, (pagearea.Width / 2) - (this.pnl_ServiceRequestPrint.Width / 2), this.pnl_ServiceRequestPrint.Location.Y);
        }

        private void ServiceRequestPrint_Load(object sender, EventArgs e)
        {
         
        }
    }
}
