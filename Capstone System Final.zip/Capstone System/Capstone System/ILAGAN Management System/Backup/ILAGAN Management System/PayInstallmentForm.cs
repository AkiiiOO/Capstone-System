﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class PayInstallmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler InstallmentPayed;

        private List<DataGridViewRow> selectedRows;

        int paymentID = 0;
        decimal currentInterestRate = 0;

        public PayInstallmentForm(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            LoadPaymentDetails();
            LoadInstallmentDetails();
        }

        private void LoadPaymentDetails()
        {
            if (selectedRows != null && selectedRows.Count > 0)
            {
                var selectedRow = selectedRows[0];

                string clientName = selectedRow.Cells["Client"].Value.ToString();
                decimal totalPrice = Convert.ToDecimal(selectedRow.Cells["Subtotal"].Value);
                decimal finalPrice = Convert.ToDecimal(selectedRow.Cells["Final Price"].Value);
                string installmentPlan = selectedRow.Cells["Installment Plan"].Value.ToString();
                paymentID = Convert.ToInt32(selectedRow.Cells["PaymentID"].Value);

                lbl_ClientName.Text = clientName;
                lbl_Totalprice.Text = "₱" + totalPrice.ToString("F2"); 
                lbl_FinalPrice.Text = "₱" + finalPrice.ToString("F2");
                lbl_InstallmentPlan.Text = installmentPlan;
            }
            else
            {
                lbl_ClientName.Text = string.Empty;
                lbl_Totalprice.Text = "₱0.00";
                lbl_FinalPrice.Text = "₱0.00";
                lbl_InstallmentPlan.Text = string.Empty;
            }
        }
        private decimal GetCurrentInterestRate()
        {
            decimal interestRate = 0;

            string query = "SELECT TOP 1 InterestRate FROM InterestRate ORDER BY LastUpdated DESC";
            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                if (db.State == ConnectionState.Closed) db.Open();

                try
                {
                    interestRate = Convert.ToDecimal(cmd.ExecuteScalar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching interest rate: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }

            return interestRate;
        }

        private void LoadInstallmentDetails()
        {
            if (selectedRows != null && selectedRows.Count > 0)
            {
                var selectedRow = selectedRows[0];
                DataTable installmentData = new DataTable();

                // SQL query to get installment details based on PaymentID
                string query = @"SELECT i.InstallmentNumber, i.DueDate, i.Amount, i.AmountPaid,ps.PaymentStatusName AS PaymentStatus, i.InstallmentID, i.PaymentStatusID
                                 FROM Installments i
                                 LEFT JOIN PaymentStatus ps ON i.PaymentStatusID = ps.PaymentStatusID
                                 WHERE i.PaymentID = @PaymentID";

                using (SqlCommand cmd = new SqlCommand(query, db))
                {
                    cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                    db.Open();
                    try
                    {

                        using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                        {
                            adapter.Fill(installmentData);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error loading installments: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
                decimal currentInterestRate = GetCurrentInterestRate();
                foreach (DataRow row in installmentData.Rows)
                {
                    DateTime dueDate = Convert.ToDateTime(row["DueDate"]);
                    decimal originalAmount = Convert.ToDecimal(row["Amount"]);

                    if (dueDate < DateTime.Now && Convert.ToInt32(row["PaymentStatusID"]) != 3)
                    {
                        decimal interestAmount = originalAmount * (currentInterestRate / 100);
                        decimal newAmount = originalAmount + interestAmount;
                        row["Amount"] = newAmount;

                        row["PaymentStatus"] = "Overdue";
                    }
                    row["DueDate"] = dueDate.ToString("MMMM/d/yyyy");
                }
                var sortedInstallments = installmentData.AsEnumerable()
            .OrderBy(row => Convert.ToInt32(row["PaymentStatusID"]) == 3) // Paid (3) rows go last
            .ThenBy(row => Convert.ToInt32(row["InstallmentNumber"]))    // Order by installment number within groups
            .CopyToDataTable();

                dgv_Installment.DataSource = sortedInstallments;

                dgv_Installment.Columns["PaymentStatusID"].Visible = false;
                dgv_Installment.Columns["InstallmentID"].Visible = false;
                dgv_Installment.Columns["SelectColumn"].Visible = true;

                dgv_Installment.Columns["InstallmentNumber"].HeaderText = "Installment No.";
                dgv_Installment.Columns["DueDate"].HeaderText = "Installment Due Date";
                dgv_Installment.Columns["Amount"].HeaderText = "Amount";
                dgv_Installment.Columns["PaymentStatus"].HeaderText = "Payment Status";

                dgv_Installment.Columns["DueDate"].DefaultCellStyle.Format = "MMMM/d/yyyy";

            }
        }
        private void txt_AmountPaid_TextChanged(object sender, EventArgs e)
        {
            var selectedInstallments = dgv_Installment.Rows.Cast<DataGridViewRow>()
                .Where(row => Convert.ToBoolean(row.Cells["SelectColumn"].Value) == true).ToList();
            if (selectedInstallments.Count == 0)
            {
                MessageBox.Show("Please select at least one installment to pay.");
                txt_AmountPaid.Clear();
                return;
            }
            if (selectedInstallments.Count > 0)
            {
                decimal totalInstallmentAmount = 0;

                foreach (var selectedInstallment in selectedInstallments)
                {
                    totalInstallmentAmount += Convert.ToDecimal(selectedInstallment.Cells["Amount"].Value);
                    lbl_TotalInstallment.Text = "₱" + totalInstallmentAmount.ToString("F2");
                }

                decimal remainingBalance = totalInstallmentAmount;

                decimal userPaidAmount;
                if (decimal.TryParse(txt_AmountPaid.Text, out userPaidAmount) && userPaidAmount >= 0)
                {
                    decimal newRemainingBalance = remainingBalance - userPaidAmount;

                    lbl_RemainingBalance.Text = newRemainingBalance >= 0 ? "₱" + newRemainingBalance.ToString("F2") : "₱0.00";
                    lbl_Change.Text = newRemainingBalance < 0 ? "₱" + Math.Abs(newRemainingBalance).ToString("F2") : "₱0.00";
                }
                else
                {
                    lbl_RemainingBalance.Text = "₱" + remainingBalance.ToString("F2");
                    lbl_Change.Text = "₱0.00";
                }
            }
            else
            {
                lbl_RemainingBalance.Text = "₱0.00";
                lbl_Change.Text = "₱0.00";
            }
        }
        private bool validation()
        {
            var selectedInstallments = dgv_Installment.Rows.Cast<DataGridViewRow>()
        .Where(row => Convert.ToBoolean(row.Cells["SelectColumn"].Value) == true).ToList();

            if (selectedInstallments.Count == 0)
            {
                MessageBox.Show("Please select at least one installment to pay.");
                return false;
            }

            decimal userPaidAmount;
            if (!decimal.TryParse(txt_AmountPaid.Text, out userPaidAmount) || userPaidAmount <= 0)
            {
                MessageBox.Show("Please enter a valid amount to pay.");
                return false;
            }

            decimal totalInstallmentAmount = selectedInstallments.Sum(row => Convert.ToDecimal(row.Cells["Amount"].Value));

            var unpaidInstallments = dgv_Installment.Rows.Cast<DataGridViewRow>()
                .Where(row => Convert.ToInt32(row.Cells["PaymentStatusID"].Value) != 3)
                .OrderBy(row => Convert.ToDateTime(row.Cells["DueDate"].Value))
                .ToList();

            if (unpaidInstallments.Count == 0)
            {
                MessageBox.Show("All installments are already paid.");
                return false;
            }

            bool hasPaidInstallmentSelected = selectedInstallments.Any(row =>
                Convert.ToInt32(row.Cells["PaymentStatusID"].Value) == 3);

            if (hasPaidInstallmentSelected)
            {
                MessageBox.Show("You have selected an installment that is already paid. Please select unpaid installments only.");
                return false;
            }

            bool skippedInstallment = false;
            foreach (var unpaidInstallment in unpaidInstallments)
            {
                DateTime unpaidDueDate = Convert.ToDateTime(unpaidInstallment.Cells["DueDate"].Value);
                bool isSelected = selectedInstallments.Any(row =>
                    Convert.ToDateTime(row.Cells["DueDate"].Value) == unpaidDueDate);

                if (!isSelected && selectedInstallments.Any(row =>
                        Convert.ToDateTime(row.Cells["DueDate"].Value) > unpaidDueDate))
                {
                    skippedInstallment = true;
                    break;
                }
            }

            if (skippedInstallment)
            {
                MessageBox.Show("You cannot skip an unpaid installment. Please pay all earlier installments first.");
                return false;
            }

            if (userPaidAmount < totalInstallmentAmount)
            {
                MessageBox.Show("The amount entered (" + userPaidAmount.ToString("F2") + ") is less than the total selected installment amount (" + totalInstallmentAmount.ToString("F2") + "). Please enter a valid amount.");
                return false;
            }

            return true;
        }
        private void btn_submitPayment_Click(object sender, EventArgs e)
        {
                if (!validation()) return;
                DialogResult confirmation = MessageBox.Show("Are you sure you want to submit the payment?",
                                                "Confirm Payment",
                                                MessageBoxButtons.YesNo,
                                                MessageBoxIcon.Question);

                if (confirmation == DialogResult.No)
                {
                    return;
                }

                var selectedInstallments = dgv_Installment.Rows.Cast<DataGridViewRow>()
                    .Where(row => Convert.ToBoolean(row.Cells["SelectColumn"].Value) == true)
                    .ToList();

                decimal userPaidAmount = Convert.ToDecimal(txt_AmountPaid.Text);
                decimal remainingUserAmount = userPaidAmount;

                if (db.State == ConnectionState.Closed)
                {
                    db.Open();
                }

                SqlTransaction transaction = null;

                try
                {
                    transaction = db.BeginTransaction();
                    
                    UpdateInstallments(selectedInstallments, ref remainingUserAmount, transaction);
                    UpdatePayment(userPaidAmount, remainingUserAmount, transaction);
                    UpdatePaymentStatus(transaction);

                    transaction.Commit();
                    
                    lbl_Change.Text = remainingUserAmount > 0 ? remainingUserAmount.ToString("F2") : "0.00";
                    lbl_RemainingBalance.Text = "0.00";

                    MessageBox.Show("Payment submitted successfully.");
                    txt_AmountPaid.Text = string.Empty;

                    InstallmentPayed.Invoke(this, EventArgs.Empty);
                }
                catch (Exception ex)
                {
                    if (transaction != null)
                    {
                        transaction.Rollback();
                    }
                    MessageBox.Show("Error processing payment: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                    {
                        db.Close();
                    }
                    LoadInstallmentDetails();
                }
        }
        private void UpdateInstallments(List<DataGridViewRow> selectedInstallments, ref decimal remainingUserAmount, SqlTransaction transaction)
        {
            foreach (var row in selectedInstallments)
            {
                int installmentID = Convert.ToInt32(row.Cells["InstallmentID"].Value);
                decimal installmentAmount = Convert.ToDecimal(row.Cells["Amount"].Value);
                decimal currentAmountPaid = Convert.ToDecimal(row.Cells["AmountPaid"].Value);
                decimal amountDue = installmentAmount - currentAmountPaid;

                // Determine the actual amount to apply for this installment
                decimal amountToPay = Math.Min(amountDue, remainingUserAmount);

                // Update the installment with the amount paid, capping at the due amount
                string updateInstallmentQuery = @"UPDATE Installments SET AmountPaid = AmountPaid + @AmountToPay, 
                                          PaymentStatusID = CASE WHEN AmountPaid + @AmountToPay >= Amount THEN 3 ELSE 2 END, 
                                          PaymentDate = GETDATE()
                                          WHERE InstallmentID = @InstallmentID";

                using (SqlCommand cmd = new SqlCommand(updateInstallmentQuery, db, transaction))
                {
                    cmd.Parameters.AddWithValue("@InstallmentID", installmentID);
                    cmd.Parameters.AddWithValue("@AmountToPay", amountToPay);
                    cmd.ExecuteNonQuery();
                }

                remainingUserAmount -= amountToPay;

                if (remainingUserAmount <= 0)
                {
                    break; // Exit if no remaining amount to apply
                }
            }
        }
        private void UpdatePayment(decimal userPaidAmount, decimal remainingUserAmount, SqlTransaction transaction)
        {
            decimal totalAppliedAmount = userPaidAmount - remainingUserAmount;

            string updatePaymentQuery = @"UPDATE Payments SET AmountPaid += @TotalAppliedAmount, 
                                  RemainingBalance -= @TotalAppliedAmount 
                                  WHERE PaymentID = @PaymentID";

            using (SqlCommand cmd = new SqlCommand(updatePaymentQuery, db, transaction))
            {
                cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                cmd.Parameters.AddWithValue("@TotalAppliedAmount", totalAppliedAmount);
                cmd.ExecuteNonQuery();
            }
        }
        private void UpdatePaymentStatus(SqlTransaction transaction)
        {
            bool allInstallmentsPaid = true;

            string checkInstallmentsQuery = @"SELECT COUNT(*) FROM Installments WHERE PaymentID = @PaymentID AND PaymentStatusID != 3";
            using (SqlCommand cmd = new SqlCommand(checkInstallmentsQuery, db, transaction))
            {
                cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                int unpaidInstallmentsCount = (int)cmd.ExecuteScalar();
                allInstallmentsPaid = (unpaidInstallmentsCount == 0); // If count is 0, all installments are paid
            }

            if (allInstallmentsPaid)
            {
                // Update the payment status to 'Paid'
                string updatePaymentStatusQuery = @"UPDATE Payments 
                                             SET PaymentStatusID = @PaymentStatusID 
                                             WHERE PaymentID = @PaymentID";

                using (SqlCommand cmd = new SqlCommand(updatePaymentStatusQuery, db, transaction))
                {
                    cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                    cmd.Parameters.AddWithValue("@PaymentStatusID", 3); // Mark as paid
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private void dgv_Installment_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgv_Installment.IsCurrentCellDirty)
            {
                dgv_Installment.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }

        private void dgv_Installment_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (dgv_Installment.Columns.Contains("SelectColumn") && e.ColumnIndex == dgv_Installment.Columns["SelectColumn"].Index)
            {
                decimal totalInstallmentAmount = 0;

                foreach (DataGridViewRow row in dgv_Installment.Rows)
                {
                    if (row.Cells["SelectColumn"].Value != null && Convert.ToBoolean(row.Cells["SelectColumn"].Value) == true)
                    {
                        if (row.Cells["Amount"].Value != null)
                        {
                            DateTime dueDate = Convert.ToDateTime(row.Cells["DueDate"].Value);
                            decimal originalAmount = Convert.ToDecimal(row.Cells["Amount"].Value);

                            if (dueDate < DateTime.Now)
                            {
                                // Apply interest for overdue installments
                                decimal interestAmount = originalAmount * (currentInterestRate / 100);
                                totalInstallmentAmount += originalAmount + interestAmount;
                            }
                            else
                            {
                                totalInstallmentAmount += originalAmount;
                            }

                        }
                    }
                }
                lbl_TotalInstallment.Text =  "₱" + totalInstallmentAmount.ToString("F2");
            }
        }
    }
}
