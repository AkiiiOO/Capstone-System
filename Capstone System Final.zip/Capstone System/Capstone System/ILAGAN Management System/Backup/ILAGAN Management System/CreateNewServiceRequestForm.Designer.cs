﻿namespace ILAGAN_Management_System
{
    partial class CreateNewServiceRequestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_DFname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_DMname = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_DLname = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtp_burialdate = new System.Windows.Forms.DateTimePicker();
            this.dtp_burialtime = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.cmb_CemeteryLocation = new System.Windows.Forms.ComboBox();
            this.lbl_TotalPrice = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.dgv_PackageDetails = new System.Windows.Forms.DataGridView();
            this.lbl_DiscountedPrice = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lbl_SubTotal = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txt_ServiceLocation = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.lbl_FirstName = new System.Windows.Forms.Label();
            this.lbl_MiddleName = new System.Windows.Forms.Label();
            this.lbl_LastName = new System.Windows.Forms.Label();
            this.lbl_Address = new System.Windows.Forms.Label();
            this.chb_DeathCertificate = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_ChapelPrice = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.lbl_PakcagePrice = new System.Windows.Forms.Label();
            this.cmb_Discount = new System.Windows.Forms.ComboBox();
            this.picb_documents = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_CancelPackage = new ILAGAN_Management_System.RoundedButton();
            this.btn_ClearDiscount = new ILAGAN_Management_System.RoundedButton();
            this.btn_Canacel = new ILAGAN_Management_System.RoundedButton();
            this.btn_Package = new ILAGAN_Management_System.RoundedButton();
            this.btn_Reservation = new ILAGAN_Management_System.RoundedButton();
            this.btn_Browse = new ILAGAN_Management_System.RoundedButton();
            this.btn_View = new ILAGAN_Management_System.RoundedButton();
            this.btn_Upload = new ILAGAN_Management_System.RoundedButton();
            this.btnAdd = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PackageDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_documents)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(855, 68);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Create New Service Request";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(28, 92);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(380, 2);
            this.panel2.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Location = new System.Drawing.Point(28, 256);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(380, 2);
            this.panel3.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 33;
            this.label2.Text = "First Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 35;
            this.label3.Text = "Middle Name:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 39;
            this.label5.Text = "Last Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 41;
            this.label4.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SeaGreen;
            this.label6.Location = new System.Drawing.Point(29, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 16);
            this.label6.TabIndex = 43;
            this.label6.Text = "Client Details";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SeaGreen;
            this.label7.Location = new System.Drawing.Point(29, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 16);
            this.label7.TabIndex = 44;
            this.label7.Text = "Deseased Information";
            // 
            // txt_DFname
            // 
            this.txt_DFname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DFname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DFname.Location = new System.Drawing.Point(176, 263);
            this.txt_DFname.Name = "txt_DFname";
            this.txt_DFname.Size = new System.Drawing.Size(215, 25);
            this.txt_DFname.TabIndex = 47;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(29, 266);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 16);
            this.label9.TabIndex = 46;
            this.label9.Text = "First Name:";
            // 
            // txt_DMname
            // 
            this.txt_DMname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DMname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DMname.Location = new System.Drawing.Point(176, 294);
            this.txt_DMname.Name = "txt_DMname";
            this.txt_DMname.Size = new System.Drawing.Size(215, 25);
            this.txt_DMname.TabIndex = 49;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(29, 297);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 16);
            this.label10.TabIndex = 48;
            this.label10.Text = "Middle Name:";
            // 
            // txt_DLname
            // 
            this.txt_DLname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DLname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DLname.Location = new System.Drawing.Point(176, 325);
            this.txt_DLname.Name = "txt_DLname";
            this.txt_DLname.Size = new System.Drawing.Size(215, 25);
            this.txt_DLname.TabIndex = 51;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(29, 328);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 16);
            this.label11.TabIndex = 50;
            this.label11.Text = "Last Name:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(437, 167);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 16);
            this.label12.TabIndex = 52;
            this.label12.Text = "Cementery Location:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(439, 195);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 16);
            this.label13.TabIndex = 54;
            this.label13.Text = "Burial Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(439, 226);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 16);
            this.label14.TabIndex = 56;
            this.label14.Text = "Burial Time:";
            // 
            // dtp_burialdate
            // 
            this.dtp_burialdate.CustomFormat = "MMMM/d/yyyy";
            this.dtp_burialdate.Font = new System.Drawing.Font("Arial", 9.75F);
            this.dtp_burialdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_burialdate.Location = new System.Drawing.Point(571, 197);
            this.dtp_burialdate.Name = "dtp_burialdate";
            this.dtp_burialdate.Size = new System.Drawing.Size(157, 22);
            this.dtp_burialdate.TabIndex = 58;
            // 
            // dtp_burialtime
            // 
            this.dtp_burialtime.CustomFormat = "dd/MM/yyyy";
            this.dtp_burialtime.Font = new System.Drawing.Font("Arial", 9.75F);
            this.dtp_burialtime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_burialtime.Location = new System.Drawing.Point(571, 221);
            this.dtp_burialtime.Name = "dtp_burialtime";
            this.dtp_burialtime.Size = new System.Drawing.Size(157, 22);
            this.dtp_burialtime.TabIndex = 59;
            this.dtp_burialtime.Value = new System.DateTime(2024, 9, 29, 21, 1, 0, 0);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.SeaGreen;
            this.label15.Location = new System.Drawing.Point(29, 369);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 16);
            this.label15.TabIndex = 70;
            this.label15.Text = "Document";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DimGray;
            this.panel5.Location = new System.Drawing.Point(28, 388);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(380, 2);
            this.panel5.TabIndex = 69;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(439, 576);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 16);
            this.label21.TabIndex = 78;
            this.label21.Text = "Total Price:";
            // 
            // cmb_CemeteryLocation
            // 
            this.cmb_CemeteryLocation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_CemeteryLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_CemeteryLocation.FormattingEnabled = true;
            this.cmb_CemeteryLocation.Location = new System.Drawing.Point(571, 162);
            this.cmb_CemeteryLocation.Name = "cmb_CemeteryLocation";
            this.cmb_CemeteryLocation.Size = new System.Drawing.Size(233, 26);
            this.cmb_CemeteryLocation.TabIndex = 80;
            // 
            // lbl_TotalPrice
            // 
            this.lbl_TotalPrice.AutoSize = true;
            this.lbl_TotalPrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPrice.Location = new System.Drawing.Point(556, 574);
            this.lbl_TotalPrice.Name = "lbl_TotalPrice";
            this.lbl_TotalPrice.Size = new System.Drawing.Size(128, 18);
            this.lbl_TotalPrice.TabIndex = 179;
            this.lbl_TotalPrice.Text = "********************";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DimGray;
            this.panel6.Location = new System.Drawing.Point(442, 92);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 2);
            this.panel6.TabIndex = 180;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.SeaGreen;
            this.label22.Location = new System.Drawing.Point(439, 73);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(103, 16);
            this.label22.TabIndex = 181;
            this.label22.Text = "Service Details";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(437, 105);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(102, 16);
            this.label23.TabIndex = 182;
            this.label23.Text = "Reserve Chapel:";
            // 
            // dgv_PackageDetails
            // 
            this.dgv_PackageDetails.AllowUserToAddRows = false;
            this.dgv_PackageDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_PackageDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_PackageDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_PackageDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_PackageDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_PackageDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_PackageDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PackageDetails.Location = new System.Drawing.Point(537, 263);
            this.dgv_PackageDetails.Name = "dgv_PackageDetails";
            this.dgv_PackageDetails.ReadOnly = true;
            this.dgv_PackageDetails.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_PackageDetails.RowHeadersVisible = false;
            this.dgv_PackageDetails.Size = new System.Drawing.Size(303, 167);
            this.dgv_PackageDetails.TabIndex = 186;
            // 
            // lbl_DiscountedPrice
            // 
            this.lbl_DiscountedPrice.AutoSize = true;
            this.lbl_DiscountedPrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DiscountedPrice.Location = new System.Drawing.Point(556, 545);
            this.lbl_DiscountedPrice.Name = "lbl_DiscountedPrice";
            this.lbl_DiscountedPrice.Size = new System.Drawing.Size(128, 18);
            this.lbl_DiscountedPrice.TabIndex = 190;
            this.lbl_DiscountedPrice.Text = "********************";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(439, 547);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(111, 16);
            this.label19.TabIndex = 189;
            this.label19.Text = "Discounted Price:";
            // 
            // lbl_SubTotal
            // 
            this.lbl_SubTotal.AutoSize = true;
            this.lbl_SubTotal.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SubTotal.Location = new System.Drawing.Point(556, 491);
            this.lbl_SubTotal.Name = "lbl_SubTotal";
            this.lbl_SubTotal.Size = new System.Drawing.Size(128, 18);
            this.lbl_SubTotal.TabIndex = 192;
            this.lbl_SubTotal.Text = "********************";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(439, 493);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 16);
            this.label18.TabIndex = 191;
            this.label18.Text = "SubTotal:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.SeaGreen;
            this.label20.Location = new System.Drawing.Point(437, 433);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(130, 16);
            this.label20.TabIndex = 194;
            this.label20.Text = "Pricing Information";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Location = new System.Drawing.Point(440, 452);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(400, 2);
            this.panel7.TabIndex = 181;
            // 
            // txt_ServiceLocation
            // 
            this.txt_ServiceLocation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ServiceLocation.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ServiceLocation.Location = new System.Drawing.Point(571, 131);
            this.txt_ServiceLocation.Name = "txt_ServiceLocation";
            this.txt_ServiceLocation.Size = new System.Drawing.Size(215, 25);
            this.txt_ServiceLocation.TabIndex = 196;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(437, 134);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(111, 16);
            this.label24.TabIndex = 195;
            this.label24.Text = "Service Location: ";
            // 
            // lbl_FirstName
            // 
            this.lbl_FirstName.AutoSize = true;
            this.lbl_FirstName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FirstName.Location = new System.Drawing.Point(130, 105);
            this.lbl_FirstName.Name = "lbl_FirstName";
            this.lbl_FirstName.Size = new System.Drawing.Size(188, 18);
            this.lbl_FirstName.TabIndex = 197;
            this.lbl_FirstName.Text = "____________________";
            // 
            // lbl_MiddleName
            // 
            this.lbl_MiddleName.AutoSize = true;
            this.lbl_MiddleName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MiddleName.Location = new System.Drawing.Point(130, 136);
            this.lbl_MiddleName.Name = "lbl_MiddleName";
            this.lbl_MiddleName.Size = new System.Drawing.Size(188, 18);
            this.lbl_MiddleName.TabIndex = 198;
            this.lbl_MiddleName.Text = "____________________";
            // 
            // lbl_LastName
            // 
            this.lbl_LastName.AutoSize = true;
            this.lbl_LastName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LastName.Location = new System.Drawing.Point(130, 167);
            this.lbl_LastName.Name = "lbl_LastName";
            this.lbl_LastName.Size = new System.Drawing.Size(188, 18);
            this.lbl_LastName.TabIndex = 201;
            this.lbl_LastName.Text = "____________________";
            // 
            // lbl_Address
            // 
            this.lbl_Address.AutoSize = true;
            this.lbl_Address.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Address.Location = new System.Drawing.Point(130, 198);
            this.lbl_Address.Name = "lbl_Address";
            this.lbl_Address.Size = new System.Drawing.Size(188, 18);
            this.lbl_Address.TabIndex = 202;
            this.lbl_Address.Text = "____________________";
            // 
            // chb_DeathCertificate
            // 
            this.chb_DeathCertificate.AutoSize = true;
            this.chb_DeathCertificate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chb_DeathCertificate.Location = new System.Drawing.Point(52, 407);
            this.chb_DeathCertificate.Name = "chb_DeathCertificate";
            this.chb_DeathCertificate.Size = new System.Drawing.Size(123, 20);
            this.chb_DeathCertificate.TabIndex = 204;
            this.chb_DeathCertificate.Text = "Death Certificate";
            this.chb_DeathCertificate.UseVisualStyleBackColor = true;
            this.chb_DeathCertificate.CheckedChanged += new System.EventHandler(this.chb_DeathCertificate_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(439, 518);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 16);
            this.label17.TabIndex = 187;
            this.label17.Text = "Discount:";
            // 
            // lbl_ChapelPrice
            // 
            this.lbl_ChapelPrice.AutoSize = true;
            this.lbl_ChapelPrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChapelPrice.Location = new System.Drawing.Point(531, 463);
            this.lbl_ChapelPrice.Name = "lbl_ChapelPrice";
            this.lbl_ChapelPrice.Size = new System.Drawing.Size(98, 18);
            this.lbl_ChapelPrice.TabIndex = 209;
            this.lbl_ChapelPrice.Text = "***************";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(439, 465);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 16);
            this.label16.TabIndex = 208;
            this.label16.Text = "Chapel Price:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(635, 465);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(97, 16);
            this.label26.TabIndex = 210;
            this.label26.Text = "Package Price:";
            // 
            // lbl_PakcagePrice
            // 
            this.lbl_PakcagePrice.AutoSize = true;
            this.lbl_PakcagePrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PakcagePrice.Location = new System.Drawing.Point(738, 463);
            this.lbl_PakcagePrice.Name = "lbl_PakcagePrice";
            this.lbl_PakcagePrice.Size = new System.Drawing.Size(98, 18);
            this.lbl_PakcagePrice.TabIndex = 211;
            this.lbl_PakcagePrice.Text = "***************";
            // 
            // cmb_Discount
            // 
            this.cmb_Discount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Discount.FormattingEnabled = true;
            this.cmb_Discount.Location = new System.Drawing.Point(559, 513);
            this.cmb_Discount.Name = "cmb_Discount";
            this.cmb_Discount.Size = new System.Drawing.Size(184, 26);
            this.cmb_Discount.TabIndex = 212;
            this.cmb_Discount.SelectedIndexChanged += new System.EventHandler(this.cmb_Discount_SelectedIndexChanged);
            // 
            // picb_documents
            // 
            this.picb_documents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.picb_documents.Location = new System.Drawing.Point(47, 433);
            this.picb_documents.Name = "picb_documents";
            this.picb_documents.Size = new System.Drawing.Size(221, 161);
            this.picb_documents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_documents.TabIndex = 74;
            this.picb_documents.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btn_CancelPackage
            // 
            this.btn_CancelPackage.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_CancelPackage.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_CancelPackage.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_CancelPackage.BorderRadius = 5;
            this.btn_CancelPackage.BorderSize = 0;
            this.btn_CancelPackage.FlatAppearance.BorderSize = 0;
            this.btn_CancelPackage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CancelPackage.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CancelPackage.ForeColor = System.Drawing.Color.White;
            this.btn_CancelPackage.Location = new System.Drawing.Point(439, 320);
            this.btn_CancelPackage.Name = "btn_CancelPackage";
            this.btn_CancelPackage.Size = new System.Drawing.Size(86, 30);
            this.btn_CancelPackage.TabIndex = 214;
            this.btn_CancelPackage.Text = "Cancel";
            this.btn_CancelPackage.TextColor = System.Drawing.Color.White;
            this.btn_CancelPackage.UseVisualStyleBackColor = false;
            this.btn_CancelPackage.Click += new System.EventHandler(this.btn_CancelPackage_Click);
            // 
            // btn_ClearDiscount
            // 
            this.btn_ClearDiscount.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_ClearDiscount.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_ClearDiscount.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ClearDiscount.BorderRadius = 5;
            this.btn_ClearDiscount.BorderSize = 0;
            this.btn_ClearDiscount.FlatAppearance.BorderSize = 0;
            this.btn_ClearDiscount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ClearDiscount.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ClearDiscount.ForeColor = System.Drawing.Color.White;
            this.btn_ClearDiscount.Location = new System.Drawing.Point(749, 509);
            this.btn_ClearDiscount.Name = "btn_ClearDiscount";
            this.btn_ClearDiscount.Size = new System.Drawing.Size(66, 30);
            this.btn_ClearDiscount.TabIndex = 213;
            this.btn_ClearDiscount.Text = "Clear";
            this.btn_ClearDiscount.TextColor = System.Drawing.Color.White;
            this.btn_ClearDiscount.UseVisualStyleBackColor = false;
            this.btn_ClearDiscount.Click += new System.EventHandler(this.btn_ClearDiscount_Click);
            // 
            // btn_Canacel
            // 
            this.btn_Canacel.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Canacel.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Canacel.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Canacel.BorderRadius = 5;
            this.btn_Canacel.BorderSize = 0;
            this.btn_Canacel.FlatAppearance.BorderSize = 0;
            this.btn_Canacel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Canacel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Canacel.ForeColor = System.Drawing.Color.White;
            this.btn_Canacel.Location = new System.Drawing.Point(673, 98);
            this.btn_Canacel.Name = "btn_Canacel";
            this.btn_Canacel.Size = new System.Drawing.Size(70, 30);
            this.btn_Canacel.TabIndex = 203;
            this.btn_Canacel.Text = "Cancel";
            this.btn_Canacel.TextColor = System.Drawing.Color.White;
            this.btn_Canacel.UseVisualStyleBackColor = false;
            this.btn_Canacel.Click += new System.EventHandler(this.btn_Canacel_Click);
            // 
            // btn_Package
            // 
            this.btn_Package.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Package.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Package.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Package.BorderRadius = 5;
            this.btn_Package.BorderSize = 0;
            this.btn_Package.FlatAppearance.BorderSize = 0;
            this.btn_Package.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Package.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Package.ForeColor = System.Drawing.Color.White;
            this.btn_Package.Location = new System.Drawing.Point(439, 263);
            this.btn_Package.Name = "btn_Package";
            this.btn_Package.Size = new System.Drawing.Size(85, 31);
            this.btn_Package.TabIndex = 185;
            this.btn_Package.Text = "Package";
            this.btn_Package.TextColor = System.Drawing.Color.White;
            this.btn_Package.UseVisualStyleBackColor = false;
            this.btn_Package.Click += new System.EventHandler(this.btn_CustomizePackage_Click_1);
            // 
            // btn_Reservation
            // 
            this.btn_Reservation.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Reservation.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Reservation.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Reservation.BorderRadius = 5;
            this.btn_Reservation.BorderSize = 0;
            this.btn_Reservation.FlatAppearance.BorderSize = 0;
            this.btn_Reservation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reservation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reservation.ForeColor = System.Drawing.Color.White;
            this.btn_Reservation.Location = new System.Drawing.Point(571, 98);
            this.btn_Reservation.Name = "btn_Reservation";
            this.btn_Reservation.Size = new System.Drawing.Size(96, 30);
            this.btn_Reservation.TabIndex = 184;
            this.btn_Reservation.Text = "Reserve";
            this.btn_Reservation.TextColor = System.Drawing.Color.White;
            this.btn_Reservation.UseVisualStyleBackColor = false;
            this.btn_Reservation.Click += new System.EventHandler(this.btn_Reservation_Click);
            // 
            // btn_Browse
            // 
            this.btn_Browse.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Browse.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Browse.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Browse.BorderRadius = 5;
            this.btn_Browse.BorderSize = 0;
            this.btn_Browse.FlatAppearance.BorderSize = 0;
            this.btn_Browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Browse.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse.ForeColor = System.Drawing.Color.White;
            this.btn_Browse.Location = new System.Drawing.Point(321, 192);
            this.btn_Browse.Name = "btn_Browse";
            this.btn_Browse.Size = new System.Drawing.Size(70, 30);
            this.btn_Browse.TabIndex = 82;
            this.btn_Browse.Text = "Browse";
            this.btn_Browse.TextColor = System.Drawing.Color.White;
            this.btn_Browse.UseVisualStyleBackColor = false;
            this.btn_Browse.Click += new System.EventHandler(this.btn_Browse_Click);
            // 
            // btn_View
            // 
            this.btn_View.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_View.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_View.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_View.BorderRadius = 5;
            this.btn_View.BorderSize = 0;
            this.btn_View.FlatAppearance.BorderSize = 0;
            this.btn_View.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_View.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View.ForeColor = System.Drawing.Color.White;
            this.btn_View.Location = new System.Drawing.Point(291, 564);
            this.btn_View.Name = "btn_View";
            this.btn_View.Size = new System.Drawing.Size(70, 30);
            this.btn_View.TabIndex = 81;
            this.btn_View.Text = "View";
            this.btn_View.TextColor = System.Drawing.Color.White;
            this.btn_View.UseVisualStyleBackColor = false;
            this.btn_View.Click += new System.EventHandler(this.btn_View_Click);
            // 
            // btn_Upload
            // 
            this.btn_Upload.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Upload.BorderRadius = 5;
            this.btn_Upload.BorderSize = 0;
            this.btn_Upload.FlatAppearance.BorderSize = 0;
            this.btn_Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Upload.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Upload.ForeColor = System.Drawing.Color.White;
            this.btn_Upload.Location = new System.Drawing.Point(291, 504);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(70, 30);
            this.btn_Upload.TabIndex = 73;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.TextColor = System.Drawing.Color.White;
            this.btn_Upload.UseVisualStyleBackColor = false;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnAdd.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnAdd.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnAdd.BorderRadius = 5;
            this.btnAdd.BorderSize = 0;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(772, 574);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(70, 30);
            this.btnAdd.TabIndex = 67;
            this.btnAdd.Text = "Save";
            this.btnAdd.TextColor = System.Drawing.Color.White;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // CreateNewServiceRequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(855, 616);
            this.Controls.Add(this.btn_CancelPackage);
            this.Controls.Add(this.btn_ClearDiscount);
            this.Controls.Add(this.cmb_Discount);
            this.Controls.Add(this.lbl_PakcagePrice);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.lbl_ChapelPrice);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.chb_DeathCertificate);
            this.Controls.Add(this.btn_Canacel);
            this.Controls.Add(this.lbl_Address);
            this.Controls.Add(this.lbl_LastName);
            this.Controls.Add(this.lbl_MiddleName);
            this.Controls.Add(this.lbl_FirstName);
            this.Controls.Add(this.txt_ServiceLocation);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.lbl_SubTotal);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lbl_DiscountedPrice);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dgv_PackageDetails);
            this.Controls.Add(this.btn_Package);
            this.Controls.Add(this.btn_Reservation);
            this.Controls.Add(this.lbl_TotalPrice);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.btn_Browse);
            this.Controls.Add(this.btn_View);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cmb_CemeteryLocation);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.picb_documents);
            this.Controls.Add(this.btn_Upload);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dtp_burialtime);
            this.Controls.Add(this.dtp_burialdate);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_DLname);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_DMname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_DFname);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "CreateNewServiceRequestForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateNewServiceRequestForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateNewServiceRequestForm_FormClosing);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PackageDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_documents)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_DFname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_DMname;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_DLname;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtp_burialdate;
        private System.Windows.Forms.DateTimePicker dtp_burialtime;
        private RoundedButton btnAdd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel5;
        private RoundedButton btn_Upload;
        private System.Windows.Forms.PictureBox picb_documents;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmb_CemeteryLocation;
        private RoundedButton btn_View;
        private RoundedButton btn_Browse;
        private System.Windows.Forms.Label lbl_TotalPrice;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private RoundedButton btn_Reservation;
        private RoundedButton btn_Package;
        private System.Windows.Forms.DataGridView dgv_PackageDetails;
        private System.Windows.Forms.Label lbl_DiscountedPrice;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lbl_SubTotal;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txt_ServiceLocation;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lbl_FirstName;
        private System.Windows.Forms.Label lbl_MiddleName;
        private System.Windows.Forms.Label lbl_LastName;
        private System.Windows.Forms.Label lbl_Address;
        private RoundedButton btn_Canacel;
        private System.Windows.Forms.CheckBox chb_DeathCertificate;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbl_ChapelPrice;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lbl_PakcagePrice;
        private System.Windows.Forms.ComboBox cmb_Discount;
        private RoundedButton btn_ClearDiscount;
        private RoundedButton btn_CancelPackage;
    }
}