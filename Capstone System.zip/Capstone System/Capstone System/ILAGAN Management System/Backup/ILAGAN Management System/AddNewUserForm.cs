﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewUserForm : Form
    {
        public event EventHandler UserAdded;

        public AddNewUserForm()
        {
            InitializeComponent();
        }

        private void AddNewUserForm_Load(object sender, EventArgs e)
        {
            cmb_UserAccessLevel.Items.Add("Admin");
            cmb_UserAccessLevel.Items.Add("Service");
            cmb_UserAccessLevel.Items.Add("Inventory");
            cmb_UserAccessLevel.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_UserAccessLevel.FormattingEnabled = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection x = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
            x.Open();
            SqlCommand com = new SqlCommand("INSERT INTO tbl_Users (Username, Password, FirstName, LastName, Email, PhoneNum﻿ber, AccessLevel, Status) VALUES (@Username, @Password, @FirstName, @LastName, @Email, @PhoneNum﻿ber, @AccessLevel, @Status);", x);

            com.Parameters.AddWithValue("@Username", txtUsername.Text);
            com.Parameters.AddWithValue("@Password", txtPassword.Text);
            com.Parameters.AddWithValue("@FirstName", txtFName.Text);
            com.Parameters.AddWithValue("@LastName", txtLastName.Text);
            com.Parameters.AddWithValue("@Email", txtEmail.Text);
            com.Parameters.AddWithValue("@PhoneNum﻿ber", long.Parse(txtPhoneNumber.Text));
            com.Parameters.AddWithValue("@AccessLevel", cmb_UserAccessLevel.Text);
            com.Parameters.AddWithValue("@Status", "Active");
            com.ExecuteNonQuery();

            MessageBox.Show("Successfully added!! ");
            txtUsername.Clear();
            txtPassword.Clear();
            txtFName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            txtPhoneNumber.Clear();
            cmb_UserAccessLevel.SelectedIndex = -1;

            UserAdded.Invoke(this, EventArgs.Empty);
            x.Close();
        }
    }
}
