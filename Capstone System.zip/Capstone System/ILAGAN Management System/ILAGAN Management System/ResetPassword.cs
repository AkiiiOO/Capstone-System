﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace ILAGAN_Management_System
{
    public partial class ResetPassword : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        private string username;
        private ForgotPassword forgotPasswordForm;

        public ResetPassword(string username, ForgotPassword forgotPassword)
        {
            InitializeComponent();
            this.username = username;
            forgotPasswordForm = forgotPassword;
            db = y.GetConnection();
        }

        private void btn_ResetPassword_Click(object sender, EventArgs e)
        {
            string newPassword = txt_NewPass.Text;
            string confirmPassword = txt_ConfirmPass.Text;
            if (!ValidatePassword(newPassword, confirmPassword))
            {
                return;
            }
            string hashedPassword = HashPassword(newPassword);

            if (UpdatePasswordInDatabase(hashedPassword))
            {
                MessageBox.Show("Password reset successfully, You can now Login to the system.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                forgotPasswordForm.Close();
            }
            else
            {
                MessageBox.Show("An error occurred while resetting the password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool ValidatePassword(string newPassword, string confirmPassword)
        {
            if (string.IsNullOrEmpty(newPassword) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("Password fields cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (newPassword.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters long.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            if (newPassword != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            return true;
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        private bool UpdatePasswordInDatabase(string hashedPassword)
        {
            try
            {
                string query = "UPDATE Users SET Password = @Password WHERE Username = @Username";

                SqlCommand cmd = new SqlCommand(query, db);
                cmd.Parameters.AddWithValue("@Password", hashedPassword);
                cmd.Parameters.AddWithValue("@Username", username);

                y.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                y.Close();

                return rowsAffected > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating password: " + ex.Message);
                return false;
            }
        }


    }
}
