﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ManageUserStatus : Form
    {
        public event EventHandler UpdateStatus;

        public ManageUserStatus()
        {
            InitializeComponent();
        }

        private void ManageUserStatus_Load(object sender, EventArgs e)
        {
            cmb_Status.Items.Add("Active");
            cmb_Status.Items.Add("Deactivated");
            cmb_Status.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_Status.FormattingEnabled = true;
        }

        private void btn_UpdateStatus_Click(object sender, EventArgs e)
        {
            SqlConnection y = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
            y.Open();
            string query = "UPDATE tbl_Users SET Status = @Status WHERE Username = @Username";
            SqlCommand command = new SqlCommand(query, y);

            command.Parameters.AddWithValue("@Status", cmb_Status.Text);
            command.Parameters.AddWithValue("@Username", txtUsername.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("User status updated successfully.");
                UpdateStatus.Invoke(this, EventArgs.Empty);
            }
            else
            {
                MessageBox.Show("User not found.");
            }
        }

        private void btn_Disable_Click(object sender, EventArgs e)
        {

        }
    }
}
