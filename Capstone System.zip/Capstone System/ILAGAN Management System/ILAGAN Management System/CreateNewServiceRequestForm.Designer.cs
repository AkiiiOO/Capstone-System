﻿namespace ILAGAN_Management_System
{
    partial class CreateNewServiceRequestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_MiddleInitial = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgv_PackageDetails = new System.Windows.Forms.DataGridView();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Address = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_DFname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_DMname = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_DLname = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtp_burialdate = new System.Windows.Forms.DateTimePicker();
            this.dtp_burialtime = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.cmb_Package = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cmb_DocumentType = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.cmb_CemeteryLocation = new System.Windows.Forms.ComboBox();
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl_Price = new System.Windows.Forms.Label();
            this.picb_documents = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_Browse = new ILAGAN_Management_System.RoundedButton();
            this.btn_View = new ILAGAN_Management_System.RoundedButton();
            this.btn_Upload = new ILAGAN_Management_System.RoundedButton();
            this.btnAdd = new ILAGAN_Management_System.RoundedButton();
            this.btn_CustomizePackage = new ILAGAN_Management_System.RoundedButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.cmb_ServiceType = new System.Windows.Forms.ComboBox();
            this.btn_Reservation = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PackageDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_documents)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(895, 68);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Create New Service Request";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(28, 92);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 2);
            this.panel2.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Location = new System.Drawing.Point(25, 328);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 2);
            this.panel3.TabIndex = 15;
            // 
            // txtFName
            // 
            this.txtFName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFName.Location = new System.Drawing.Point(128, 104);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(215, 25);
            this.txtFName.TabIndex = 34;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 33;
            this.label2.Text = "First Name:";
            // 
            // txt_MiddleInitial
            // 
            this.txt_MiddleInitial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_MiddleInitial.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MiddleInitial.Location = new System.Drawing.Point(128, 135);
            this.txt_MiddleInitial.Name = "txt_MiddleInitial";
            this.txt_MiddleInitial.Size = new System.Drawing.Size(70, 25);
            this.txt_MiddleInitial.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 16);
            this.label3.TabIndex = 35;
            this.label3.Text = "Middle Initial:";
            // 
            // dgv_PackageDetails
            // 
            this.dgv_PackageDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv_PackageDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_PackageDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_PackageDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_PackageDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_PackageDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_PackageDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PackageDetails.Location = new System.Drawing.Point(690, 363);
            this.dgv_PackageDetails.Name = "dgv_PackageDetails";
            this.dgv_PackageDetails.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_PackageDetails.RowHeadersVisible = false;
            this.dgv_PackageDetails.Size = new System.Drawing.Size(151, 132);
            this.dgv_PackageDetails.TabIndex = 37;
            this.dgv_PackageDetails.Click += new System.EventHandler(this.dgv_ClientsRecords_Click);
            // 
            // txtLName
            // 
            this.txtLName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLName.Location = new System.Drawing.Point(128, 166);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(215, 25);
            this.txtLName.TabIndex = 40;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 39;
            this.label5.Text = "Last Name:";
            // 
            // txt_Address
            // 
            this.txt_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Address.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Address.Location = new System.Drawing.Point(128, 197);
            this.txt_Address.Name = "txt_Address";
            this.txt_Address.Size = new System.Drawing.Size(215, 25);
            this.txt_Address.TabIndex = 42;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 41;
            this.label4.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(191, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 16);
            this.label6.TabIndex = 43;
            this.label6.Text = "Charge To.";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Location = new System.Drawing.Point(491, 319);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(380, 2);
            this.panel4.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(166, 308);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 16);
            this.label7.TabIndex = 44;
            this.label7.Text = "Deseased Information";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(611, 294);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 16);
            this.label8.TabIndex = 45;
            this.label8.Text = "Package Selection";
            // 
            // txt_DFname
            // 
            this.txt_DFname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DFname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DFname.Location = new System.Drawing.Point(173, 335);
            this.txt_DFname.Name = "txt_DFname";
            this.txt_DFname.Size = new System.Drawing.Size(215, 25);
            this.txt_DFname.TabIndex = 47;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(26, 338);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 16);
            this.label9.TabIndex = 46;
            this.label9.Text = "First Name:";
            // 
            // txt_DMname
            // 
            this.txt_DMname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DMname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DMname.Location = new System.Drawing.Point(173, 366);
            this.txt_DMname.Name = "txt_DMname";
            this.txt_DMname.Size = new System.Drawing.Size(70, 25);
            this.txt_DMname.TabIndex = 49;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(26, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 16);
            this.label10.TabIndex = 48;
            this.label10.Text = "Middle Initial:";
            // 
            // txt_DLname
            // 
            this.txt_DLname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DLname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DLname.Location = new System.Drawing.Point(173, 397);
            this.txt_DLname.Name = "txt_DLname";
            this.txt_DLname.Size = new System.Drawing.Size(215, 25);
            this.txt_DLname.TabIndex = 51;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(26, 400);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 16);
            this.label11.TabIndex = 50;
            this.label11.Text = "Last Name:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(26, 450);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 16);
            this.label12.TabIndex = 52;
            this.label12.Text = "Cementery Location:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(26, 481);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 16);
            this.label13.TabIndex = 54;
            this.label13.Text = "Burial Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(26, 512);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 16);
            this.label14.TabIndex = 56;
            this.label14.Text = "Burial Time:";
            // 
            // dtp_burialdate
            // 
            this.dtp_burialdate.Checked = false;
            this.dtp_burialdate.CustomFormat = "dd/MM/yyyy";
            this.dtp_burialdate.Font = new System.Drawing.Font("Arial", 9.75F);
            this.dtp_burialdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_burialdate.Location = new System.Drawing.Point(173, 481);
            this.dtp_burialdate.Name = "dtp_burialdate";
            this.dtp_burialdate.Size = new System.Drawing.Size(157, 22);
            this.dtp_burialdate.TabIndex = 58;
            // 
            // dtp_burialtime
            // 
            this.dtp_burialtime.Checked = false;
            this.dtp_burialtime.CustomFormat = "dd/MM/yyyy";
            this.dtp_burialtime.Font = new System.Drawing.Font("Arial", 9.75F);
            this.dtp_burialtime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_burialtime.Location = new System.Drawing.Point(173, 510);
            this.dtp_burialtime.Name = "dtp_burialtime";
            this.dtp_burialtime.Size = new System.Drawing.Size(157, 22);
            this.dtp_burialtime.TabIndex = 59;
            this.dtp_burialtime.Value = new System.DateTime(2024, 9, 29, 21, 1, 0, 0);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(493, 330);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 16);
            this.label17.TabIndex = 64;
            this.label17.Text = "Package:";
            // 
            // cmb_Package
            // 
            this.cmb_Package.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Package.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Package.FormattingEnabled = true;
            this.cmb_Package.Location = new System.Drawing.Point(562, 326);
            this.cmb_Package.Name = "cmb_Package";
            this.cmb_Package.Size = new System.Drawing.Size(204, 26);
            this.cmb_Package.TabIndex = 68;
            this.cmb_Package.SelectedIndexChanged += new System.EventHandler(this.cmb_Package_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(635, 74);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 16);
            this.label15.TabIndex = 70;
            this.label15.Text = "Document";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DimGray;
            this.panel5.Location = new System.Drawing.Point(491, 99);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(380, 2);
            this.panel5.TabIndex = 69;
            // 
            // cmb_DocumentType
            // 
            this.cmb_DocumentType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_DocumentType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_DocumentType.FormattingEnabled = true;
            this.cmb_DocumentType.Location = new System.Drawing.Point(596, 107);
            this.cmb_DocumentType.Name = "cmb_DocumentType";
            this.cmb_DocumentType.Size = new System.Drawing.Size(228, 26);
            this.cmb_DocumentType.TabIndex = 72;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(488, 109);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(102, 16);
            this.label16.TabIndex = 71;
            this.label16.Text = "Document Type:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(409, 450);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 16);
            this.label19.TabIndex = 76;
            this.label19.Text = "*Optional";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(336, 512);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 16);
            this.label20.TabIndex = 77;
            this.label20.Text = "*Optional";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(336, 486);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 16);
            this.label18.TabIndex = 75;
            this.label18.Text = "*Optional";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(26, 541);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(42, 16);
            this.label21.TabIndex = 78;
            this.label21.Text = "Price:";
            // 
            // cmb_CemeteryLocation
            // 
            this.cmb_CemeteryLocation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_CemeteryLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_CemeteryLocation.FormattingEnabled = true;
            this.cmb_CemeteryLocation.Location = new System.Drawing.Point(169, 445);
            this.cmb_CemeteryLocation.Name = "cmb_CemeteryLocation";
            this.cmb_CemeteryLocation.Size = new System.Drawing.Size(228, 26);
            this.cmb_CemeteryLocation.TabIndex = 80;
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.flowLayoutPanel.Location = new System.Drawing.Point(496, 363);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Size = new System.Drawing.Size(159, 165);
            this.flowLayoutPanel.TabIndex = 83;
            // 
            // lbl_Price
            // 
            this.lbl_Price.AutoSize = true;
            this.lbl_Price.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Price.Location = new System.Drawing.Point(170, 539);
            this.lbl_Price.Name = "lbl_Price";
            this.lbl_Price.Size = new System.Drawing.Size(128, 18);
            this.lbl_Price.TabIndex = 179;
            this.lbl_Price.Text = "********************";
            // 
            // picb_documents
            // 
            this.picb_documents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.picb_documents.Location = new System.Drawing.Point(596, 143);
            this.picb_documents.Name = "picb_documents";
            this.picb_documents.Size = new System.Drawing.Size(196, 143);
            this.picb_documents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_documents.TabIndex = 74;
            this.picb_documents.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // btn_Browse
            // 
            this.btn_Browse.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Browse.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Browse.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Browse.BorderRadius = 5;
            this.btn_Browse.BorderSize = 0;
            this.btn_Browse.FlatAppearance.BorderSize = 0;
            this.btn_Browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Browse.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse.ForeColor = System.Drawing.Color.White;
            this.btn_Browse.Location = new System.Drawing.Point(358, 193);
            this.btn_Browse.Name = "btn_Browse";
            this.btn_Browse.Size = new System.Drawing.Size(70, 30);
            this.btn_Browse.TabIndex = 82;
            this.btn_Browse.Text = "Browse";
            this.btn_Browse.TextColor = System.Drawing.Color.White;
            this.btn_Browse.UseVisualStyleBackColor = false;
            this.btn_Browse.Click += new System.EventHandler(this.btn_Browse_Click);
            // 
            // btn_View
            // 
            this.btn_View.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_View.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_View.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_View.BorderRadius = 5;
            this.btn_View.BorderSize = 0;
            this.btn_View.FlatAppearance.BorderSize = 0;
            this.btn_View.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_View.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View.ForeColor = System.Drawing.Color.White;
            this.btn_View.Location = new System.Drawing.Point(801, 256);
            this.btn_View.Name = "btn_View";
            this.btn_View.Size = new System.Drawing.Size(70, 30);
            this.btn_View.TabIndex = 81;
            this.btn_View.Text = "View";
            this.btn_View.TextColor = System.Drawing.Color.White;
            this.btn_View.UseVisualStyleBackColor = false;
            this.btn_View.Click += new System.EventHandler(this.btn_View_Click);
            // 
            // btn_Upload
            // 
            this.btn_Upload.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Upload.BorderRadius = 5;
            this.btn_Upload.BorderSize = 0;
            this.btn_Upload.FlatAppearance.BorderSize = 0;
            this.btn_Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Upload.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Upload.ForeColor = System.Drawing.Color.White;
            this.btn_Upload.Location = new System.Drawing.Point(491, 166);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(70, 30);
            this.btn_Upload.TabIndex = 73;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.TextColor = System.Drawing.Color.White;
            this.btn_Upload.UseVisualStyleBackColor = false;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnAdd.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnAdd.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnAdd.BorderRadius = 5;
            this.btnAdd.BorderSize = 0;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(811, 520);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(70, 30);
            this.btnAdd.TabIndex = 67;
            this.btnAdd.Text = "Add";
            this.btnAdd.TextColor = System.Drawing.Color.White;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btn_CustomizePackage
            // 
            this.btn_CustomizePackage.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_CustomizePackage.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_CustomizePackage.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_CustomizePackage.BorderRadius = 5;
            this.btn_CustomizePackage.BorderSize = 0;
            this.btn_CustomizePackage.FlatAppearance.BorderSize = 0;
            this.btn_CustomizePackage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CustomizePackage.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CustomizePackage.ForeColor = System.Drawing.Color.White;
            this.btn_CustomizePackage.Location = new System.Drawing.Point(771, 323);
            this.btn_CustomizePackage.Name = "btn_CustomizePackage";
            this.btn_CustomizePackage.Size = new System.Drawing.Size(85, 31);
            this.btn_CustomizePackage.TabIndex = 66;
            this.btn_CustomizePackage.Text = "Customize";
            this.btn_CustomizePackage.TextColor = System.Drawing.Color.White;
            this.btn_CustomizePackage.UseVisualStyleBackColor = false;
            this.btn_CustomizePackage.Click += new System.EventHandler(this.btn_CustomizePackage_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DimGray;
            this.panel6.Location = new System.Drawing.Point(28, 252);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 2);
            this.panel6.TabIndex = 180;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(184, 233);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(90, 16);
            this.label22.TabIndex = 181;
            this.label22.Text = "Service Type";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(33, 265);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 16);
            this.label23.TabIndex = 182;
            this.label23.Text = "Service Type";
            // 
            // cmb_ServiceType
            // 
            this.cmb_ServiceType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_ServiceType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ServiceType.FormattingEnabled = true;
            this.cmb_ServiceType.Location = new System.Drawing.Point(128, 260);
            this.cmb_ServiceType.Name = "cmb_ServiceType";
            this.cmb_ServiceType.Size = new System.Drawing.Size(187, 26);
            this.cmb_ServiceType.TabIndex = 183;
            // 
            // btn_Reservation
            // 
            this.btn_Reservation.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Reservation.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Reservation.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Reservation.BorderRadius = 5;
            this.btn_Reservation.BorderSize = 0;
            this.btn_Reservation.FlatAppearance.BorderSize = 0;
            this.btn_Reservation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reservation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reservation.ForeColor = System.Drawing.Color.White;
            this.btn_Reservation.Location = new System.Drawing.Point(332, 258);
            this.btn_Reservation.Name = "btn_Reservation";
            this.btn_Reservation.Size = new System.Drawing.Size(96, 30);
            this.btn_Reservation.TabIndex = 184;
            this.btn_Reservation.Text = "Reservation";
            this.btn_Reservation.TextColor = System.Drawing.Color.White;
            this.btn_Reservation.UseVisualStyleBackColor = false;
            this.btn_Reservation.Click += new System.EventHandler(this.btn_Reservation_Click);
            // 
            // CreateNewServiceRequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(895, 576);
            this.Controls.Add(this.btn_Reservation);
            this.Controls.Add(this.lbl_Price);
            this.Controls.Add(this.flowLayoutPanel);
            this.Controls.Add(this.cmb_ServiceType);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.btn_Browse);
            this.Controls.Add(this.btn_View);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cmb_CemeteryLocation);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.picb_documents);
            this.Controls.Add(this.btn_Upload);
            this.Controls.Add(this.cmb_DocumentType);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.cmb_Package);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btn_CustomizePackage);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dtp_burialtime);
            this.Controls.Add(this.dtp_burialdate);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_DLname);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_DMname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_DFname);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Address);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtLName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dgv_PackageDetails);
            this.Controls.Add(this.txt_MiddleInitial);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "CreateNewServiceRequestForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateNewServiceRequestForm";
            this.Load += new System.EventHandler(this.CreateNewServiceRequestForm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PackageDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_documents)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_MiddleInitial;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgv_PackageDetails;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_DFname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_DMname;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_DLname;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtp_burialdate;
        private System.Windows.Forms.DateTimePicker dtp_burialtime;
        private System.Windows.Forms.Label label17;
        private RoundedButton btn_CustomizePackage;
        private RoundedButton btnAdd;
        private System.Windows.Forms.ComboBox cmb_Package;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox cmb_DocumentType;
        private System.Windows.Forms.Label label16;
        private RoundedButton btn_Upload;
        private System.Windows.Forms.PictureBox picb_documents;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmb_CemeteryLocation;
        private RoundedButton btn_View;
        private RoundedButton btn_Browse;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.Label lbl_Price;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cmb_ServiceType;
        private RoundedButton btn_Reservation;
    }
}