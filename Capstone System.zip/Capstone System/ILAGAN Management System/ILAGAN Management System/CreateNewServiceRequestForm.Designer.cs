﻿namespace ILAGAN_Management_System
{
    partial class CreateNewServiceRequestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtFName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_MiddleInitial = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Address = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_DFname = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_DMname = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_DLname = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dtp_burialdate = new System.Windows.Forms.DateTimePicker();
            this.dtp_burialtime = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.cmb_DocumentType = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.cmb_CemeteryLocation = new System.Windows.Forms.ComboBox();
            this.lbl_TotalPrice = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.cmb_ServiceType = new System.Windows.Forms.ComboBox();
            this.dgv_PackageDetails = new System.Windows.Forms.DataGridView();
            this.label17 = new System.Windows.Forms.Label();
            this.cmb_Discount = new System.Windows.Forms.ComboBox();
            this.picb_documents = new System.Windows.Forms.PictureBox();
            this.lbl_DiscountedPrice = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btn_Package = new ILAGAN_Management_System.RoundedButton();
            this.btn_Reservation = new ILAGAN_Management_System.RoundedButton();
            this.btn_Browse = new ILAGAN_Management_System.RoundedButton();
            this.btn_View = new ILAGAN_Management_System.RoundedButton();
            this.btn_Upload = new ILAGAN_Management_System.RoundedButton();
            this.btnAdd = new ILAGAN_Management_System.RoundedButton();
            this.label20 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PackageDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_documents)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(861, 68);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(259, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Create New Service Request";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(28, 92);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(380, 2);
            this.panel2.TabIndex = 15;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Location = new System.Drawing.Point(28, 256);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(380, 2);
            this.panel3.TabIndex = 15;
            // 
            // txtFName
            // 
            this.txtFName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFName.Location = new System.Drawing.Point(128, 104);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(187, 25);
            this.txtFName.TabIndex = 34;
            this.txtFName.Text = " ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 33;
            this.label2.Text = "First Name:";
            // 
            // txt_MiddleInitial
            // 
            this.txt_MiddleInitial.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_MiddleInitial.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MiddleInitial.Location = new System.Drawing.Point(128, 135);
            this.txt_MiddleInitial.Name = "txt_MiddleInitial";
            this.txt_MiddleInitial.Size = new System.Drawing.Size(187, 25);
            this.txt_MiddleInitial.TabIndex = 36;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 35;
            this.label3.Text = "Middle Name:";
            // 
            // txtLName
            // 
            this.txtLName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLName.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLName.Location = new System.Drawing.Point(128, 166);
            this.txtLName.Name = "txtLName";
            this.txtLName.Size = new System.Drawing.Size(187, 25);
            this.txtLName.TabIndex = 40;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 169);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 16);
            this.label5.TabIndex = 39;
            this.label5.Text = "Last Name:";
            // 
            // txt_Address
            // 
            this.txt_Address.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Address.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Address.Location = new System.Drawing.Point(128, 197);
            this.txt_Address.Name = "txt_Address";
            this.txt_Address.Size = new System.Drawing.Size(187, 25);
            this.txt_Address.TabIndex = 42;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 41;
            this.label4.Text = "Address:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SeaGreen;
            this.label6.Location = new System.Drawing.Point(29, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 16);
            this.label6.TabIndex = 43;
            this.label6.Text = "Client Details";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SeaGreen;
            this.label7.Location = new System.Drawing.Point(29, 237);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 16);
            this.label7.TabIndex = 44;
            this.label7.Text = "Deseased Information";
            // 
            // txt_DFname
            // 
            this.txt_DFname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DFname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DFname.Location = new System.Drawing.Point(176, 263);
            this.txt_DFname.Name = "txt_DFname";
            this.txt_DFname.Size = new System.Drawing.Size(215, 25);
            this.txt_DFname.TabIndex = 47;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(29, 266);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 16);
            this.label9.TabIndex = 46;
            this.label9.Text = "First Name:";
            // 
            // txt_DMname
            // 
            this.txt_DMname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DMname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DMname.Location = new System.Drawing.Point(176, 294);
            this.txt_DMname.Name = "txt_DMname";
            this.txt_DMname.Size = new System.Drawing.Size(70, 25);
            this.txt_DMname.TabIndex = 49;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(29, 297);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 16);
            this.label10.TabIndex = 48;
            this.label10.Text = "Middle Initial:";
            // 
            // txt_DLname
            // 
            this.txt_DLname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DLname.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_DLname.Location = new System.Drawing.Point(176, 325);
            this.txt_DLname.Name = "txt_DLname";
            this.txt_DLname.Size = new System.Drawing.Size(215, 25);
            this.txt_DLname.TabIndex = 51;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(29, 328);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 16);
            this.label11.TabIndex = 50;
            this.label11.Text = "Last Name:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(437, 138);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 16);
            this.label12.TabIndex = 52;
            this.label12.Text = "Cementery Location:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(439, 166);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 16);
            this.label13.TabIndex = 54;
            this.label13.Text = "Burial Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(439, 197);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 16);
            this.label14.TabIndex = 56;
            this.label14.Text = "Burial Time:";
            // 
            // dtp_burialdate
            // 
            this.dtp_burialdate.CustomFormat = "MMMM/d/yyyy";
            this.dtp_burialdate.Font = new System.Drawing.Font("Arial", 9.75F);
            this.dtp_burialdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_burialdate.Location = new System.Drawing.Point(571, 168);
            this.dtp_burialdate.Name = "dtp_burialdate";
            this.dtp_burialdate.Size = new System.Drawing.Size(157, 22);
            this.dtp_burialdate.TabIndex = 58;
            // 
            // dtp_burialtime
            // 
            this.dtp_burialtime.CustomFormat = "dd/MM/yyyy";
            this.dtp_burialtime.Font = new System.Drawing.Font("Arial", 9.75F);
            this.dtp_burialtime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtp_burialtime.Location = new System.Drawing.Point(571, 193);
            this.dtp_burialtime.Name = "dtp_burialtime";
            this.dtp_burialtime.Size = new System.Drawing.Size(157, 22);
            this.dtp_burialtime.TabIndex = 59;
            this.dtp_burialtime.Value = new System.DateTime(2024, 9, 29, 21, 1, 0, 0);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.SeaGreen;
            this.label15.Location = new System.Drawing.Point(29, 369);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 16);
            this.label15.TabIndex = 70;
            this.label15.Text = "Document";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DimGray;
            this.panel5.Location = new System.Drawing.Point(28, 388);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(380, 2);
            this.panel5.TabIndex = 69;
            // 
            // cmb_DocumentType
            // 
            this.cmb_DocumentType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_DocumentType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_DocumentType.FormattingEnabled = true;
            this.cmb_DocumentType.Location = new System.Drawing.Point(133, 400);
            this.cmb_DocumentType.Name = "cmb_DocumentType";
            this.cmb_DocumentType.Size = new System.Drawing.Size(228, 26);
            this.cmb_DocumentType.TabIndex = 72;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(25, 402);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(102, 16);
            this.label16.TabIndex = 71;
            this.label16.Text = "Document Type:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(451, 543);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 16);
            this.label21.TabIndex = 78;
            this.label21.Text = "Total Price:";
            // 
            // cmb_CemeteryLocation
            // 
            this.cmb_CemeteryLocation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_CemeteryLocation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_CemeteryLocation.FormattingEnabled = true;
            this.cmb_CemeteryLocation.Location = new System.Drawing.Point(571, 133);
            this.cmb_CemeteryLocation.Name = "cmb_CemeteryLocation";
            this.cmb_CemeteryLocation.Size = new System.Drawing.Size(233, 26);
            this.cmb_CemeteryLocation.TabIndex = 80;
            // 
            // lbl_TotalPrice
            // 
            this.lbl_TotalPrice.AutoSize = true;
            this.lbl_TotalPrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_TotalPrice.Location = new System.Drawing.Point(582, 543);
            this.lbl_TotalPrice.Name = "lbl_TotalPrice";
            this.lbl_TotalPrice.Size = new System.Drawing.Size(128, 18);
            this.lbl_TotalPrice.TabIndex = 179;
            this.lbl_TotalPrice.Text = "********************";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DimGray;
            this.panel6.Location = new System.Drawing.Point(442, 92);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 2);
            this.panel6.TabIndex = 180;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.SeaGreen;
            this.label22.Location = new System.Drawing.Point(439, 73);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(103, 16);
            this.label22.TabIndex = 181;
            this.label22.Text = "Service Details";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(437, 105);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(85, 16);
            this.label23.TabIndex = 182;
            this.label23.Text = "Service Type:";
            // 
            // cmb_ServiceType
            // 
            this.cmb_ServiceType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_ServiceType.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_ServiceType.FormattingEnabled = true;
            this.cmb_ServiceType.Location = new System.Drawing.Point(571, 99);
            this.cmb_ServiceType.Name = "cmb_ServiceType";
            this.cmb_ServiceType.Size = new System.Drawing.Size(157, 26);
            this.cmb_ServiceType.TabIndex = 183;
            // 
            // dgv_PackageDetails
            // 
            this.dgv_PackageDetails.AllowUserToAddRows = false;
            this.dgv_PackageDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_PackageDetails.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_PackageDetails.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_PackageDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_PackageDetails.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_PackageDetails.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_PackageDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_PackageDetails.Location = new System.Drawing.Point(571, 237);
            this.dgv_PackageDetails.Name = "dgv_PackageDetails";
            this.dgv_PackageDetails.ReadOnly = true;
            this.dgv_PackageDetails.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_PackageDetails.RowHeadersVisible = false;
            this.dgv_PackageDetails.Size = new System.Drawing.Size(242, 176);
            this.dgv_PackageDetails.TabIndex = 186;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(451, 483);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 16);
            this.label17.TabIndex = 187;
            this.label17.Text = "Discount:";
            // 
            // cmb_Discount
            // 
            this.cmb_Discount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Discount.FormattingEnabled = true;
            this.cmb_Discount.Location = new System.Drawing.Point(585, 478);
            this.cmb_Discount.Name = "cmb_Discount";
            this.cmb_Discount.Size = new System.Drawing.Size(219, 26);
            this.cmb_Discount.TabIndex = 188;
            this.cmb_Discount.SelectedIndexChanged += new System.EventHandler(this.cmb_Discount_SelectedIndexChanged);
            // 
            // picb_documents
            // 
            this.picb_documents.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.picb_documents.Location = new System.Drawing.Point(133, 431);
            this.picb_documents.Name = "picb_documents";
            this.picb_documents.Size = new System.Drawing.Size(196, 151);
            this.picb_documents.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picb_documents.TabIndex = 74;
            this.picb_documents.TabStop = false;
            // 
            // lbl_DiscountedPrice
            // 
            this.lbl_DiscountedPrice.AutoSize = true;
            this.lbl_DiscountedPrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DiscountedPrice.Location = new System.Drawing.Point(582, 516);
            this.lbl_DiscountedPrice.Name = "lbl_DiscountedPrice";
            this.lbl_DiscountedPrice.Size = new System.Drawing.Size(128, 18);
            this.lbl_DiscountedPrice.TabIndex = 190;
            this.lbl_DiscountedPrice.Text = "********************";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(451, 516);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(111, 16);
            this.label19.TabIndex = 189;
            this.label19.Text = "Discounted Price:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(582, 450);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 18);
            this.label8.TabIndex = 192;
            this.label8.Text = "********************";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(451, 450);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 16);
            this.label18.TabIndex = 191;
            this.label18.Text = "SubTotal:";
            // 
            // btn_Package
            // 
            this.btn_Package.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Package.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Package.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Package.BorderRadius = 5;
            this.btn_Package.BorderSize = 0;
            this.btn_Package.FlatAppearance.BorderSize = 0;
            this.btn_Package.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Package.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Package.ForeColor = System.Drawing.Color.White;
            this.btn_Package.Location = new System.Drawing.Point(473, 237);
            this.btn_Package.Name = "btn_Package";
            this.btn_Package.Size = new System.Drawing.Size(85, 31);
            this.btn_Package.TabIndex = 185;
            this.btn_Package.Text = "Package";
            this.btn_Package.TextColor = System.Drawing.Color.White;
            this.btn_Package.UseVisualStyleBackColor = false;
            this.btn_Package.Click += new System.EventHandler(this.btn_CustomizePackage_Click_1);
            // 
            // btn_Reservation
            // 
            this.btn_Reservation.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Reservation.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Reservation.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Reservation.BorderRadius = 5;
            this.btn_Reservation.BorderSize = 0;
            this.btn_Reservation.FlatAppearance.BorderSize = 0;
            this.btn_Reservation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Reservation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reservation.ForeColor = System.Drawing.Color.White;
            this.btn_Reservation.Location = new System.Drawing.Point(746, 97);
            this.btn_Reservation.Name = "btn_Reservation";
            this.btn_Reservation.Size = new System.Drawing.Size(96, 30);
            this.btn_Reservation.TabIndex = 184;
            this.btn_Reservation.Text = "Reservation";
            this.btn_Reservation.TextColor = System.Drawing.Color.White;
            this.btn_Reservation.UseVisualStyleBackColor = false;
            this.btn_Reservation.Click += new System.EventHandler(this.btn_Reservation_Click);
            // 
            // btn_Browse
            // 
            this.btn_Browse.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Browse.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Browse.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Browse.BorderRadius = 5;
            this.btn_Browse.BorderSize = 0;
            this.btn_Browse.FlatAppearance.BorderSize = 0;
            this.btn_Browse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Browse.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Browse.ForeColor = System.Drawing.Color.White;
            this.btn_Browse.Location = new System.Drawing.Point(321, 192);
            this.btn_Browse.Name = "btn_Browse";
            this.btn_Browse.Size = new System.Drawing.Size(70, 30);
            this.btn_Browse.TabIndex = 82;
            this.btn_Browse.Text = "Browse";
            this.btn_Browse.TextColor = System.Drawing.Color.White;
            this.btn_Browse.UseVisualStyleBackColor = false;
            this.btn_Browse.Click += new System.EventHandler(this.btn_Browse_Click);
            // 
            // btn_View
            // 
            this.btn_View.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_View.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_View.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_View.BorderRadius = 5;
            this.btn_View.BorderSize = 0;
            this.btn_View.FlatAppearance.BorderSize = 0;
            this.btn_View.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_View.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_View.ForeColor = System.Drawing.Color.White;
            this.btn_View.Location = new System.Drawing.Point(338, 552);
            this.btn_View.Name = "btn_View";
            this.btn_View.Size = new System.Drawing.Size(70, 30);
            this.btn_View.TabIndex = 81;
            this.btn_View.Text = "View";
            this.btn_View.TextColor = System.Drawing.Color.White;
            this.btn_View.UseVisualStyleBackColor = false;
            this.btn_View.Click += new System.EventHandler(this.btn_View_Click);
            // 
            // btn_Upload
            // 
            this.btn_Upload.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_Upload.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Upload.BorderRadius = 5;
            this.btn_Upload.BorderSize = 0;
            this.btn_Upload.FlatAppearance.BorderSize = 0;
            this.btn_Upload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Upload.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Upload.ForeColor = System.Drawing.Color.White;
            this.btn_Upload.Location = new System.Drawing.Point(28, 462);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(70, 30);
            this.btn_Upload.TabIndex = 73;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.TextColor = System.Drawing.Color.White;
            this.btn_Upload.UseVisualStyleBackColor = false;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnAdd.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnAdd.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnAdd.BorderRadius = 5;
            this.btnAdd.BorderSize = 0;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(772, 574);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(70, 30);
            this.btnAdd.TabIndex = 67;
            this.btnAdd.Text = "Add";
            this.btnAdd.TextColor = System.Drawing.Color.White;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.SeaGreen;
            this.label20.Location = new System.Drawing.Point(439, 412);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(130, 16);
            this.label20.TabIndex = 194;
            this.label20.Text = "Pricing Information";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DimGray;
            this.panel7.Location = new System.Drawing.Point(442, 431);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(400, 2);
            this.panel7.TabIndex = 181;
            // 
            // CreateNewServiceRequestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(861, 616);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.lbl_DiscountedPrice);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.cmb_Discount);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.dgv_PackageDetails);
            this.Controls.Add(this.btn_Package);
            this.Controls.Add(this.btn_Reservation);
            this.Controls.Add(this.lbl_TotalPrice);
            this.Controls.Add(this.cmb_ServiceType);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.btn_Browse);
            this.Controls.Add(this.btn_View);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cmb_CemeteryLocation);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.picb_documents);
            this.Controls.Add(this.btn_Upload);
            this.Controls.Add(this.cmb_DocumentType);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.dtp_burialtime);
            this.Controls.Add(this.dtp_burialdate);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txt_DLname);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_DMname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_DFname);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_Address);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtLName);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txt_MiddleInitial);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "CreateNewServiceRequestForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CreateNewServiceRequestForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CreateNewServiceRequestForm_FormClosing);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_PackageDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_documents)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtFName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_MiddleInitial;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_Address;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_DFname;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_DMname;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_DLname;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DateTimePicker dtp_burialdate;
        private System.Windows.Forms.DateTimePicker dtp_burialtime;
        private RoundedButton btnAdd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ComboBox cmb_DocumentType;
        private System.Windows.Forms.Label label16;
        private RoundedButton btn_Upload;
        private System.Windows.Forms.PictureBox picb_documents;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmb_CemeteryLocation;
        private RoundedButton btn_View;
        private RoundedButton btn_Browse;
        private System.Windows.Forms.Label lbl_TotalPrice;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cmb_ServiceType;
        private RoundedButton btn_Reservation;
        private RoundedButton btn_Package;
        private System.Windows.Forms.DataGridView dgv_PackageDetails;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cmb_Discount;
        private System.Windows.Forms.Label lbl_DiscountedPrice;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel7;
    }
}