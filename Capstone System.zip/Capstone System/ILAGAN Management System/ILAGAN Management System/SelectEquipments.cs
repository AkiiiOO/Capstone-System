﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class SelectEquipments : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public List<Equipment> SelectedEquipments { get; set; }

        public SelectEquipments()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadEquipment();
            SelectedEquipments = new List<Equipment>();
        }
        private void LoadEquipment()
        {
            try
            {
                db.Open();
                string query = "SELECT EquipmentID, EquipmentName, EquipmentType, Quantity FROM Equipment";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataAdapter dt = new SqlDataAdapter(command);

                DataTable equipmentTable = new DataTable();
                dt.Fill(equipmentTable);
                dgv_EquipmentsRecords.DataSource = equipmentTable;

                // Rename the columns to be more user-friendly
                dgv_EquipmentsRecords.Columns["EquipmentID"].Visible = false;  // Hide the EquipmentID column
                dgv_EquipmentsRecords.Columns["EquipmentName"].HeaderText = "Equipment Name";
                dgv_EquipmentsRecords.Columns["EquipmentName"].ReadOnly = true;
                dgv_EquipmentsRecords.Columns["EquipmentType"].HeaderText = "Equipment Type";
                dgv_EquipmentsRecords.Columns["EquipmentType"].ReadOnly = true;
                dgv_EquipmentsRecords.Columns["Quantity"].HeaderText = "Quantity Available";
                dgv_EquipmentsRecords.Columns["Quantity"].ReadOnly = true;

                // Make the 'Select' column visible if you have one for selection
                dgv_EquipmentsRecords.Columns["SelectColumn"].Visible = true;
                dgv_EquipmentsRecords.Columns["txt_Quantity"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading equipment: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void btn_Select_Click(object sender, EventArgs e)
        {
            SelectedEquipments.Clear(); 
            
            foreach (DataGridViewRow row in dgv_EquipmentsRecords.Rows)
            {
                if (Convert.ToBoolean(row.Cells["SelectColumn"].Value)) // Check if selected
                {
                    if (row.Cells["txt_Quantity"].Value == null || string.IsNullOrEmpty(row.Cells["txt_Quantity"].Value.ToString()))
                    {
                        MessageBox.Show("Quantity is required for selected equipment.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    int quantity;
                    if (!int.TryParse(row.Cells["txt_Quantity"].Value.ToString(), out quantity) || quantity <= 0)
                    {
                        MessageBox.Show("Quantity must be a valid number greater than 0.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string equipmentName = row.Cells["EquipmentName"].Value.ToString();
                    string equipmentType = row.Cells["EquipmentType"].Value.ToString();
                    int availableQuantity = Convert.ToInt32(row.Cells["Quantity"].Value);

                    if (quantity > availableQuantity)
                    {
                        MessageBox.Show("You can only select up to " + availableQuantity + " of " + equipmentName, "Quantity Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    SelectedEquipments.Add(new Equipment
                    {
                        EquipmentID = Convert.ToInt32(row.Cells["EquipmentID"].Value),
                        EquipmentName = equipmentName,
                        EquipmentType = equipmentType,
                        Quantity = quantity
                    });
                }
            }

            if (SelectedEquipments.Count > 0)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Please select at least one equipment.");
            }
        }
        public class Equipment
        {
            public int EquipmentID { get; set; }
            public string EquipmentName { get; set; }
            public string EquipmentType { get; set; }
            public int Quantity { get; set; }
        }
    }
}
