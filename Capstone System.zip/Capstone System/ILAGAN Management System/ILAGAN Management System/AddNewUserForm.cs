﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewUserForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler UserAdded;

        public AddNewUserForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void AddNewUserForm_Load(object sender, EventArgs e)
        {
            //display the accesslevel in combolistbox
            LoadAccessLevels();
            
            //display the Status in combolistbox
            LoadPermissions();
            cmb_Permissions.Enabled = false;
            clb_UserAccessLevel.ItemCheck += new ItemCheckEventHandler(clb_UserAccessLevel_SelectedIndexChanged);
        }

        private void LoadAccessLevels()
        {
            clb_UserAccessLevel.Items.Clear();
            string al_query = "SELECT AccessLevelName FROM AccessLevels";
            using (SqlCommand al_command = new SqlCommand(al_query, db))
            {
                db.Open();
                using (SqlDataReader al_reader = al_command.ExecuteReader())
                {
                    while (al_reader.Read())
                    {
                        clb_UserAccessLevel.Items.Add(al_reader["AccessLevelName"].ToString());
                    }
                }
                db.Close();
            }
        }
        private void LoadPermissions()
        {
            cmb_Permissions.Items.Clear();
            string p_query = "SELECT PermissionName FROM Permissions";
            using (SqlCommand p_command = new SqlCommand(p_query, db))
            {
                db.Open();
                using (SqlDataReader p_reader = p_command.ExecuteReader())
                {
                    while (p_reader.Read())
                    {
                        cmb_Permissions.Items.Add(p_reader["PermissionName"].ToString());
                    }
                }
                db.Close();
            }
        }

        private void btn_Assign_Click(object sender, EventArgs e)
        {

        }

        private void clb_UserAccessLevel_SelectedIndexChanged(object sender, ItemCheckEventArgs e)
        {
            string selectedAccessLevel = clb_UserAccessLevel.Items[e.Index].ToString();

            if (e.NewValue == CheckState.Checked)
            {
                if (selectedAccessLevel == "Admin")
                {
                    for (int i = 0; i < clb_UserAccessLevel.Items.Count; i++)
                    {
                        if (i != e.Index)
                        {
                            clb_UserAccessLevel.SetItemChecked(i, false);
                        }
                    }
                    cmb_Permissions.Enabled = false;
                }
                else
                {
                    for (int i = 0; i < clb_UserAccessLevel.Items.Count; i++)
                    {
                        if (clb_UserAccessLevel.Items[i].ToString() == "Admin")
                        {
                            clb_UserAccessLevel.SetItemChecked(i, false);
                        }
                    }
                    cmb_Permissions.Enabled = true;
                }
            }
            else
            {
                if (selectedAccessLevel == "Admin")
                {
                    cmb_Permissions.Enabled = true;
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            db.Open();
            SqlCommand checkUsernameCommand = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @Username", db);
            checkUsernameCommand.Parameters.AddWithValue("@Username", txtUsername.Text);
            int userCount = (int)checkUsernameCommand.ExecuteScalar();

            if (userCount > 0)
            {
                MessageBox.Show("The username already exists. Please choose a different username.");
                return;
            }

            SqlCommand com = new SqlCommand("INSERT INTO Users (Username, Password, FirstName, LastName, Contact_No, StatusID) OUTPUT INSERTED.UserID VALUES (@Username, @Password, @FirstName, @LastName, @Contact_No, @StatusID);", db);
            
            com.Parameters.AddWithValue("@Username", txtUsername.Text);
            com.Parameters.AddWithValue("@Password", txtPassword.Text);
            com.Parameters.AddWithValue("@FirstName", txtFName.Text);
            com.Parameters.AddWithValue("@LastName", txtLastName.Text);
            com.Parameters.AddWithValue("@Contact_No", txtPhoneNumber.Text);
            com.Parameters.AddWithValue("@StatusID", 1);

            int userID = (int)com.ExecuteScalar();

            foreach (var item in clb_UserAccessLevel.CheckedItems)
            {
                string accessLevelName = item.ToString();

                // Get the AccessLevelID for the selected AccessLevelName
                SqlCommand al_Command = new SqlCommand("SELECT AccessLevelID FROM AccessLevels WHERE AccessLevelName = @AccessLevelName", db);
                al_Command.Parameters.AddWithValue("@AccessLevelName", accessLevelName);
                int accessLevelID = (int)al_Command.ExecuteScalar();

                // Insert into UserAccessLevels
                SqlCommand insertUserAccessLevel = new SqlCommand("INSERT INTO UserAccessLevels (UserID, AccessLevelID) VALUES (@UserID, @AccessLevelID)", db);
                insertUserAccessLevel.Parameters.AddWithValue("@UserID", userID);
                insertUserAccessLevel.Parameters.AddWithValue("@AccessLevelID", accessLevelID);
                insertUserAccessLevel.ExecuteNonQuery();

                // If the selected access level is not 'Admin', insert permissions
                if (accessLevelName != "Admin")
                {
                    // Retrieve the corresponding permission selected for this access level
                    int permissionID = GetSelectedPermissionID();

                    SqlCommand insertAccessLevelPermission = new SqlCommand("INSERT INTO AccessLevelPermissions (AccessLevelID, PermissionID) VALUES (@AccessLevelID, @PermissionID)", db);
                    insertAccessLevelPermission.Parameters.AddWithValue("@AccessLevelID", accessLevelID);
                    insertAccessLevelPermission.Parameters.AddWithValue("@PermissionID", permissionID);
                    insertAccessLevelPermission.ExecuteNonQuery();
                }
            }


            // notify the user
            MessageBox.Show("Successfully added!!");

            txtUsername.Clear();
            txtPassword.Clear();
            txtFName.Clear();
            txtLastName.Clear();
            txtPhoneNumber.Clear();
            clb_UserAccessLevel.ClearSelected();
            cmb_Permissions.SelectedIndex = -1;

            UserAdded.Invoke(this, EventArgs.Empty);
            db.Close();
        }
        private int GetSelectedPermissionID()
        {
            if (cmb_Permissions.SelectedItem == null)
            {
                throw new InvalidOperationException("No permission selected.");
            }

            string selectedPermission = cmb_Permissions.SelectedItem.ToString();
            SqlCommand permissionCommand = new SqlCommand("SELECT PermissionID FROM Permissions WHERE PermissionName = @PermissionName", db);
            permissionCommand.Parameters.AddWithValue("@PermissionName", selectedPermission);

            return (int)permissionCommand.ExecuteScalar();
        }
    }
}
