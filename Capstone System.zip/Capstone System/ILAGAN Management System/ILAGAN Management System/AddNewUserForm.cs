﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace ILAGAN_Management_System
{
    public partial class AddNewUserForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler UserAdded;

        public AddNewUserForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadAccessLevels();
        }

        private void LoadAccessLevels()
        {
            try
            {
                db.Open();
                string query = "SELECT AccessLevelID, AccessLevelName FROM AccessLevels";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataAdapter dt = new SqlDataAdapter(command);

                DataTable accessLevelsTable = new DataTable();
                dt.Fill(accessLevelsTable);
                dgv_AccessLevel.DataSource = accessLevelsTable; 

                dgv_AccessLevel.Columns["AccessLevelID"].Visible = false;
                dgv_AccessLevel.Columns["AccessLevelName"].HeaderText = "Access Level";
                dgv_AccessLevel.Columns["AccessLevelName"].ReadOnly = true;
                dgv_AccessLevel.Columns["SelectColumn"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading access levels: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
        private void dgv_AccessLevel_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgv_AccessLevel.Columns["SelectColumn"].Index && e.RowIndex >= 0)
            {
                string adminName = "Admin";
                DataGridViewRow selectedRow = dgv_AccessLevel.Rows[e.RowIndex];
                bool isSelected = Convert.ToBoolean(selectedRow.Cells["SelectColumn"].EditedFormattedValue);

                if (selectedRow.Cells["AccessLevelName"].Value.ToString() == adminName && isSelected)
                {
                    foreach (DataGridViewRow row in dgv_AccessLevel.Rows)
                    {
                        if (row.Cells["AccessLevelName"].Value.ToString() != adminName)
                        {
                            row.Cells["SelectColumn"].Value = false;
                        }
                    }
                }
                else if (isSelected)
                {
                    foreach (DataGridViewRow row in dgv_AccessLevel.Rows)
                    {
                        if (row.Cells["AccessLevelName"].Value.ToString() == adminName)
                        {
                            row.Cells["SelectColumn"].Value = false;
                        }
                    }
                }
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateInput())
            {
                return; 
            }

            try
            {
                db.Open();

                if (UsernameExists(txtUsername.Text))
                {
                    MessageBox.Show("Username already exists. Please choose a different username.", "Validation Error");
                    return;
                }

                string insertUserQuery = @"INSERT INTO Users (Username, Password, FirstName, LastName, Contact_No, SecurityAnswer, StatusID)
                                           VALUES (@Username, @Password, @FirstName, @LastName, @Contact_No, @SecurityAnswer, @StatusID);
                                           SELECT SCOPE_IDENTITY();";

                SqlCommand cmd = new SqlCommand(insertUserQuery, db);
                cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                cmd.Parameters.AddWithValue("@Password", HashPassword(txtPassword.Text));
                cmd.Parameters.AddWithValue("@FirstName", txtFName.Text);
                cmd.Parameters.AddWithValue("@LastName", txtLastName.Text);
                cmd.Parameters.AddWithValue("@Contact_No", txtPhoneNumber.Text);
                cmd.Parameters.AddWithValue("@SecurityAnswer", txtSecurityAnswer.Text);
                cmd.Parameters.AddWithValue("@StatusID", 1);

                int newUserId = Convert.ToInt32(cmd.ExecuteScalar());

                foreach (DataGridViewRow row in dgv_AccessLevel.Rows)
                {
                    if (Convert.ToBoolean(row.Cells["SelectColumn"].Value) == true)
                    {
                        int accessLevelId = Convert.ToInt32(row.Cells["AccessLevelID"].Value);
                        string insertAccessLevelQuery = @"INSERT INTO UserAccessLevels (UserID, AccessLevelID)
                                                          VALUES (@UserID, @AccessLevelID);";

                        SqlCommand accessCmd = new SqlCommand(insertAccessLevelQuery, db);
                        accessCmd.Parameters.AddWithValue("@UserID", newUserId);
                        accessCmd.Parameters.AddWithValue("@AccessLevelID", accessLevelId);
                        accessCmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("User added successfully!");
                UserAdded.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding user: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private bool UsernameExists(string username)
        {
            string checkQuery = "SELECT COUNT(1) FROM Users WHERE Username = @Username";
            SqlCommand checkCmd = new SqlCommand(checkQuery, db);
            checkCmd.Parameters.AddWithValue("@Username", username);

            int count = Convert.ToInt32(checkCmd.ExecuteScalar());
            return count > 0;
        }

        private bool ValidateInput()
        {
            // Username validation
            if (string.IsNullOrEmpty(txtUsername.Text))
            {
                MessageBox.Show("Username is required.", "Validation Error");
                return false;
            }

            // Password validation
            if (string.IsNullOrEmpty(txtPassword.Text) || txtPassword.Text.Length < 6)
            {
                MessageBox.Show("Password is required and must be at least 6 characters long.", "Validation Error");
                return false;
            }

            // First Name and Last Name validation
            if (string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLastName.Text))
            {
                MessageBox.Show("First Name and Last Name are required.", "Validation Error");
                return false;
            }

            // Phone number validation (must be 11 characters)
            if (string.IsNullOrEmpty(txtPhoneNumber.Text) || txtPhoneNumber.Text.Length != 11)
            {
                MessageBox.Show("Contact number must be exactly 11 characters.", "Validation Error");
                return false;
            }

            // Access Level validation
            bool accessLevelSelected = false;
            foreach (DataGridViewRow row in dgv_AccessLevel.Rows)
            {
                if (Convert.ToBoolean(row.Cells["SelectColumn"].Value) == true)
                {
                    accessLevelSelected = true;
                    break;
                }
            }

            if (!accessLevelSelected)
            {
                MessageBox.Show("At least one access level must be selected.", "Validation Error");
                return false;
            }
            return true;
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
