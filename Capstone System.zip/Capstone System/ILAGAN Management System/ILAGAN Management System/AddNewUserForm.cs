﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewUserForm : Form
    {
        public event EventHandler UserAdded;

        public AddNewUserForm()
        {
            InitializeComponent();
        }

        private void AddNewUserForm_Load(object sender, EventArgs e)
        {
            cmb_UserAccessLevel.Items.Clear();
            SqlConnection x = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
            x.Open();
            SqlCommand command = new SqlCommand("SELECT AccessLevelName FROM AccessLevels", x);
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                // Add the AccessLevelName to the ComboBox
                cmb_UserAccessLevel.Items.Add(reader["AccessLevelName"].ToString());
            }

            cmb_UserAccessLevel.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_UserAccessLevel.FormattingEnabled = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection x = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
            x.Open();

            SqlCommand accessLevelCommand = new SqlCommand("SELECT AccessLevelID FROM AccessLevels WHERE AccessLevelName = @AccessLevelName", x);
            accessLevelCommand.Parameters.AddWithValue("@AccessLevelName", cmb_UserAccessLevel.Text);
            int accessLevelID = (int)accessLevelCommand.ExecuteScalar();


            SqlCommand com = new SqlCommand("INSERT INTO Users (Username, Password, FirstName, LastName, Email, Contact_No, AccessLevelID, StatusID) VALUES (@Username, @Password, @FirstName, @LastName, @Email, @Contact_No, @AccessLevelID, @StatusID);", x);
            
            com.Parameters.AddWithValue("@Username", txtUsername.Text);
            com.Parameters.AddWithValue("@Password", txtPassword.Text);
            com.Parameters.AddWithValue("@FirstName", txtFName.Text);
            com.Parameters.AddWithValue("@LastName", txtLastName.Text);
            com.Parameters.AddWithValue("@Email", txtEmail.Text);
            com.Parameters.AddWithValue("@Contact_No", txtPhoneNumber.Text); 
            com.Parameters.AddWithValue("@AccessLevelID", accessLevelID);
            com.Parameters.AddWithValue("@StatusID", 1);
            com.ExecuteNonQuery();

            // notify the user
            MessageBox.Show("Successfully added!!");

            txtUsername.Clear();
            txtPassword.Clear();
            txtFName.Clear();
            txtLastName.Clear();
            txtPhoneNumber.Clear();
            txtEmail.Clear();
            cmb_UserAccessLevel.SelectedIndex = -1;

            UserAdded.Invoke(this, EventArgs.Empty);
            x.Close();
        }
    }
}
