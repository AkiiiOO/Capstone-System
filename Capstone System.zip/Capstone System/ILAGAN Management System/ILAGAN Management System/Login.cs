﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class LoginForm : Form
    {
        SqlConnection y = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
        int attempts = 0;
        int maxAttempts = 3;
        
        public LoginForm()
        {
            InitializeComponent();
            CurrentUser.Permissions = new List<int>();
        }

        private void chk_ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_ShowPassword.Checked == true)
            {
                txtpassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }
       
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //Validations

            // Validate that both username and password are not empty
            if (string.IsNullOrEmpty(txtusername.Text) && string.IsNullOrEmpty(txtpassword.Text))
            {
                MessageBox.Show("Both Username and Password cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                attempts++;
                MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (attempts >= maxAttempts)
                {
                    MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                return;
            }

            // Validate that the username is not empty
            if (string.IsNullOrEmpty(txtusername.Text))
            {
                MessageBox.Show("Username cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                attempts++;
                MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (attempts >= maxAttempts)
                {
                    MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                return;
            }

            // Validate that the password is not empty
            if (string.IsNullOrEmpty(txtpassword.Text))
            {
                MessageBox.Show("Password cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                attempts++;
                MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (attempts >= maxAttempts)
                {
                    MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                return;
            }


            try
            {
                string query = @"SELECT u.UserID, u.Username, u.StatusID, u.FirstName, u.LastName, ua.AccessLevelID, al.AccessLevelName 
                 FROM Users u 
                 INNER JOIN UserAccessLevels ua ON u.UserID = ua.UserID 
                 INNER JOIN AccessLevels al ON ua.AccessLevelID = al.AccessLevelID 
                 WHERE u.Username = @Username AND u.Password = @Password";

                SqlCommand command = new SqlCommand(query, y);

                command.Parameters.AddWithValue("@Username", txtusername.Text);
                command.Parameters.AddWithValue("@Password", txtpassword.Text);

                y.Open();

                SqlDataReader dr = command.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    int userID = Convert.ToInt32(dr["UserID"]);
                    string status = dr["StatusID"].ToString();
                    string accessLevelID = dr["AccessLevelID"].ToString();
                    string accessLevelName = dr["AccessLevelName"].ToString();
                    string username = dr["Username"].ToString();
                    string firstName = dr["FirstName"].ToString();
                    string lastName = dr["LastName"].ToString();

                    
                    if (status == "1")
                    {
                        CurrentUser.UserID = userID;
                        CurrentUser.AccessLevel = accessLevelID;
                        CurrentUser.FirstName = firstName;
                        CurrentUser.LastName = lastName;


                        dr.Close();

                        GetUserPermissions(accessLevelID);
                        

                        MessageBox.Show("Welcome " + username);

                        this.Hide();
                        Home form2 = new Home(username);
                        form2.Show();
                    }
                    else
                    {
                        MessageBox.Show("This account is deactivated.", "Deactivated Account", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    
                }
                else
                {
                    LoginAttempt();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                y.Close();
            }
        }

        private void GetUserPermissions(string accessLevelID)
        {
            try
            {
                string permissionsQuery = "SELECT p.PermissionID FROM AccessLevelPermissions alp INNER JOIN Permissions p ON alp.PermissionID = p.PermissionID WHERE alp.AccessLevelID = @AccessLevelID";
                SqlCommand perCommand = new SqlCommand(permissionsQuery, y);
                
                    perCommand.Parameters.AddWithValue("@AccessLevelID", accessLevelID);

                    SqlDataReader permissionsReader = perCommand.ExecuteReader();

                    // Clear existing permissions
                    CurrentUser.Permissions.Clear();

                    while (permissionsReader.Read())
                    {
                        int permissionID = Convert.ToInt32(permissionsReader["PermissionID"]);
                        CurrentUser.Permissions.Add(permissionID);

                    }
                    permissionsReader.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while Getting permissions: " + ex.Message);
            }
        }


        private void LoginAttempt()
        {
            attempts++;
            MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtusername.Clear();
            txtpassword.Clear();
            txtusername.Focus();

            if (attempts >= maxAttempts)
            {
                MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
        }
    }
    public class CurrentUser
    {
        public static int UserID { get; set; }
        public static string AccessLevel { get; set; }
        public static List<int> Permissions { get; set; }
        public static string FirstName { get; set; }
        public static string LastName { get; set; }

    }
}


