﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class LoginForm : Form
    {
        SqlConnection y = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
        int attempts = 0;
        int maxAttempts = 3;
        
        public LoginForm()
        {
            InitializeComponent();
        }

        private void chk_ShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_ShowPassword.Checked == true)
            {
                txtpassword.UseSystemPasswordChar = false;
            }
            else
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }
       
        private void btnLogin_Click(object sender, EventArgs e)
        {
            //Validations

            // Validate that both username and password are not empty
            if (string.IsNullOrEmpty(txtusername.Text) && string.IsNullOrEmpty(txtpassword.Text))
            {
                MessageBox.Show("Both Username and Password cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                attempts++;
                MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (attempts >= maxAttempts)
                {
                    MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                return;
            }

            // Validate that the username is not empty
            if (string.IsNullOrEmpty(txtusername.Text))
            {
                MessageBox.Show("Username cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                attempts++;
                MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (attempts >= maxAttempts)
                {
                    MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                return;
            }

            // Validate that the password is not empty
            if (string.IsNullOrEmpty(txtpassword.Text))
            {
                MessageBox.Show("Password cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                attempts++;
                MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (attempts >= maxAttempts)
                {
                    MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Application.Exit();
                }
                return;
            }


            try
            {
                string query = "SELECT * FROM Users WHERE Username = '" + txtusername.Text + "' AND Password = '" + txtpassword.Text + "'";
                SqlCommand command = new SqlCommand(query, y);

                y.Open();

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                SqlDataReader dr = command.ExecuteReader();

                if (dr.HasRows)
                {
                    dr.Read();
                    string status = dr["StatusID"].ToString();
                    string accessLevel = dr["AccessLevelID"].ToString();

                    if (status == "1")
                    {
                        ulog.type = accessLevel;

                        string username = dr["Username"].ToString();
                        MessageBox.Show("Welcome " + username);

                        this.Hide();
                        Home form2 = new Home(username);
                        form2.Show();
                    }
                    else
                    {
                        MessageBox.Show("This account is deactivated.", "Deactivated Account", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    
                }
                else
                {
                    // Invalid login details
                    attempts++;
                    MessageBox.Show("Invalid Login details. Attempts left: " + (maxAttempts - attempts), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtusername.Clear();
                    txtpassword.Clear();

                    txtusername.Focus();

                    if (attempts >= maxAttempts)
                    {
                        MessageBox.Show("Maximum login attempts reached. Exiting application.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Application.Exit();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                y.Close();
            }
        }
    }

    public static class CurrentUser
    {
        public static int UserID { get; set; }
        public static string AccessLevel { get; set; }
    }

}

