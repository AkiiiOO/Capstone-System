﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ManageSongs : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public ManageSongs()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadSongs();
        }

        private void LoadSongs()
        {
            string query = "SELECT SongID, SongName, Artist FROM Song";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable songTable = new DataTable();
                adapter.Fill(songTable);

                dgv_Song.DataSource = songTable;
                dgv_Song.Columns["SongID"].Visible = false; 

                // Customize column headers
                dgv_Song.Columns["SongName"].HeaderText = "Song";
                dgv_Song.Columns["Artist"].HeaderText = "Artist";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            string songName = txt_SongName.Text.Trim();
            string artist = txt_Artist.Text.Trim();

            if (string.IsNullOrEmpty(txt_SongName.Text) || string.IsNullOrEmpty(txt_Artist.Text))
            {
                MessageBox.Show("Both Song Name and Artist are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (SongExists(songName))
            {
                MessageBox.Show("Song " + songName + " by " + artist + " already exists.", "Duplicate Song", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            string query = "INSERT INTO Song (UserID, SongName, Artist, CreatedBy) VALUES (@UserID, @SongName, @Artist, @CreatedBy)";

            try
            {
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@UserID", currentUserId);
                    command.Parameters.AddWithValue("@SongName", txt_SongName.Text);
                    command.Parameters.AddWithValue("@Artist", txt_Artist.Text);
                    command.Parameters.AddWithValue("@CreatedBy", createdBy); 

                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Song added successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
                LoadSongs(); 
            }
            txt_SongName.Clear();
            txt_Artist.Clear();
            db.Close();
        }
        private bool SongExists(string songName)
        {
            string query = "SELECT COUNT(*) FROM Song WHERE SongName = @SongName";
            int count = 0;

            try
            {
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@SongName", songName);
                db.Open();
                count = (int)command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking song existence: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
            return count > 0;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadSongs();
                return;
            }
            string query = @"SELECT SongID, SongName, Artist  FROM Song 
                             WHERE SongName LIKE @SearchText 
                             OR Artist LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_Song.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_Song.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
