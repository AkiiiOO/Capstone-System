﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class EditClientForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler ClientAdded;

        public EditClientForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            db.Open();
            string query = @"UPDATE Clients 
                             SET FirstName = @FirstName, MiddleName = @MiddleName, LastName = @LastName, Address = @Address, Contact_No = @Contact_No
                             WHERE ClientID = @ClientID";
            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@FirstName", txtFName.Text);
            cmd.Parameters.AddWithValue("@MiddleName", txtMInitial.Text);
            cmd.Parameters.AddWithValue("@LastName", txtLName.Text);
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Contact_No", txtContact_no.Text);

            cmd.ExecuteNonQuery();
            db.Close();
            ClientAdded.Invoke(this, EventArgs.Empty);
            MessageBox.Show("Client details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
