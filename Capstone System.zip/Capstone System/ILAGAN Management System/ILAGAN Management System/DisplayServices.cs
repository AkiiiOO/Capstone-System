﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class DisplayServices : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public DisplayServices()
        {
            InitializeComponent();
            db = y.GetConnection();
            lbl_PackageName.Text = "Origin";
        }
    }
}
