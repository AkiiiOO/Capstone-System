﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ILAGAN_Management_System
{
    class PackCustomizationClass
    {
        public int CasketID { get; set; }
        public int VehicleID { get; set; }
        public int ArrangementID { get; set; }
        public string CasketName { get; set; }
        public string VehicleName { get; set; }
        public string ArrangementName { get; set; }
        public int EmbalmingDays { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
