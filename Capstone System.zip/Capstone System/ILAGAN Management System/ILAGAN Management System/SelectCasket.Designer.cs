﻿namespace ILAGAN_Management_System
{
    partial class SelectCasket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.asd = new System.Windows.Forms.Label();
            this.las = new System.Windows.Forms.Label();
            this.lbl_CasketName = new System.Windows.Forms.Label();
            this.lbl_CasketPrice = new System.Windows.Forms.Label();
            this.picbox_CasketImage = new System.Windows.Forms.PictureBox();
            this.dgv_CasketRecords = new System.Windows.Forms.DataGridView();
            this.btnSelect = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_CasketImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CasketRecords)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(836, 68);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Select Casket";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // txt_search
            // 
            this.txt_search.AccessibleName = "";
            this.txt_search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_search.Location = new System.Drawing.Point(22, 76);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(172, 24);
            this.txt_search.TabIndex = 87;
            this.txt_search.Tag = "";
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // asd
            // 
            this.asd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.asd.AutoSize = true;
            this.asd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.asd.Location = new System.Drawing.Point(512, 214);
            this.asd.Name = "asd";
            this.asd.Size = new System.Drawing.Size(97, 15);
            this.asd.TabIndex = 90;
            this.asd.Text = "Casket Name:";
            // 
            // las
            // 
            this.las.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.las.AutoSize = true;
            this.las.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.las.Location = new System.Drawing.Point(512, 252);
            this.las.Name = "las";
            this.las.Size = new System.Drawing.Size(46, 15);
            this.las.TabIndex = 91;
            this.las.Text = "Price:";
            // 
            // lbl_CasketName
            // 
            this.lbl_CasketName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_CasketName.AutoSize = true;
            this.lbl_CasketName.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.lbl_CasketName.Location = new System.Drawing.Point(637, 214);
            this.lbl_CasketName.Name = "lbl_CasketName";
            this.lbl_CasketName.Size = new System.Drawing.Size(75, 15);
            this.lbl_CasketName.TabIndex = 92;
            this.lbl_CasketName.Text = "-----------------";
            // 
            // lbl_CasketPrice
            // 
            this.lbl_CasketPrice.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_CasketPrice.AutoSize = true;
            this.lbl_CasketPrice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F);
            this.lbl_CasketPrice.Location = new System.Drawing.Point(637, 252);
            this.lbl_CasketPrice.Name = "lbl_CasketPrice";
            this.lbl_CasketPrice.Size = new System.Drawing.Size(75, 15);
            this.lbl_CasketPrice.TabIndex = 93;
            this.lbl_CasketPrice.Text = "-----------------";
            // 
            // picbox_CasketImage
            // 
            this.picbox_CasketImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.picbox_CasketImage.Location = new System.Drawing.Point(640, 76);
            this.picbox_CasketImage.Name = "picbox_CasketImage";
            this.picbox_CasketImage.Size = new System.Drawing.Size(147, 108);
            this.picbox_CasketImage.TabIndex = 89;
            this.picbox_CasketImage.TabStop = false;
            // 
            // dgv_CasketRecords
            // 
            this.dgv_CasketRecords.AllowUserToAddRows = false;
            this.dgv_CasketRecords.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_CasketRecords.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_CasketRecords.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_CasketRecords.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_CasketRecords.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_CasketRecords.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_CasketRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_CasketRecords.Location = new System.Drawing.Point(22, 106);
            this.dgv_CasketRecords.Name = "dgv_CasketRecords";
            this.dgv_CasketRecords.ReadOnly = true;
            this.dgv_CasketRecords.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_CasketRecords.RowHeadersVisible = false;
            this.dgv_CasketRecords.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_CasketRecords.Size = new System.Drawing.Size(471, 208);
            this.dgv_CasketRecords.TabIndex = 166;
            this.dgv_CasketRecords.DoubleClick += new System.EventHandler(this.dgv_CasketRecords_DoubleClick_1);
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnSelect.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnSelect.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnSelect.BorderRadius = 5;
            this.btnSelect.BorderSize = 0;
            this.btnSelect.FlatAppearance.BorderSize = 0;
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.ForeColor = System.Drawing.Color.White;
            this.btnSelect.Location = new System.Drawing.Point(423, 320);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(70, 30);
            this.btnSelect.TabIndex = 88;
            this.btnSelect.Text = "Select";
            this.btnSelect.TextColor = System.Drawing.Color.White;
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // SelectCasket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(836, 362);
            this.Controls.Add(this.dgv_CasketRecords);
            this.Controls.Add(this.lbl_CasketPrice);
            this.Controls.Add(this.lbl_CasketName);
            this.Controls.Add(this.las);
            this.Controls.Add(this.asd);
            this.Controls.Add(this.picbox_CasketImage);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.txt_search);
            this.Controls.Add(this.panel1);
            this.Name = "SelectCasket";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectCasket";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_CasketImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_CasketRecords)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private RoundedButton btnSelect;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.PictureBox picbox_CasketImage;
        private System.Windows.Forms.Label asd;
        private System.Windows.Forms.Label las;
        private System.Windows.Forms.Label lbl_CasketName;
        private System.Windows.Forms.Label lbl_CasketPrice;
        private System.Windows.Forms.DataGridView dgv_CasketRecords;
    }
}