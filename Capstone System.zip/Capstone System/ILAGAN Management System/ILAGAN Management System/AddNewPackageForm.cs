﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewPackageForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler PackageAdded;

        public AddNewPackageForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            decimal price;

            if (!decimal.TryParse(txt_PackagePrice.Text, out price))
            {
                MessageBox.Show("Please enter a valid price.");
                return;
            }


            db.Open();
            string query = "INSERT INTO Package (PackageName, Description, Price) VALUES (@PackageName, @Description, @Price)";

            SqlCommand command = new SqlCommand(query, db);
            command.Parameters.AddWithValue("@PackageName", txt_PackageName.Text);
            command.Parameters.AddWithValue("@Description", txt_Description.Text);
            command.Parameters.AddWithValue("@Price", price);

            try
            {
                int rowsAffected = command.ExecuteNonQuery();
      
                if (rowsAffected > 0)
                {
                    PackageAdded.Invoke(this, EventArgs.Empty);
                    MessageBox.Show("Package added successfully!");
                }
                else
                {
                    MessageBox.Show("Failed to add package.");
                }
            }
            
        catch (Exception ex)
        {
           
            MessageBox.Show("An error occurred: " + ex.Message);
        }


        }

    }
}
