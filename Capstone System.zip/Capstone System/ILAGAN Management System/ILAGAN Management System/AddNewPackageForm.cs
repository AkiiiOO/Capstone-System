﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewPackageForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler PackageAdded;

        private decimal casketPrice = 0.0M;
        private decimal vehiclePrice = 0.0M;
        private decimal flowerPrice = 0.0M;
        private decimal chapelPrice = 0.0M;

        private DateTime startDate;
        private DateTime endDate;
        private TimeSpan startTime;
        private TimeSpan endTime;

        private int selectedCasketID; // done
        private string selectedCasketName; // done
        private int selectedVehicleID; //done
        private string selectedVehicleName; //done
        private int selectedFlowerID;//done
        private string selectedFlowerName;//done
        private int selectedChapelID;
        private string selectedChapelName;
        private int selectedSongID;// done


        public AddNewPackageForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
        
        }

        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;

                selectedCasketID = selectCasketForm.SelectedCasketID;
                selectedCasketName = selectCasketForm.SelectedCasketName;

                UpdatePackagePrice();
            }
        }

        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                selectedVehicleID = selectVehicleForm.SelectedVehicleID;
                selectedVehicleName = selectVehicleForm.SelectedVehicleName;

                UpdatePackagePrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                flowerPrice = selectFlowerForm.SelectedFlowerPrice;
                selectedFlowerID = selectFlowerForm.SelectedFlowerID;
                selectedFlowerName = selectFlowerForm.SelectedFlowerName;

                UpdatePackagePrice();
            }
        }
        private void btn_Chapel_Click(object sender, EventArgs e)
        {
            SelectChapel selectChapelForm = new SelectChapel();
            if (selectChapelForm.ShowDialog() == DialogResult.OK)
            {
                txt_Chapel.Text = selectChapelForm.SelectedChapelName;
                chapelPrice = selectChapelForm.SelectedChapelPrice;

                selectedChapelID = selectChapelForm.SelectedChapelID;
                selectedChapelName = selectChapelForm.SelectedChapelName;

                startDate = selectChapelForm.StartDate;
                endDate = selectChapelForm.EndDate;
                startTime = selectChapelForm.StartTime;
                endTime = selectChapelForm.EndTime;

                InsertChapelReservation(selectedChapelID, selectChapelForm.StartDate, selectChapelForm.StartTime,
                                                            selectChapelForm.EndDate, selectChapelForm.EndTime);

                UpdatePackagePrice();
            }
        }

        private void btn_Song_Click(object sender, EventArgs e)
        {
            SelectSong selectSongForm = new SelectSong();
            if (selectSongForm.ShowDialog() == DialogResult.OK)
            {
                string songDetails = selectSongForm.SelectedSongName + ", " +
                                 selectSongForm.SelectedArtistName + ", " +
                                 selectSongForm.SelectedGenre;

                txt_Song.Text = songDetails;

                selectedSongID = selectSongForm.SelectedSongID;
            }
        }

        private void UpdatePackagePrice()
        {
            decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + chapelPrice;
            txt_PackagePrice.Text = totalPrice.ToString("F2");
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            try
            {
                InsertPackage();
                PackageAdded.Invoke(this, EventArgs.Empty);
                MessageBox.Show("Package added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding package: " + ex.Message);
            }

        }
        private void InsertChapelReservation(int chapelID, DateTime startDate, TimeSpan startTime, DateTime endDate, TimeSpan endTime)
        {
            string insertChapelReservationQuery = @"INSERT INTO ChapelReservation (ChapelID, StartDate, StartTime, EndDate, EndTime, ReservedBy) 
                                            OUTPUT INSERTED.ReservationID 
                                            VALUES (@ChapelID, @StartDate, @StartTime, @EndDate, @EndTime, @ReservedBy)";

            SqlCommand insertChapelReservationCmd = new SqlCommand(insertChapelReservationQuery, db);
            insertChapelReservationCmd.Parameters.AddWithValue("@ChapelID", chapelID);
            insertChapelReservationCmd.Parameters.AddWithValue("@StartDate", startDate);
            insertChapelReservationCmd.Parameters.AddWithValue("@StartTime", startTime);
            insertChapelReservationCmd.Parameters.AddWithValue("@EndDate", endDate);
            insertChapelReservationCmd.Parameters.AddWithValue("@EndTime", endTime);
            insertChapelReservationCmd.Parameters.AddWithValue("@ReservedBy", DBNull.Value);

            insertChapelReservationCmd.ExecuteNonQuery();
        }
        private void InsertPackage()
        {
            string insertPackageQuery = @"INSERT INTO Package (CasketID, CasketName, CasketPrice, VehicleID, VehicleName, VehiclePrice, FlowerID, FlowerName, FlowerPrice, ChapelID, ChapelName, ChapelPrice, SongID, TotalPrice)
                                         VALUES (@CasketID, @CasketName, @CasketPrice, @VehicleID, @VehicleName, @VehiclePrice, @FlowerID, @FlowerName, @FlowerPrice, @ChapelID, @ChapelName, @ChapelPrice, @SongID, @TotalPrice)";

            SqlCommand insertPackageCmd = new SqlCommand(insertPackageQuery, db);
            insertPackageCmd.Parameters.AddWithValue("@CasketID", selectedCasketID);
            insertPackageCmd.Parameters.AddWithValue("@CasketName", selectedCasketName);
            insertPackageCmd.Parameters.AddWithValue("@CasketPrice", casketPrice);
            insertPackageCmd.Parameters.AddWithValue("@VehicleID", selectedVehicleID);
            insertPackageCmd.Parameters.AddWithValue("@VehicleName", selectedVehicleName);
            insertPackageCmd.Parameters.AddWithValue("@VehiclePrice", vehiclePrice);
            insertPackageCmd.Parameters.AddWithValue("@FlowerID", selectedFlowerID);
            insertPackageCmd.Parameters.AddWithValue("@FlowerName", selectedFlowerName);
            insertPackageCmd.Parameters.AddWithValue("@FlowerPrice", flowerPrice);
            insertPackageCmd.Parameters.AddWithValue("@ChapelID", selectedChapelID);
            insertPackageCmd.Parameters.AddWithValue("@ChapelName", selectedChapelName);
            insertPackageCmd.Parameters.AddWithValue("@ChapelPrice", chapelPrice);
            insertPackageCmd.Parameters.AddWithValue("@SongID", selectedSongID);
            insertPackageCmd.Parameters.AddWithValue("@TotalPrice", casketPrice + vehiclePrice + flowerPrice + chapelPrice);

            insertPackageCmd.ExecuteNonQuery();
        }

    }
}
