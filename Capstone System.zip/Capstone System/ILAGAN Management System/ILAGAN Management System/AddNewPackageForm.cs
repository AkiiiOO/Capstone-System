﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewPackageForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler PackageAdded;

        private decimal casketPrice = 0.0M;
        private decimal vehiclePrice = 0.0M;
        private decimal flowerPrice = 0.0M;
        private decimal chapelPrice = 0.0M;

        public DateTime StartDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public DateTime EndDate { get; set; }
        public TimeSpan EndTime { get; set; }

        public int SelectedCasketID { get; set; } // done
        public int SelectedVehicleID { get; set; } //done
        public int SelectedFlowerID { get; set; } //done
        public int SelectedSongID { get; set; } //done
        public int SelectedChapelID { get; private set; } //done
        public string SelectedChapelName { get; set; } //done

        public AddNewPackageForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
        
        }

        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;

                UpdatePackagePrice();
            }
        }

        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;

                UpdatePackagePrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                flowerPrice = selectFlowerForm.SelectedFlowerPrice;

                UpdatePackagePrice();
            }
        }
        private void btn_Chapel_Click(object sender, EventArgs e)
        {
            SelectChapel selectChapelForm = new SelectChapel();
            if (selectChapelForm.ShowDialog() == DialogResult.OK)
            {
                txt_Chapel.Text = selectChapelForm.SelectedChapelName;
                chapelPrice = selectChapelForm.SelectedChapelPrice;

                UpdatePackagePrice();
            }
        }

        private void btn_Song_Click(object sender, EventArgs e)
        {
            SelectSong selectSongForm = new SelectSong();
            if (selectSongForm.ShowDialog() == DialogResult.OK)
            {
                string songDetails = selectSongForm.SelectedSongName + ", " +
                                 selectSongForm.SelectedArtistName + ", " +
                                 selectSongForm.SelectedGenre;

                txt_Song.Text = songDetails;
            }
        }

        private void UpdatePackagePrice()
        {
            decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + chapelPrice;
            txt_PackagePrice.Text = totalPrice.ToString("F2");
        }

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (db.State != ConnectionState.Open)
                {
                    db.Open();
                }
                InsertChapelReservation();

                InsertPackage();
                PackageAdded.Invoke(this, EventArgs.Empty);
                MessageBox.Show("Package added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding package: " + ex.Message);
            }
            finally
            {
                if (db.State != ConnectionState.Open)
                {
                    db.Close();
                }
            }

        }
        private void InsertChapelReservation()
        {
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            string insertChapelReservationQuery = @"INSERT INTO ChapelReservation (ChapelID, StartDate, StartTime, EndDate, EndTime, ReservedBy) 
                                            OUTPUT INSERTED.ReservationID 
                                            VALUES (@ChapelID, @StartDate, @StartTime, @EndDate, @EndTime, @ReservedBy)";

            SqlCommand insertChapelReservationCmd = new SqlCommand(insertChapelReservationQuery, db);
            insertChapelReservationCmd.Parameters.AddWithValue("@ChapelID", SelectedChapelID);
            insertChapelReservationCmd.Parameters.AddWithValue("@StartDate", StartDate);
            insertChapelReservationCmd.Parameters.AddWithValue("@StartTime", StartTime);
            insertChapelReservationCmd.Parameters.AddWithValue("@EndDate", EndDate);
            insertChapelReservationCmd.Parameters.AddWithValue("@EndTime", EndTime);
            insertChapelReservationCmd.Parameters.AddWithValue("@ReservedBy", createdBy);

            insertChapelReservationCmd.ExecuteNonQuery();
        }
        private void InsertPackage()
        {
            string insertPackageQuery = @"INSERT INTO Package (PackageName, CasketID, LightID, SongID, VehicleID, ArrangementID, 
                                                               ReservationID, ChapelName, CasketName, VehicleName, 
                                                               FlowerArrangementName, EmbalmingDays, TotalPrice)VALUES 
                                                              (@PackageName, @CasketID, @LightID, @SongID, @VehicleID, 
                                                               @ArrangementID, @ReservationID, @ChapelName, @CasketName, 
                                                               @VehicleName, @FlowerArrangementName, @EmbalmingDays, @TotalPrice)";

            SqlCommand insertPackageCmd = new SqlCommand(insertPackageQuery, db);
            
            insertPackageCmd.Parameters.AddWithValue("@PackageName", txt_PackageName.Text);
            insertPackageCmd.Parameters.AddWithValue("@CasketID", SelectedCasketID);
            insertPackageCmd.Parameters.AddWithValue("@VehicleID", SelectedVehicleID);
            insertPackageCmd.Parameters.AddWithValue("@ArrangementID", SelectedFlowerID);
            insertPackageCmd.Parameters.AddWithValue("@LightID", "1");
            insertPackageCmd.Parameters.AddWithValue("@SongID", SelectedSongID);
            insertPackageCmd.Parameters.AddWithValue("@ReservationID", DBNull.Value);
            insertPackageCmd.Parameters.AddWithValue("@ChapelName", SelectedChapelName); 
            insertPackageCmd.Parameters.AddWithValue("@CasketName", txt_Casket.Text);
            insertPackageCmd.Parameters.AddWithValue("@VehicleName", txt_Vehicle.Text);
            insertPackageCmd.Parameters.AddWithValue("@FlowerArrangementName", txt_Flower.Text);
            insertPackageCmd.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? (object)DBNull.Value : Convert.ToInt32(txt_EmbalmingDays.Text)); // Get from your UI if applicable
            insertPackageCmd.Parameters.AddWithValue("@TotalPrice", casketPrice + vehiclePrice + flowerPrice + chapelPrice); 

            insertPackageCmd.ExecuteNonQuery();
        }

    }
}
