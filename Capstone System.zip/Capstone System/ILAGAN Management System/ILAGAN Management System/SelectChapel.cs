﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class SelectChapel : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public int SelectedChapelID { get; private set; }
        public string SelectedChapelName { get; set; }
        public decimal SelectedChapelPrice { get; set; }
        public DateTime StartDate { get; set; }
        public TimeSpan StartTime { get; set; }
        public DateTime EndDate { get; set; }
        public TimeSpan EndTime { get; set; }

        public SelectChapel()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadChapelRecords();
        }

        private void LoadChapelRecords()
        {
            db.Open();
            // Display UsersTable
            string query = @"SELECT c.ChapelID, c.ChapelName, c.Capacity, c.Location, 
                             c.Price
                             FROM Chapel c";

            SqlCommand command = new SqlCommand(query, db);
            SqlDataAdapter dt = new SqlDataAdapter(command);
            DataTable ClientsTable = new DataTable();
            dt.Fill(ClientsTable);
            dgv_ChapelRecords.DataSource = ClientsTable;
            db.Close();
        }

        private void dgv_ChapelRecords_Click(object sender, EventArgs e)
        {
            if (dgv_ChapelRecords.SelectedRows.Count > 0)
            {
                // Get the selected casket's data
                DataRowView selectedRow = (DataRowView)dgv_ChapelRecords.SelectedRows[0].DataBoundItem;

                SelectedChapelName = selectedRow["ChapelName"].ToString();
                SelectedChapelPrice = (decimal)selectedRow["Price"];
                SelectedChapelID = (int)selectedRow["ChapelID"];

                txt_Location.Text = SelectedChapelName;
                txt_Price.Text = SelectedChapelPrice.ToString("F2");
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (SelectedChapelName != null)
            {
                StartDate = dtp_StartDate.Value.Date;
                StartTime = dtp_StartTime.Value.TimeOfDay;
                EndDate = dtp_EndDate.Value.Date;
                EndTime = dtp_EndTime.Value.TimeOfDay;

                this.DialogResult = DialogResult.OK;
                this.Close(); // Close the form
            }
            else
            {
                MessageBox.Show("Please select a casket.");
            }
        }
    }
}
