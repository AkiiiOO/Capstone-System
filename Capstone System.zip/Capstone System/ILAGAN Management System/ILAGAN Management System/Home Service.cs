﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class Home_Service : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public Home_Service()
        {
            InitializeComponent();
            db = y.GetConnection();
            
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (txt_homelocation == null)
            {
                MessageBox.Show("Input a location.");
            }
            string query = @"INSERT INTO ChapelReservation (ChapelID, ClientID, StartDate, StartTime, EndDate, EndTime, Location, ReservedBy)
                     VALUES (NULL, @ClientID, @StartDate, @StartTime, @EndDate, @EndTime, @Location, @ReservedBy)";
            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ClientID", 1);  // Assume you have ClientID
                command.Parameters.AddWithValue("@StartDate", 1);
                command.Parameters.AddWithValue("@StartTime", 1);
                command.Parameters.AddWithValue("@EndDate", 1);
                command.Parameters.AddWithValue("@EndTime", 1);
                command.Parameters.AddWithValue("@Location", 1);
                command.Parameters.AddWithValue("@ReservedBy", 1);

                try
                {
                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Home service reservation saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving home service reservation: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }

    }
}
