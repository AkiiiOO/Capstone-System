﻿namespace ILAGAN_Management_System
{
    partial class ProceedPaymentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.cmb_Discount = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_Totalprice = new System.Windows.Forms.Label();
            this.lbl_ClientName = new System.Windows.Forms.Label();
            this.lbl_DiscountApplied = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.cmb_PaymentOption = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label23 = new System.Windows.Forms.Label();
            this.cmb_InstallmentPlan = new System.Windows.Forms.ComboBox();
            this.dgv_Installment = new System.Windows.Forms.DataGridView();
            this.dgv_ServiceRequests = new System.Windows.Forms.DataGridView();
            this.lbl_FinalPrice = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_RemainingBalance = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txt_AmountPaid = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl_Change = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btn_submitPayment = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Installment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ServiceRequests)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(904, 68);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Payment";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 370);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 16);
            this.label3.TabIndex = 47;
            this.label3.Text = "Discount:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 252);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 16);
            this.label2.TabIndex = 45;
            this.label2.Text = "Client Name:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Location = new System.Drawing.Point(30, 99);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(400, 2);
            this.panel2.TabIndex = 44;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(192, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "Charge To.";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DimGray;
            this.panel3.Location = new System.Drawing.Point(30, 357);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(400, 2);
            this.panel3.TabIndex = 45;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(165, 338);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(139, 16);
            this.label7.TabIndex = 54;
            this.label7.Text = "Discount Information";
            // 
            // cmb_Discount
            // 
            this.cmb_Discount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Discount.FormattingEnabled = true;
            this.cmb_Discount.Location = new System.Drawing.Point(149, 365);
            this.cmb_Discount.Name = "cmb_Discount";
            this.cmb_Discount.Size = new System.Drawing.Size(215, 26);
            this.cmb_Discount.TabIndex = 73;
            this.cmb_Discount.SelectedIndexChanged += new System.EventHandler(this.cmb_Discount_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(28, 283);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 16);
            this.label10.TabIndex = 80;
            this.label10.Text = "Total Price:";
            // 
            // lbl_Totalprice
            // 
            this.lbl_Totalprice.AutoSize = true;
            this.lbl_Totalprice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Totalprice.Location = new System.Drawing.Point(148, 279);
            this.lbl_Totalprice.Name = "lbl_Totalprice";
            this.lbl_Totalprice.Size = new System.Drawing.Size(143, 18);
            this.lbl_Totalprice.TabIndex = 183;
            this.lbl_Totalprice.Text = "_______________";
            // 
            // lbl_ClientName
            // 
            this.lbl_ClientName.AutoSize = true;
            this.lbl_ClientName.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ClientName.Location = new System.Drawing.Point(148, 250);
            this.lbl_ClientName.Name = "lbl_ClientName";
            this.lbl_ClientName.Size = new System.Drawing.Size(143, 18);
            this.lbl_ClientName.TabIndex = 184;
            this.lbl_ClientName.Text = "_______________";
            // 
            // lbl_DiscountApplied
            // 
            this.lbl_DiscountApplied.AutoSize = true;
            this.lbl_DiscountApplied.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DiscountApplied.Location = new System.Drawing.Point(146, 405);
            this.lbl_DiscountApplied.Name = "lbl_DiscountApplied";
            this.lbl_DiscountApplied.Size = new System.Drawing.Size(143, 18);
            this.lbl_DiscountApplied.TabIndex = 189;
            this.lbl_DiscountApplied.Text = "_______________";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(27, 407);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(109, 16);
            this.label19.TabIndex = 188;
            this.label19.Text = "Discount Applied:";
            // 
            // cmb_PaymentOption
            // 
            this.cmb_PaymentOption.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_PaymentOption.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_PaymentOption.FormattingEnabled = true;
            this.cmb_PaymentOption.Location = new System.Drawing.Point(597, 107);
            this.cmb_PaymentOption.Name = "cmb_PaymentOption";
            this.cmb_PaymentOption.Size = new System.Drawing.Size(215, 26);
            this.cmb_PaymentOption.TabIndex = 191;
            this.cmb_PaymentOption.SelectedIndexChanged += new System.EventHandler(this.cmb_PaymentOption_SelectedIndexChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(475, 112);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(106, 16);
            this.label20.TabIndex = 190;
            this.label20.Text = "Payment Option:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(627, 80);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(110, 16);
            this.label21.TabIndex = 193;
            this.label21.Text = "Payment Option";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Location = new System.Drawing.Point(478, 99);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(400, 2);
            this.panel4.TabIndex = 192;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(594, 301);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(185, 16);
            this.label22.TabIndex = 195;
            this.label22.Text = "Installment Payment Details";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DimGray;
            this.panel5.Location = new System.Drawing.Point(478, 320);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(400, 2);
            this.panel5.TabIndex = 194;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(475, 333);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 16);
            this.label23.TabIndex = 196;
            this.label23.Text = "Installment Plan:";
            // 
            // cmb_InstallmentPlan
            // 
            this.cmb_InstallmentPlan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_InstallmentPlan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_InstallmentPlan.FormattingEnabled = true;
            this.cmb_InstallmentPlan.Location = new System.Drawing.Point(597, 328);
            this.cmb_InstallmentPlan.Name = "cmb_InstallmentPlan";
            this.cmb_InstallmentPlan.Size = new System.Drawing.Size(215, 26);
            this.cmb_InstallmentPlan.TabIndex = 197;
            this.cmb_InstallmentPlan.SelectedIndexChanged += new System.EventHandler(this.cmb_InstallmentPlan_SelectedIndexChanged);
            // 
            // dgv_Installment
            // 
            this.dgv_Installment.AllowUserToAddRows = false;
            this.dgv_Installment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Installment.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_Installment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_Installment.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_Installment.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Installment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Installment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Installment.Location = new System.Drawing.Point(478, 360);
            this.dgv_Installment.Name = "dgv_Installment";
            this.dgv_Installment.ReadOnly = true;
            this.dgv_Installment.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_Installment.RowHeadersVisible = false;
            this.dgv_Installment.Size = new System.Drawing.Size(395, 120);
            this.dgv_Installment.TabIndex = 198;
            // 
            // dgv_ServiceRequests
            // 
            this.dgv_ServiceRequests.AllowUserToAddRows = false;
            this.dgv_ServiceRequests.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_ServiceRequests.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_ServiceRequests.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_ServiceRequests.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_ServiceRequests.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_ServiceRequests.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_ServiceRequests.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_ServiceRequests.Location = new System.Drawing.Point(29, 118);
            this.dgv_ServiceRequests.Name = "dgv_ServiceRequests";
            this.dgv_ServiceRequests.ReadOnly = true;
            this.dgv_ServiceRequests.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_ServiceRequests.RowHeadersVisible = false;
            this.dgv_ServiceRequests.Size = new System.Drawing.Size(401, 114);
            this.dgv_ServiceRequests.TabIndex = 203;
            // 
            // lbl_FinalPrice
            // 
            this.lbl_FinalPrice.AutoSize = true;
            this.lbl_FinalPrice.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_FinalPrice.Location = new System.Drawing.Point(146, 439);
            this.lbl_FinalPrice.Name = "lbl_FinalPrice";
            this.lbl_FinalPrice.Size = new System.Drawing.Size(143, 18);
            this.lbl_FinalPrice.TabIndex = 205;
            this.lbl_FinalPrice.Text = "_______________";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(27, 441);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 16);
            this.label5.TabIndex = 204;
            this.label5.Text = "Final Price:";
            // 
            // lbl_RemainingBalance
            // 
            this.lbl_RemainingBalance.AutoSize = true;
            this.lbl_RemainingBalance.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_RemainingBalance.Location = new System.Drawing.Point(636, 216);
            this.lbl_RemainingBalance.Name = "lbl_RemainingBalance";
            this.lbl_RemainingBalance.Size = new System.Drawing.Size(143, 18);
            this.lbl_RemainingBalance.TabIndex = 211;
            this.lbl_RemainingBalance.Text = "_______________";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(510, 220);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(124, 16);
            this.label24.TabIndex = 210;
            this.label24.Text = "Remaining Balance:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(624, 153);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(141, 16);
            this.label17.TabIndex = 209;
            this.label17.Text = "Payment Information";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DimGray;
            this.panel6.Location = new System.Drawing.Point(478, 172);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 2);
            this.panel6.TabIndex = 208;
            // 
            // txt_AmountPaid
            // 
            this.txt_AmountPaid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AmountPaid.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_AmountPaid.Location = new System.Drawing.Point(639, 184);
            this.txt_AmountPaid.Name = "txt_AmountPaid";
            this.txt_AmountPaid.Size = new System.Drawing.Size(215, 25);
            this.txt_AmountPaid.TabIndex = 207;
            this.txt_AmountPaid.TextChanged += new System.EventHandler(this.txt_AmountPaid_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(510, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 16);
            this.label8.TabIndex = 206;
            this.label8.Text = "Amount Paid:";
            // 
            // lbl_Change
            // 
            this.lbl_Change.AutoSize = true;
            this.lbl_Change.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Change.Location = new System.Drawing.Point(636, 252);
            this.lbl_Change.Name = "lbl_Change";
            this.lbl_Change.Size = new System.Drawing.Size(143, 18);
            this.lbl_Change.TabIndex = 213;
            this.lbl_Change.Text = "_______________";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(510, 256);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 16);
            this.label9.TabIndex = 212;
            this.label9.Text = "Change:";
            // 
            // btn_submitPayment
            // 
            this.btn_submitPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_submitPayment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_submitPayment.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_submitPayment.BorderRadius = 5;
            this.btn_submitPayment.BorderSize = 0;
            this.btn_submitPayment.FlatAppearance.BorderSize = 0;
            this.btn_submitPayment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_submitPayment.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_submitPayment.ForeColor = System.Drawing.Color.White;
            this.btn_submitPayment.Location = new System.Drawing.Point(752, 493);
            this.btn_submitPayment.Name = "btn_submitPayment";
            this.btn_submitPayment.Size = new System.Drawing.Size(126, 30);
            this.btn_submitPayment.TabIndex = 76;
            this.btn_submitPayment.Text = "Submit Payment";
            this.btn_submitPayment.TextColor = System.Drawing.Color.White;
            this.btn_submitPayment.UseVisualStyleBackColor = false;
            this.btn_submitPayment.Click += new System.EventHandler(this.btn_submitPayment_Click);
            // 
            // ProceedPaymentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(904, 537);
            this.Controls.Add(this.lbl_Change);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbl_RemainingBalance);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.txt_AmountPaid);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbl_FinalPrice);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dgv_ServiceRequests);
            this.Controls.Add(this.dgv_Installment);
            this.Controls.Add(this.cmb_InstallmentPlan);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.cmb_PaymentOption);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.lbl_DiscountApplied);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lbl_ClientName);
            this.Controls.Add(this.lbl_Totalprice);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btn_submitPayment);
            this.Controls.Add(this.cmb_Discount);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ProceedPaymentForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProceedPaymentForm";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Installment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_ServiceRequests)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmb_Discount;
        private RoundedButton btn_submitPayment;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_Totalprice;
        private System.Windows.Forms.Label lbl_ClientName;
        private System.Windows.Forms.Label lbl_DiscountApplied;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cmb_PaymentOption;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ComboBox cmb_InstallmentPlan;
        private System.Windows.Forms.DataGridView dgv_Installment;
        private System.Windows.Forms.DataGridView dgv_ServiceRequests;
        private System.Windows.Forms.Label lbl_FinalPrice;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_RemainingBalance;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txt_AmountPaid;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_Change;
        private System.Windows.Forms.Label label9;
    }
}