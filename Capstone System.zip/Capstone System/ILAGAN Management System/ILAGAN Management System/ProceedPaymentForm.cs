﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ProceedPaymentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler PaymentAdded;

        private List<DataGridViewRow> selectedRows;

        private decimal totalPrice;
        private decimal discountedPrice;

        private int existingDiscountID = 0; 

        public ProceedPaymentForm(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            LoadAvailableDiscounts();
            LoadPaymentOptions();
            LoadInstallmentPlans();
            LoadServiceRequestDetails();
        }
        //Loads discounts from the database into the ComboBox
        private void LoadAvailableDiscounts()
        {
            string query = "SELECT DiscountID, DiscountName, DiscountRate FROM Discounts"; 
            SqlCommand cmd = new SqlCommand(query, db);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

                // Populate ComboBox
                cmb_Discount.DataSource = dt;
                cmb_Discount.DisplayMember = "DiscountName"; // Show the discount name
                cmb_Discount.ValueMember = "DiscountID"; // Use DiscountID as the value

                cmb_Discount.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading discounts: " + ex.Message);
            }
            finally
            {
                db.Close(); 
            }
        }
        private void btn_View_Click(object sender, EventArgs e)
        {
            if (selectedRows == null || selectedRows.Count == 0)
            {
                MessageBox.Show("No service requests selected to view.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            SharedState.SelectedRows = selectedRows;
            DisplayServices DisplayServices = new DisplayServices(selectedRows);
            DisplayServices.ShowDialog();
        }
        private void LoadServiceRequestDetails()
        {
            existingDiscountID = 0;

            if (selectedRows.Count > 0)
            {
                var clientName = selectedRows[0].Cells["Client"].Value.ToString();
                lbl_ClientName.Text = clientName; 

                DataTable dt = new DataTable();
                dt.Columns.Add("Service Request ID");
                dt.Columns.Add("Sub Total");
                dt.Columns.Add("Discount Total");


                totalPrice = 0;

                foreach (var row in selectedRows)
                {
                    dt.Rows.Add(
                        row.Cells["ServiceRequestID"].Value.ToString(),
                        row.Cells["Sub Total"].Value.ToString(),
                        row.Cells["Discount Total"].Value.ToString()
                    );

                    totalPrice += Convert.ToDecimal(row.Cells["Sub Total"].Value);
                    discountedPrice += Convert.ToDecimal(row.Cells["Discount Total"].Value);

                    if (row.Cells["DiscountID"].Value != DBNull.Value)
                    {
                        existingDiscountID = Convert.ToInt32(row.Cells["DiscountID"].Value);
                        
                    }
                }
                dgv_ServiceRequests.DataSource = dt;

                lbl_Subtotal.Text = "₱ " + totalPrice.ToString("F2");
                LoadExistingDiscount(existingDiscountID);
            }
        }
        //Retrieves the discount rate for a specific discount ID from the database
        private decimal GetDiscountRate(int discountID)
        {
            decimal discountRate = 0;

            string query = "SELECT DiscountRate FROM Discounts WHERE DiscountID = @DiscountID";
            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                cmd.Parameters.AddWithValue("@DiscountID", discountID);

                try
                {
                    db.Open();
                    discountRate = (decimal)cmd.ExecuteScalar(); // Retrieve the discount rate
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error fetching discount rate: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }

            return discountRate;
        }
        private void LoadExistingDiscount(int existingDiscountID)
        {
            if (existingDiscountID > 0)
            {
                cmb_Discount.SelectedValue = existingDiscountID;
                decimal existingDiscountRate = GetDiscountRate(existingDiscountID);
                lbl_DiscountApplied.Text = existingDiscountRate.ToString("F2") + "%";

                lbl_FinalPrice.Text = "₱ " +  discountedPrice.ToString("F2");

                CalculateFinalPrice(existingDiscountRate);
            }
            else
            {
                cmb_Discount.SelectedValue = -1;
                lbl_DiscountApplied.Text = "0%";
                CalculateFinalPrice(0); // Calculate without any discount
            }
        }
        private void CalculateFinalPrice(decimal discountRate)
        {
            decimal finalPrice = discountRate > 0 ? totalPrice - (totalPrice * (discountRate / 100)) : totalPrice;
            lbl_FinalPrice.Text = "₱ " + finalPrice.ToString("F2");
        }
        private void cmb_Discount_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Discount.SelectedValue != null)
            {
                int discountID;
                if (int.TryParse(cmb_Discount.SelectedValue.ToString(), out discountID))
                {
                    // Get the selected discount rate
                    decimal newDiscountRate = GetDiscountRate(discountID);
                    lbl_DiscountApplied.Text = newDiscountRate.ToString("F2") + "%";
                    CalculateFinalPrice(newDiscountRate);
                }
            }
            else
            {
                // If the selected value is not a valid ID (like -1 for no discount), handle it here
                lbl_DiscountApplied.Text = "0%";
                CalculateFinalPrice(0); // Recalculate final price without discount
            }
        }
        // for payment option show 
        private void LoadPaymentOptions()
        {
            string query = "SELECT PaymentOptionID, PaymenOptionName FROM PaymentOptions";
            SqlCommand cmd = new SqlCommand(query, db);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

                // Populate ComboBox for payment options
                cmb_PaymentOption.DataSource = dt;
                cmb_PaymentOption.DisplayMember = "PaymenOptionName"; 
                cmb_PaymentOption.ValueMember = "PaymentOptionID"; 

                cmb_PaymentOption.SelectedIndex = -1; // No selection initially
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading payment options: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
        private void cmb_PaymentOption_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_PaymentOption.SelectedValue != null)
            {
                DataRowView selectedRow = (DataRowView)cmb_PaymentOption.SelectedItem;

                // Extract the PaymentOptionID from the DataRowView
                int paymentOptionID = Convert.ToInt32(selectedRow["PaymentOptionID"]);

                if (paymentOptionID == 2)
                {
                    cmb_InstallmentPlan.Visible = true;
                    lbl_payment.Text = "Downpayment:";
                }
                else
                {
                    cmb_InstallmentPlan.Visible = false; // Hide installment plans
                }
            }
        }

        private void txt_AmountPaid_TextChanged(object sender, EventArgs e)
        {
            decimal amountPaid;

            if (decimal.TryParse(txt_AmountPaid.Text, out amountPaid))
            {
                // Get the final price from the label
                decimal finalPrice = GetRealPrice(lbl_FinalPrice.Text);

                // Calculate the remaining balance
                decimal remainingBalance = finalPrice - amountPaid;

                if (remainingBalance < 0) // Paid more than final price
                {
                    lbl_RemainingBalance.Text = "0.00"; // Clear remaining balance
                    decimal change = Math.Abs(remainingBalance); // Calculate change
                    lbl_Change.Text = "₱ " + change.ToString("F2"); // Display the change
                }
                else // Normal case
                {
                    lbl_RemainingBalance.Text = "₱ " + remainingBalance.ToString("F2");
                    lbl_Change.Text = "0.00"; // Reset change label
                }
            }
            else
            {
                // Clear remaining balance and change if the input is not valid
                lbl_RemainingBalance.Text = "0.00";
                lbl_Change.Text = "0.00";
            }
        }
        private void LoadInstallmentPlans()
        {
            string query = "SELECT InstallmentPlanID, PlanName FROM InstallmentPlans";
            SqlCommand cmd = new SqlCommand(query, db);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

                // Populate the combo box with installment plans
                cmb_InstallmentPlan.DataSource = dt;
                cmb_InstallmentPlan.DisplayMember = "PlanName";       
                cmb_InstallmentPlan.ValueMember = "InstallmentPlanID";

                cmb_InstallmentPlan.SelectedIndex = -1;           
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading installment plans: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void cmb_InstallmentPlan_SelectedIndexChanged(object sender, EventArgs e)
        {
            dgv_Installment.DataSource = null;

            if (cmb_InstallmentPlan.SelectedItem != null)
            {
                if (cmb_PaymentOption.SelectedItem != null)
                {
                    decimal downPayment;
                    if (string.IsNullOrEmpty(txt_AmountPaid.Text) || !decimal.TryParse(txt_AmountPaid.Text, out downPayment) || downPayment <= 0)
                    {
                        MessageBox.Show("Please enter a valid down payment amount to proceed.", "Down Payment Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        cmb_InstallmentPlan.SelectedIndex = -1;
                        return; 
                    }
                }

                var selectedRow = cmb_InstallmentPlan.SelectedItem as DataRowView;
                if (selectedRow != null)
                {
                    int installmentPlanID = Convert.ToInt32(selectedRow["InstallmentPlanID"]);

                    string query = "SELECT NumberOfPayments, PaymentInterval FROM InstallmentPlans WHERE InstallmentPlanID = @InstallmentPlanID";

                    using (SqlCommand cmd = new SqlCommand(query, db))
                    {
                        cmd.Parameters.AddWithValue("@InstallmentPlanID", installmentPlanID);

                        try
                        {
                            // Open the connection if it's not already open
                            if (db.State == ConnectionState.Closed)
                            {
                                db.Open();
                            }

                            using (SqlDataReader reader = cmd.ExecuteReader())
                            {
                                if (reader.Read())
                                {
                                    int numberOfPayments = reader.GetInt32(0);
                                    string paymentInterval = reader.GetString(1);

                                    // Display the installment schedule or calculate dates/amounts
                                    CalculateInstallmentSchedule(numberOfPayments, paymentInterval);
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error loading installment plan details: " + ex.Message);
                        }
                        finally
                        {
                            // Ensure the connection is closed after the operation
                            if (db.State == ConnectionState.Open)
                            {
                                db.Close();
                            }
                        }
                    }
                }
            }
        }
        private void CalculateInstallmentSchedule(int numberOfPayments, string paymentInterval)
        {
            decimal finalPrice = GetRealPrice(lbl_RemainingBalance.Text);
                decimal amountPerInstallment = finalPrice / numberOfPayments;

                DataTable installmentTable = new DataTable();
                installmentTable.Columns.Add("Installment Number", typeof(int));
                installmentTable.Columns.Add("Due Date", typeof(DateTime));
                installmentTable.Columns.Add("Amount Due", typeof(decimal));

                DateTime dueDate = DateTime.Now.Date;
                if (paymentInterval == "Monthly")
                {
                    dueDate = dueDate.AddMonths(1);
                }
                else // Assuming "Bi-Weekly"
                {

                    dueDate = dueDate.AddDays(14);
                }

                for (int i = 1; i <= numberOfPayments; i++)
                {
                    installmentTable.Rows.Add(i, dueDate, Math.Round(amountPerInstallment, 2));

                    if (paymentInterval == "Monthly")
                    {
                        dueDate = dueDate.AddMonths(1);
                    }
                    else // Assuming "Bi-Weekly"
                    {
                        dueDate = dueDate.AddDays(14);
                    }
                }
                dgv_Installment.DataSource = installmentTable;
        }
        private decimal GetRealPrice(string labelText)
        {
            // Remove "₱" symbol and parse the remaining text to decimal
            string priceText = labelText.Replace("₱", "").Trim();
            decimal price = 0;

            if (decimal.TryParse(priceText, out price))
            {
                return price;
            }
            else
            {
                return 0; // Return 0 if parsing fails
            }
        }
        private void btn_submitPayment_Click(object sender, EventArgs e)
        {
            string validationMessage = ValidatePaymentInputs();
            if (!string.IsNullOrEmpty(validationMessage))
            {
                MessageBox.Show(validationMessage, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult dialogResult = MessageBox.Show("Do you want to proceed with the payment?", "Confirm Payment", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialogResult == DialogResult.Yes)
            {
                string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;
                int paymentID = SavePayment(createdBy);

                if (paymentID > 0) // If payment saved successfully
                {
                    SavePaymentServiceRequests(paymentID);

                    if (cmb_InstallmentPlan.Visible && cmb_InstallmentPlan.SelectedValue != null)
                    {
                        int installmentPlanID = Convert.ToInt32(cmb_InstallmentPlan.SelectedValue);
                        SaveInstallments(paymentID, installmentPlanID, createdBy);
                    }

                    UpdateServiceRequestStatus();
                    UpdateChapelReservationStatus();
                    UpdateServiceRequestPackageEquipmentStatus();

                    MessageBox.Show("Payment successfully!");
                    PaymentAdded.Invoke(this, EventArgs.Empty);
                }
                else
                {
                    MessageBox.Show("Error processing payment.");
                }
            }
            else
            {
                MessageBox.Show("Payment cancelled.");
            }
        }
        private string ValidatePaymentInputs()
        {
            // Check if payment option is selected
            if (cmb_PaymentOption.SelectedValue == null)
                return "Please select a payment option.";

            // Validate installment plan selection
            if (cmb_PaymentOption.SelectedValue.ToString() == "2" &&
                (cmb_InstallmentPlan.SelectedValue == null || cmb_InstallmentPlan.SelectedValue.ToString() == ""))
            {
                cmb_InstallmentPlan.SelectedValue = -1;
                return "Please select an installment plan.";
            }
                
            // Validate Amount Paid against Final Price
            decimal amountPaid;
            decimal finalPrice;
            if (!decimal.TryParse(txt_AmountPaid.Text, out amountPaid) || amountPaid < 0 )
            {
                return "Please enter a valid amount paid (numbers only).";
            }
            finalPrice = GetRealPrice(lbl_FinalPrice.Text);

            // If installment is selected, ensure amount paid is not greater than final price
            int paymentOptionId = (int)cmb_PaymentOption.SelectedValue;
            if (paymentOptionId != 2 && amountPaid < finalPrice)
            {
                return "For full payment, the amount paid must be equal to or greater than the final price.";
            }

            if (paymentOptionId == 2 && amountPaid > finalPrice)
            {
                cmb_InstallmentPlan.SelectedIndex = -1;
                dgv_Installment.Columns.Clear();
                return "Amount paid cannot exceed the final price for installment payments.";
            }

            // Validate Remaining Balance
            decimal remainingBalance ;
            if (!decimal.TryParse(lbl_RemainingBalance.Text.Replace("₱", "").Trim(), out remainingBalance) || remainingBalance < 0)
                return "Remaining balance cannot be negative.";

            return string.Empty; // All validations passed
        }
        private int SavePayment(string createdBy)
        {
            int paymentID = 0;
            int paymentStatusID = cmb_InstallmentPlan.Visible && cmb_InstallmentPlan.SelectedValue != null ? 2 : 3;

            decimal finalPrice = 0;
            decimal remainingBalance = 0;
            if (!decimal.TryParse(lbl_FinalPrice.Text.Replace("₱", "").Trim(), out finalPrice))
            {
                MessageBox.Show("Invalid final price.");
                return 0;
            }

            if (!decimal.TryParse(lbl_RemainingBalance.Text.Replace("₱", "").Trim(), out remainingBalance))
            {
                MessageBox.Show("Invalid remaining balance.");
                return 0;
            }

            string query = @"INSERT INTO Payments (PaymentOptionID, PaymentStatusID, DiscountID, InstallmentPlanID, 
                                          ClientName, Subtotal, DiscountApplied, DiscountAmount, FinalPrice, 
                                          PaymentOption, InstallmentPlan, AmountPaid, RemainingBalance, CreatedBy, PaymentDate)
                     OUTPUT INSERTED.PaymentID
                     VALUES (@PaymentOptionID, @PaymentStatusID, @DiscountID, @InstallmentPlanID,
                             @ClientName, @Subtotal, @DiscountApplied, @DiscountAmount, @FinalPrice,
                             @PaymentOption, @InstallmentPlan, @AmountPaid, @RemainingBalance, @CreatedBy, GETDATE())";

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                // Add parameters
                cmd.Parameters.AddWithValue("@PaymentOptionID", cmb_PaymentOption.SelectedValue);
                cmd.Parameters.AddWithValue("@PaymentStatusID", paymentStatusID);
                cmd.Parameters.AddWithValue("@DiscountID", cmb_Discount.SelectedValue ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@InstallmentPlanID", cmb_InstallmentPlan.SelectedValue ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@ClientName", lbl_ClientName.Text);
                cmd.Parameters.AddWithValue("@Subtotal", totalPrice);
                cmd.Parameters.AddWithValue("@DiscountApplied", lbl_DiscountApplied.Text);
                cmd.Parameters.AddWithValue("@DiscountAmount", lbl_FinalPrice.Text.Replace("₱", "").Trim());
                cmd.Parameters.AddWithValue("@FinalPrice", lbl_FinalPrice.Text.Replace("₱", "").Trim());
                cmd.Parameters.AddWithValue("@PaymentOption", cmb_PaymentOption.Text);
                cmd.Parameters.AddWithValue("@InstallmentPlan", cmb_InstallmentPlan.Text);
                cmd.Parameters.AddWithValue("@AmountPaid", txt_AmountPaid.Text);
                cmd.Parameters.AddWithValue("@RemainingBalance", lbl_RemainingBalance.Text.Replace("₱", "").Trim());
                cmd.Parameters.AddWithValue("@CreatedBy", createdBy);

                try
                {
                    db.Open();
                    paymentID = (int)cmd.ExecuteScalar(); // Retrieves the generated PaymentID
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving payment: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }
            return paymentID;
        }
        private void SavePaymentServiceRequests(int paymentID)
        {
            foreach (var row in selectedRows)
            {
                int serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);
                string query = @"INSERT INTO PaymentServiceRequests (PaymentID, ServiceRequestID)
                         VALUES (@PaymentID, @ServiceRequestID)";

                using (SqlCommand cmd = new SqlCommand(query, db))
                {
                    cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                    cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                    try
                    {
                        db.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving service request association: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
        private void SaveInstallments(int paymentID, int installmentPlanID, string createdBy)
        {
            // Load the installment schedule created in CalculateInstallmentSchedule
            foreach (DataGridViewRow row in dgv_Installment.Rows)
            {
                string query = @"INSERT INTO Installments (PaymentID, PaymentStatusID, InstallmentNumber, DueDate, Amount, AmountPaid, CreatedBy, PaymentDate)
                         VALUES (@PaymentID, @PaymentStatusID, @InstallmentNumber, @DueDate, @Amount, @AmountPaid, @CreatedBy, GETDATE())";

                using (SqlCommand cmd = new SqlCommand(query, db))
                {
                    cmd.Parameters.AddWithValue("@PaymentID", paymentID);
                    cmd.Parameters.AddWithValue("@PaymentStatusID", 1); // Assuming '1' for 'Pending' or unpaid
                    cmd.Parameters.AddWithValue("@InstallmentNumber", row.Cells["Installment Number"].Value);
                    cmd.Parameters.AddWithValue("@DueDate", row.Cells["Due Date"].Value);
                    cmd.Parameters.AddWithValue("@Amount", row.Cells["Amount Due"].Value);
                    cmd.Parameters.AddWithValue("@AmountPaid", 0); // Initially unpaid
                    cmd.Parameters.AddWithValue("@CreatedBy", createdBy); // Hardcoded for example

                    try
                    {
                        db.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error saving installment: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
        private void UpdateServiceRequestStatus()
        {
            int ongoingStatusID = 2;
            foreach (var row in selectedRows)
            {
                int serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);

                string query = "UPDATE ServiceRequests SET ServiceStatusID = @ServiceStatusID WHERE ServiceRequestID = @ServiceRequestID";

                using (SqlCommand cmd = new SqlCommand(query, db))
                {
                    cmd.Parameters.AddWithValue("@ServiceStatusID", ongoingStatusID);
                    cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                    try
                    {
                        db.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating service request status: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
        private void UpdateChapelReservationStatus()
        {
            int confirmedStatusID = 2; // ID for 'Confirmed' status

            foreach (var row in selectedRows)
            {
                int reservationID = Convert.ToInt32(row.Cells["ReservationID"].Value);

                string query = "UPDATE ChapelReservation SET ReservationStatusID = @ReservationStatusID WHERE ReservationID = @ReservationID";

                using (SqlCommand cmd = new SqlCommand(query, db))
                {
                    cmd.Parameters.AddWithValue("@ReservationStatusID", confirmedStatusID);
                    cmd.Parameters.AddWithValue("@ReservationID", reservationID);

                    try
                    {
                        db.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating chapel reservation status: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
        private void UpdateServiceRequestPackageEquipmentStatus()
        {
            int reservedStatusID = 2; // ID for 'Reserved' status in EquipmentStatus

            foreach (var row in selectedRows)
            {
                int serviceRequestPackageEquipmentID = Convert.ToInt32(row.Cells["ServiceRequestsPackageEquipmentID"].Value);

                string query = "UPDATE ServiceRequestsPackageEquipments SET EquipmentStatusID = @EquipmentStatusID WHERE ServiceRequestsPackageEquipmentID = @ServiceRequestsPackageEquipmentID";

                using (SqlCommand cmd = new SqlCommand(query, db))
                {
                    cmd.Parameters.AddWithValue("@EquipmentStatusID", reservedStatusID);
                    cmd.Parameters.AddWithValue("@ServiceRequestsPackageEquipmentID", serviceRequestPackageEquipmentID);

                    try
                    {
                        db.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error updating equipment status: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
    }
    public static class SharedState
    {
        public static List<DataGridViewRow> SelectedRows { get; set; }
    }
}
