﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class SalesReport : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public SalesReport()
        {
            InitializeComponent();
            db = y.GetConnection();
            customizeDesign();
            showSubMenu(panelReportsSubMenu);
            btn_Sales.BackColor = Color.LightSkyBlue; 
            DisplayPaymentHistory();
            UserAccessLevel();
        }
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
            panelTransactionSubMenu.Visible = false;
            panelInventorySubMenu.Visible = false;
            panelReportsSubMenu.Visible = false;
            panelSettingsSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            //user
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            //service
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
            //transaction
            if (panelTransactionSubMenu.Visible == true)
                panelTransactionSubMenu.Visible = false;
            //inventory
            if (panelInventorySubMenu.Visible == true)
                panelInventorySubMenu.Visible = false;
            //reports
            if (panelReportsSubMenu.Visible == true)
                panelReportsSubMenu.Visible = false;
            //setting
            if (panelSettingsSubMenu.Visible == true)
                panelSettingsSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        //Home Nav
        private void btn_Home_Click(object sender, EventArgs e)
        {
            Home form2 = new Home();
            form2.Show();
            this.Hide();
        }

        //UserSubMenu
        private void btn_User_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus
        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            UsersLog form1 = new UsersLog();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Permission_Click(object sender, EventArgs e)
        {
            Permission form1 = new Permission();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            ServiceRequest form3 = new ServiceRequest();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Package_Click(object sender, EventArgs e)
        {
            CreatePackage form2 = new CreatePackage();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }


        //TransactionSubMenu
        private void btn_Transaction_Click(object sender, EventArgs e)
        {
            showSubMenu(panelTransactionSubMenu);
        }
        //TheSubMenus
        private void btn_Payment_Click(object sender, EventArgs e)
        {
            Payment form3 = new Payment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_InstallmentPayment_Click_1(object sender, EventArgs e)
        {
            InstallmentPayment form3 = new InstallmentPayment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //InventorySubMenus
        private void btn_Inventory_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelInventorySubMenu);
        }
        private void btn_AddEquipment_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //ReportsSubMenus
        private void btn_Reports_Click(object sender, EventArgs e)
        {
            showSubMenu(panelReportsSubMenu);
        }
        private void btn_ServiceHistory_Click(object sender, EventArgs e)
        {
            ServiceHistory form3 = new ServiceHistory();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_EquipmentReleaseLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Inventory_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Sales_Click(object sender, EventArgs e)
        {
            SalesReport form3 = new SalesReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_EquipmentNarrative_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //SettingsSubMenus
        private void btn_Settings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSettingsSubMenu);
        }
        private void btn_EmployeeList_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_AccountDetails_Click(object sender, EventArgs e)
        {
            AccountDetails form3 = new AccountDetails();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ChangePassword_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }



        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks Yes log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LogUserLogout();
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
        private void LogUserLogout()
        {
            try
            {
                if (CurrentUser.LogID > 0)
                {
                    string logoutQuery = "UPDATE UserLog SET LogoutDateTime = GETDATE() WHERE LogID = @LogID";
                    SqlCommand logoutCommand = new SqlCommand(logoutQuery, db);
                    logoutCommand.Parameters.AddWithValue("@LogID", CurrentUser.LogID);

                    y.Open();
                    logoutCommand.ExecuteNonQuery();
                    y.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while logging out: " + ex.Message);
            }
        }
        private void UserAccessLevel()
        {
            int userID = CurrentUser.UserID;

            //what buttons admin can access
            if (CurrentUser.AccessLevel == "1")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = true;
                btn_AddUser.Visible = true;
                btn_UserLog.Visible = true;
                btn_Permission.Visible = true;
                //service
                btn_Service.Visible = true;
                btn_AddClient.Visible = true;
                btn_ServiceRequest.Visible = true;
                btn_Package.Visible = true;
                //transaction
                btn_Transaction.Visible = true;
                btn_Payment.Visible = true;
                btn_InstallmentPayment.Visible = true;
                //Inventory
                btn_Inventory.Visible = true;
                btn_AddEquipment.Visible = true;
                //report
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = true;
                btn_EquipmentReleaseLog.Visible = true;
                btn_InventoryMasterList.Visible = true;
                btn_Sales.Visible = true;
                btn_EquipmentNarrative.Visible = true;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = true;
                btn_AccountDetails.Visible = true;
                btn_ChangePassword.Visible = true;
            }
            //what buttons Service Staff can access
            else if (CurrentUser.AccessLevel == "2")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = false;
                btn_AddUser.Visible = false;
                btn_UserLog.Visible = false;
                btn_Permission.Visible = false;
                //service
                btn_Service.Visible = true;
                btn_AddClient.Visible = true;
                btn_ServiceRequest.Visible = true;
                btn_Package.Visible = true;
                //transaction
                btn_Transaction.Visible = true;
                btn_Payment.Visible = true;
                btn_InstallmentPayment.Visible = true;
                //Inventory
                btn_Inventory.Visible = false;
                btn_AddEquipment.Visible = false;
                //report
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = true;
                btn_EquipmentReleaseLog.Visible = false;
                btn_Inventory.Visible = false;
                btn_Sales.Visible = true;
                btn_EquipmentNarrative.Visible = false;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = false;
                btn_AccountDetails.Visible = true;
                btn_ChangePassword.Visible = true;
            }
            //what buttons Inventory Staff can access
            else if (CurrentUser.AccessLevel == "3")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = false;
                btn_AddUser.Visible = false;
                btn_UserLog.Visible = false;
                btn_Permission.Visible = false;
                //service 
                btn_Service.Visible = false;
                btn_AddClient.Visible = false;
                btn_ServiceRequest.Visible = false;
                btn_Package.Visible = false;
                //transaction
                btn_Transaction.Visible = false;
                btn_Payment.Visible = false;
                btn_InstallmentPayment.Visible = false;
                //Inventory
                btn_Inventory.Visible = true;
                btn_AddEquipment.Visible = true;
                //report module
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = false;
                btn_EquipmentReleaseLog.Visible = true;
                btn_Inventory.Visible = true;
                btn_Sales.Visible = false;
                btn_EquipmentNarrative.Visible = true;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = false;
                btn_AccountDetails.Visible = true;
                btn_ChangePassword.Visible = true;
            }
        }
        private void DisplayPaymentHistory()
        {
            string query = @"
        SELECT p.PaymentID, p.ClientName, p.Subtotal, p.DiscountApplied, p.DiscountAmount, 
               p.FinalPrice, p.PaymentOption, p.RemainingBalance, ps.PaymentStatusName AS PaymentStatus
        FROM Payments p
        LEFT JOIN Installments i ON p.PaymentID = i.PaymentID
        LEFT JOIN PaymentStatus ps ON p.PaymentStatusID = ps.PaymentStatusID
        WHERE p.PaymentStatusID = 3 
              AND (i.PaymentID IS NULL OR i.PaymentStatusID = 3)
        GROUP BY p.PaymentID, p.ClientName, p.Subtotal, p.DiscountApplied, 
                 p.DiscountAmount, p.FinalPrice, p.PaymentOption, 
                 p.RemainingBalance, ps.PaymentStatusName
        HAVING COUNT(i.InstallmentID) = COUNT(CASE WHEN i.PaymentStatusID = 3 THEN 1 END) 
               OR COUNT(i.InstallmentID) = 0";


            DataTable paymentHistoryData = new DataTable();

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                try
                {
                    db.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(paymentHistoryData);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving payment history: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }

            // Bind the data to a DataGridView control
            dgv_Sales.DataSource = paymentHistoryData;

            // Optionally, set column headers
            dgv_Sales.Columns["PaymentID"].HeaderText = "Payment ID";
            dgv_Sales.Columns["ClientName"].HeaderText = "Client Name";
            dgv_Sales.Columns["Subtotal"].HeaderText = "Sub Price";
            dgv_Sales.Columns["DiscountApplied"].HeaderText = "Discount Applied";
            dgv_Sales.Columns["DiscountAmount"].HeaderText = "Discount Amount";
            dgv_Sales.Columns["FinalPrice"].HeaderText = "Final Price";
            dgv_Sales.Columns["PaymentOption"].HeaderText = "Payment Option";
            dgv_Sales.Columns["RemainingBalance"].HeaderText = "Remaining Balance";
            dgv_Sales.Columns["PaymentStatus"].HeaderText = "Payment Status";
        }
    }
}
