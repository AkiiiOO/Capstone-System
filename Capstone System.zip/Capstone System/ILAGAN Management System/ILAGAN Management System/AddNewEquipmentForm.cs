﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler ClientAdded;

        public AddNewEquipmentForm()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (string.IsNullOrEmpty(txt_EquipmentName.Text) || string.IsNullOrEmpty(txt_EquipmentType.Text) || string.IsNullOrEmpty(txt_Quantity.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                string equipmentName = txt_EquipmentName.Text;
                string equipmentType = txt_EquipmentType.Text;
                int quantity = int.Parse(txt_Quantity.Text);

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO Equipment (EquipmentName, EquipmentType, Quantity) VALUES (@EquipmentName, @EquipmentType, @Quantity)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@EquipmentName", equipmentName);
                    command.Parameters.AddWithValue("@EquipmentType", equipmentType);
                    command.Parameters.AddWithValue("@Quantity", quantity);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Equipment added successfully.");
                        ClientAdded.Invoke(this, EventArgs.Empty);
                    }
                    else
                    {
                        MessageBox.Show("Error adding equipment.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
