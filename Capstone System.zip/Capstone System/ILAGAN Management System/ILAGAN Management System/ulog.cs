﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ILAGAN_Management_System
{
    class ulog
    {
        public static string type;
    }
}
