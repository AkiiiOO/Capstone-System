﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewClientForm : Form
    {
        SqlConnection db = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
        public event EventHandler ClientAdded;

        public AddNewClientForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //validations
            //first name textbox
            if (string.IsNullOrEmpty(txtFName.Text))
            {
                MessageBox.Show("First Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtFName.Focus();
                return;
            }
            //Middle Initial textbox
            if (!string.IsNullOrEmpty(txtMInitial.Text) && txtMInitial.Text.Length != 1)
            {
                MessageBox.Show("Middle Initial must be a single character or empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //Last Name textbox
            if (string.IsNullOrEmpty(txtLName.Text))
            {
                MessageBox.Show("Last Name cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtLName.Focus();
                return;
            }
            //email textbox
            if (string.IsNullOrEmpty(txtEmail.Text) || !IsValidEmail(txtEmail.Text))
            {
                MessageBox.Show("Please enter a valid email address.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
                return;
            }
            //address textbox
            if (string.IsNullOrEmpty(txtAddress.Text))
            {
                MessageBox.Show("Address cannot be empty.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtAddress.Focus();
                return;
            }
            //contact number textbox
            if (string.IsNullOrEmpty(txtContact_no.Text) || txtContact_no.Text.Length != 11 || !txtContact_no.Text.All(char.IsDigit))
            {
                MessageBox.Show("Contact Number must be exactly 11 digits.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtContact_no.Focus();
                return;
            }


            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            db.Open();
            string query = @"INSERT INTO Clients (UserID, FirstName, MiddleInitial, LastName, Email, Address, Contact_No, CreatedBy)
                             VALUES (@UserID, @FirstName, @MiddleInitial, @LastName, @Email, @Address, @Contact_No, @CreatedBy)";
            try
            {
                SqlCommand command = new SqlCommand(query, db);

                command.Parameters.AddWithValue("@UserID", currentUserId);
                command.Parameters.AddWithValue("@FirstName", txtFName.Text);
                command.Parameters.AddWithValue("@MiddleInitial", txtMInitial.Text);
                command.Parameters.AddWithValue("@LastName", txtLName.Text);
                command.Parameters.AddWithValue("@Email", txtEmail.Text);
                command.Parameters.AddWithValue("@Address", txtAddress.Text);
                command.Parameters.AddWithValue("@Contact_No", txtContact_no.Text);
                command.Parameters.AddWithValue("@CreatedBy", createdBy);

                
                command.ExecuteNonQuery();
                db.Close();

                ClearFormFields();
                ClientAdded.Invoke(this, EventArgs.Empty);
                MessageBox.Show("Client added successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while adding the client: " + ex.Message);
            }

        }
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return false;
            }

            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                // Check if the email address ends with @gmail.com
                return addr.Address.Equals(email, StringComparison.OrdinalIgnoreCase) && email.EndsWith("@gmail.com", StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }

        }

        private void ClearFormFields()
        {
            txtFName.Clear();
            txtMInitial.Clear();
            txtLName.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtContact_no.Clear();
        }
    }

}
