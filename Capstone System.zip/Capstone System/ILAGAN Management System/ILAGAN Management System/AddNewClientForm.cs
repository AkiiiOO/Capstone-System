﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddNewClientForm : Form
    {
        public event EventHandler ClientAdded;
        private string db = (@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");

        public AddNewClientForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection x = new SqlConnection(db);
            x.Open();


            int userID = CurrentUser.UserID;
            string fullname = GetUserFullName(userID);
            DateTime dateCreated = DateTime.Now;


            string query = "INSERT INTO Clients (UserID, FirstName, MiddleInitial, LastName, Email, Address, Contact_No, DateCreated, CreatedBy) " +
                                           "VALUES (@UserID, @FirstName, @MiddleInitial, @LastName, @Email, @Address, @ContactNo, @DateCreated, @CreatedBy)";

            SqlCommand com = new SqlCommand(query, x);

            com.Parameters.AddWithValue("@UserID", userID);
            com.Parameters.AddWithValue("@FirstName", txtFName.Text);
            com.Parameters.AddWithValue("@MiddleInitial", txtMInitial.Text);
            com.Parameters.AddWithValue("@LastName", txtLName.Text);
            com.Parameters.AddWithValue("@Email", txtEmail.Text);
            com.Parameters.AddWithValue("@Address", txtAddress.Text);
            com.Parameters.AddWithValue("@ContactNo", txtContact_no.Text);
            com.Parameters.AddWithValue("@DateCreated", dateCreated);
            com.Parameters.AddWithValue("@CreatedBy", fullname);

            com.ExecuteNonQuery();
            MessageBox.Show("Client added successfully.");

            txtFName.Clear();
            txtMInitial.Clear();
            txtLName.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            txtContact_no.Clear();

            ClientAdded.Invoke(this, EventArgs.Empty);
        }
        private string GetUserFullName(int userID)
        {
            string fullName = "";

            SqlConnection x = new SqlConnection(db);
            x.Open();

            string query = "SELECT FirstName, LastName FROM Users WHERE UserID = @UserID";
            SqlCommand command = new SqlCommand(query, x);

            command.Parameters.AddWithValue("@UserID", userID);

            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                string firstName = reader["FirstName"].ToString();
                string lastName = reader["LastName"].ToString();
                fullName = "{firstName} {lastName}".Trim();
            }
            reader.Close();
            x.Close();

            return fullName;
        }

    }

}
