﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ReturnEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        
        public event EventHandler ClientAdded;

        private List<DataGridViewRow> selectedRows;
        int serviceRequestID;

        public ReturnEquipmentForm(List<DataGridViewRow> selectedRows)
        {
            InitializeComponent();
            db = y.GetConnection();
            this.selectedRows = selectedRows;
            PopulateRelease();
            LoadEmployees();
        }
        private void PopulateRelease()
        {
            if (selectedRows.Count == 1)
            {
                var row = selectedRows[0];

                // Extract the Service Location value
                serviceRequestID = Convert.ToInt32(row.Cells["ServiceRequestID"].Value);

                // Populate the Service Location field
                LoadReleasedEquipment();

            }
            else
            {
                MessageBox.Show("Please select one service request.");
            }
        }
        private void LoadReleasedEquipment()
        {
            try
            {
                db.Open();

                // Query to fetch released equipment associated with the selected service request
                string query = @"
                SELECT 
                    er.EquipmentReleaseID,
                    e.EquipmentID,
                    e.EquipmentName, 
                    e.EquipmentType, 
                    er.Quantity,
                    er.ReleaseDate,
                    er.ReturnDate,
                    er.ReleasedBy,
                    er.ReturnedBy
                FROM EquipmentRelease er
                JOIN Equipment e ON er.EquipmentID = e.EquipmentID
                WHERE er.ServiceRequestID = @ServiceRequestID"; 

                SqlCommand cmd = new SqlCommand(query, db);
                cmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Rename columns for display
                dataTable.Columns["EquipmentName"].ColumnName = "Equipment Name";
                dataTable.Columns["EquipmentType"].ColumnName = "Type";
                dataTable.Columns["Quantity"].ColumnName = "Quantity";
                dataTable.Columns["ReleaseDate"].ColumnName = "Release Date";
                dataTable.Columns["ReturnDate"].ColumnName = "Return Date";
                dataTable.Columns["ReleasedBy"].ColumnName = "Released By";
                dataTable.Columns["ReturnedBy"].ColumnName = "Returned By";
                

                // Bind the equipment data to the DataGridView
                dgv_EquipmentsReturnDisplay.DataSource = dataTable;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentReleaseID"].Visible = false;
                dgv_EquipmentsReturnDisplay.Columns["EquipmentID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
        private void LoadEmployees()
        {
            try
            {
                // Open the database connection
                db.Open();

                // Query to select EmployeeID, FirstName, and LastName from Employees table
                string query = "SELECT EmployeeID, FirstName, LastName FROM Employees";

                SqlCommand cmd = new SqlCommand(query, db);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataTable.Columns.Add("FullName", typeof(string), "FirstName + ' ' + LastName");

                // Bind the data to the ComboBox
                cmb_Employees.DataSource = dataTable;
                cmb_Employees.DisplayMember = "FullName";
                cmb_Employees.ValueMember = "EmployeeID";

                cmb_Employees.SelectedIndex = -1;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading employees: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void btn_Return_Click(object sender, EventArgs e)
        {
           // Ensure an employee is selected from the ComboBox
            if (cmb_Employees.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an employee who is returning the equipment.");
                return;
            }

            try
            {
                // Get the employee name who is returning the equipment
                var selectedEmployee = (DataRowView)cmb_Employees.SelectedItem;
                string returnedBy = selectedEmployee["FullName"].ToString();

                // Open the database connection once before processing all rows
                db.Open();

                foreach (DataGridViewRow row in dgv_EquipmentsReturnDisplay.Rows)
                {
                    int equipmentReleaseID = Convert.ToInt32(row.Cells["EquipmentReleaseID"].Value);
                    int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                    string equipmentName = row.Cells["Equipment Name"].Value.ToString();
                    DateTime? returnDate = row.Cells["Return Date"].Value as DateTime?;

                    // Check if the equipment has already been returned
                    if (returnDate.HasValue)
                    {
                        continue; // Skip the equipment if it has already been returned
                    }

                    // Update the EquipmentRelease table
                    string updateQuery = @"
                    UPDATE EquipmentRelease
                    SET ReturnDate = GETDATE(),
                        ReturnedBy = @ReturnedBy,
                        EquipmentStatusID = 4 -- Assuming 4 is the 'Returned' status
                    WHERE EquipmentReleaseID = @EquipmentReleaseID";

                    SqlCommand updateCmd = new SqlCommand(updateQuery, db);
                    updateCmd.Parameters.AddWithValue("@ReturnedBy", returnedBy);
                    updateCmd.Parameters.AddWithValue("@EquipmentReleaseID", equipmentReleaseID);

                    int rowsAffected = updateCmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        // Update the Equipment table to reflect the returned quantity
                        string inventoryUpdateQuery = @"
                        UPDATE Equipment
                        SET Quantity = Quantity + @Quantity
                        WHERE EquipmentName = @EquipmentName";

                        SqlCommand inventoryUpdateCmd = new SqlCommand(inventoryUpdateQuery, db);
                        inventoryUpdateCmd.Parameters.AddWithValue("@Quantity", quantity);
                        inventoryUpdateCmd.Parameters.AddWithValue("@EquipmentName", equipmentName);

                        inventoryUpdateCmd.ExecuteNonQuery();

                        // Now, update the ServiceRequestsPackageEquipments table with the new status
                        string equipmentStatusUpdateQuery = @"
                        UPDATE ServiceRequestsPackageEquipments
                        SET EquipmentStatusID = 4 -- Assuming 4 is 'Returned'
                        WHERE ServiceRequestID = @ServiceRequestID
                          AND EquipmentID = @EquipmentID";

                        SqlCommand statusUpdateCmd = new SqlCommand(equipmentStatusUpdateQuery, db);
                        statusUpdateCmd.Parameters.AddWithValue("@ServiceRequestID", serviceRequestID); // Use the serviceRequestID from earlier
                        statusUpdateCmd.Parameters.AddWithValue("@EquipmentID", row.Cells["EquipmentID"].Value); // Assuming you have EquipmentID

                        statusUpdateCmd.ExecuteNonQuery();
                    }
                    else
                    {
                        MessageBox.Show("Error returning equipment. Please try again.");
                    }
                }

                MessageBox.Show("All equipment returned successfully.");
                ClientAdded.Invoke(this, EventArgs.Empty);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                db.Close();
                LoadReleasedEquipment();
                if (AllEquipmentReturned())
                {
                    this.Close();  // Close the form if all equipment have been returned
                }
            }
        }
        private bool AllEquipmentReturned()
        {
            foreach (DataGridViewRow row in dgv_EquipmentsReturnDisplay.Rows)
            {
                if (row.Cells["Return Date"].Value == DBNull.Value)
                {
                    // If any equipment doesn't have a return date, return false
                    return false;
                }
            }
            // If all rows have a return date, return true
            return true;
        }

    }
}
