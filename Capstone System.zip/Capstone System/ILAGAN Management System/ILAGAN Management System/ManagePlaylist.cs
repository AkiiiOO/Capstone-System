﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ManagePlaylist : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public ManagePlaylist()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadPlaylist();
            LoadPlaylistsSelect();
            LoadSongs();
        }

        private void LoadPlaylistsSelect()
        {
            cmb_PlaylistSelect.Items.Clear();

            string query = "SELECT PlaylistsID, PlaylistsName FROM Playlists";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable playlistsTable = new DataTable();
                adapter.Fill(playlistsTable);

                cmb_PlaylistSelect.DataSource = playlistsTable; 
                cmb_PlaylistSelect.DisplayMember = "PlaylistsName"; 
                cmb_PlaylistSelect.ValueMember = "PlaylistsID";

                cmb_PlaylistSelect.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading playlists: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void LoadSongs()
        {
            string query = "SELECT SongID, SongName, Artist FROM Song";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable songTable = new DataTable();
                adapter.Fill(songTable);

                dgv_SelectSongs.DataSource = songTable;
                dgv_SelectSongs.Columns["SongID"].Visible = false;

                // Customize column headers
                dgv_SelectSongs.Columns["SongName"].HeaderText = "Song";
                dgv_SelectSongs.Columns["SongName"].ReadOnly = true;
                dgv_SelectSongs.Columns["Artist"].HeaderText = "Artist";
                dgv_SelectSongs.Columns["Artist"].ReadOnly = true;
                dgv_SelectSongs.Columns["SelectColumn"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void LoadPlaylist()
        {
            string query = "SELECT PlaylistsName FROM Playlists";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable songTable = new DataTable();
                adapter.Fill(songTable);

                dgv_Playlist.DataSource = songTable;

                // Customize column headers
                dgv_Playlist.Columns["PlaylistsName"].HeaderText = "Playlist";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void btn_NewPlaylist_Click(object sender, EventArgs e)
        {
            string playlistName = txt_PlaylistName.Text.Trim();

            if (string.IsNullOrEmpty(txt_PlaylistName.Text))
            {
                MessageBox.Show("Playlist Name are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (PlaylistExists(playlistName))
            {
                MessageBox.Show( playlistName + " already exists.", "Duplicate Song", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            string query = "INSERT INTO Playlists (UserID, PlaylistsName, CreatedBy) VALUES (@UserID, @PlaylistsName, @CreatedBy)";

            try
            {
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@UserID", currentUserId); 
                    command.Parameters.AddWithValue("@PlaylistsName", txt_PlaylistName.Text);
                    command.Parameters.AddWithValue("@CreatedBy", createdBy); 

                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Playlist added successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
                LoadPlaylist();
            }
            txt_PlaylistName.Clear();
            db.Close();
        }

        private bool PlaylistExists(string playlistName)
        {
            string query = "SELECT COUNT(*) FROM Playlists WHERE PlaylistsName = @PlaylistsName";
            int count = 0;

            try
            {
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@PlaylistsName", playlistName);
                db.Open();
                count = (int)command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error checking playlist: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
            return count > 0;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadPlaylist();
                return;
            }
            string query = @"SELECT PlaylistsID, PlaylistsName  FROM Playlists 
                             WHERE PlaylistsName LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_Playlist.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_Playlist.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void btn_AddPlaylist_Click(object sender, EventArgs e)
        {
            if (cmb_PlaylistSelect.SelectedValue == null)
            {
                MessageBox.Show("Please select a playlist.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int playlistId = (int)cmb_PlaylistSelect.SelectedValue; // Selected Playlist ID

            try
            {
                db.Open();
                using (SqlTransaction transaction = db.BeginTransaction())
                {
                    foreach (DataGridViewRow row in dgv_SelectSongs.Rows)
                    {
                        DataGridViewCheckBoxCell chk = row.Cells["SelectColumn"] as DataGridViewCheckBoxCell;

                        if (chk != null && chk.Value != null && (bool)chk.Value == true)
                        {
                            int songId = (int)row.Cells["SongID"].Value;
                            string query = "INSERT INTO PlaylistSongs (SongID, PlaylistsID) VALUES (@SongID, @PlaylistsID)";

                            using (SqlCommand command = new SqlCommand(query, db, transaction))
                            {
                                command.Parameters.AddWithValue("@SongID", songId);
                                command.Parameters.AddWithValue("@PlaylistsID", playlistId);

                                command.ExecuteNonQuery();
                            }
                        }
                    }
                    transaction.Commit();
                }
                MessageBox.Show("Selected songs added to playlist successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding songs to playlist: " + ex.Message);
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }

        }
    }
}
