﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class EditUserForm : Form
    {
        SqlConnection y = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
        public event EventHandler UserUpdated, UserDelete;

        public EditUserForm()
        {
            InitializeComponent();
        }

        private void EditUserForm_Load(object sender, EventArgs e)
        {
            cmb_UserAccessLevel.Items.Add("Admin");
            cmb_UserAccessLevel.Items.Add("Service");
            cmb_UserAccessLevel.Items.Add("Inventory");
            cmb_UserAccessLevel.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_UserAccessLevel.FormattingEnabled = true;
        }

        private void txtUsername_Leave(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtUsername.Text))
            {
                try
                {
                    y.Open();
                    string queryFetch = @"SELECT Password, FirstName, LastName, Email, PhoneNumber, AccessLevel FROM tbl_Users WHERE Username = @Username";
                    SqlCommand command = new SqlCommand(queryFetch, y);
                    command.Parameters.AddWithValue("@Username", txtUsername.Text);

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        txtPassword.Text = reader["Password"].ToString();
                        txtFName.Text = reader["FirstName"].ToString();
                        txtLastName.Text = reader["LastName"].ToString();
                        txtEmail.Text = reader["Email"].ToString();
                        txtPhoneNumber.Text = reader["PhoneNumber"].ToString();
                        cmb_UserAccessLevel.Text = reader["AccessLevel"].ToString();
                    }
                    else
                    {
                        MessageBox.Show("User not found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearUserFields();
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while fetching user details: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    y.Close();
                }
            }
        }

        private void ClearUserFields()
        {
            txtPassword.Clear();
            txtFName.Clear();
            txtLastName.Clear();
            txtEmail.Clear();
            txtPhoneNumber.Clear();
            cmb_UserAccessLevel.SelectedIndex = -1;
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) ||
                string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLastName.Text) ||
                string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtPhoneNumber.Text) || 
                string.IsNullOrEmpty(cmb_UserAccessLevel.Text))
            {
                MessageBox.Show("Textbox must be filled.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            y.Open();
            string queryUpdate = @"UPDATE tbl_Users SET Password = @Password, FirstName = @FirstName, LastName = @LastName, Email = @Email, PhoneNumber = @PhoneNumber, AccessLevel = @AccessLevel WHERE Username = @Username";
            SqlCommand command = new SqlCommand(queryUpdate, y);
            command.Parameters.AddWithValue("@Username", txtUsername.Text);
            command.Parameters.AddWithValue("@Password", txtPassword.Text);
            command.Parameters.AddWithValue("@FirstName", txtFName.Text);
            command.Parameters.AddWithValue("@LastName", txtLastName.Text);
            command.Parameters.AddWithValue("@Email", txtEmail.Text);
            command.Parameters.AddWithValue("@PhoneNum﻿ber", long.Parse(txtPhoneNumber.Text));
            command.Parameters.AddWithValue("@AccessLevel", cmb_UserAccessLevel.Text);

            int result = command.ExecuteNonQuery();
            if (result > 0)
            {
                MessageBox.Show("User details updated successfully.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                UserUpdated.Invoke(this, EventArgs.Empty);
            }
            else
            {
                MessageBox.Show("Update failed. User not found.", "Update Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
 

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) ||
                string.IsNullOrEmpty(txtFName.Text) || string.IsNullOrEmpty(txtLastName.Text) ||
                string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtPhoneNumber.Text) ||
                string.IsNullOrEmpty(cmb_UserAccessLevel.Text))
            {
                MessageBox.Show("Textbox must be filled up to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult deleteresult = MessageBox.Show("Are you sure you want to delete this user?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (deleteresult == DialogResult.Yes)
            {
                try
                {
                y.Open();
                string queryDelete = @"DELETE FROM tbl_Users WHERE Username = @Username";
                SqlCommand command = new SqlCommand(queryDelete, y);
                command.Parameters.AddWithValue("@Username", txtUsername.Text);

                int result = command.ExecuteNonQuery();
                    if (result > 0)
                    {
                        MessageBox.Show("User deleted successfully.", "Delete Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearUserFields();
                        txtUsername.Clear();
                        UserDelete.Invoke(this, EventArgs.Empty);
                    }
                    else
                    {
                        MessageBox.Show("Delete failed! User isnot found.", "Delete Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while deleting the user: " + ex.Message, "Error!!!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
