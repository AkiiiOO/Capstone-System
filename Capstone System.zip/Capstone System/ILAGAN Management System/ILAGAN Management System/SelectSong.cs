﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class SelectSong : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public int SelectedSongID { get; set; }
        public string SelectedSongName { get; set; }
        public string SelectedArtistName { get; set; }
        public string SelectedGenre { get; set; }

        public SelectSong()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadSongRecords();
        }

        private void LoadSongRecords()
        {
            db.Open();
            string query = @"SELECT SongID, SongName, Artist, Genre FROM Song";

            SqlCommand command = new SqlCommand(query, db);
            SqlDataAdapter dt = new SqlDataAdapter(command);
            DataTable songsTable = new DataTable();
            dt.Fill(songsTable);
            dgv_SongRecords.DataSource = songsTable;
            db.Close();
        }

        private void dgv_SongRecords_Click(object sender, EventArgs e)
        {
            if (dgv_SongRecords.SelectedRows.Count > 0)
            {
                // Get the selected song's data
                DataRowView selectedRow = (DataRowView)dgv_SongRecords.SelectedRows[0].DataBoundItem;

                SelectedSongID = (int)selectedRow["SongID"];

                SelectedSongName = selectedRow["SongName"].ToString();
                SelectedArtistName = selectedRow["Artist"].ToString();
                SelectedGenre = selectedRow["Genre"].ToString();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(SelectedSongName))
            {
                this.DialogResult = DialogResult.OK;
                this.Close(); // Close the form
            }
            else
            {
                MessageBox.Show("Please select a song.");
            }
        }
    }
}
