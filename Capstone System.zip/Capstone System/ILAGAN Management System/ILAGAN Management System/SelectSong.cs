﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class SelectSong : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public int SelectedPlaylistId { get; private set; }
        public string SelectedPlaylistName { get; private set; }

        public SelectSong()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadPlaylistsSelect();
        }
        private void cmb_Playlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Playlist.SelectedValue != null)
            {
                int selectedPlaylistId = (int)cmb_Playlist.SelectedValue;
                LoadSongsInPlaylist(selectedPlaylistId);  
            }
        }

        private void LoadSongsInPlaylist(int playlistId)
        {
            string query = @"SELECT s.SongID, s.SongName, s.Artist
                             FROM PlaylistSongs ps
                             JOIN Song s ON ps.SongID = s.SongID
                             WHERE ps.PlaylistsID = @PlaylistID";

            DataTable songsTable = new DataTable();

            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@PlaylistID", playlistId);

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(songsTable);

                dgv_Playlist.DataSource = songsTable;
                dgv_Playlist.Columns["SongID"].Visible = false; 
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading songs: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void LoadPlaylistsSelect()
        {
            cmb_Playlist.Items.Clear();

            string query = "SELECT PlaylistsID, PlaylistsName FROM Playlists";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable playlistsTable = new DataTable();
                adapter.Fill(playlistsTable);

                cmb_Playlist.DataSource = playlistsTable;
                cmb_Playlist.DisplayMember = "PlaylistsName";
                cmb_Playlist.ValueMember = "PlaylistsID";

                cmb_Playlist.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading playlists: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void btn_Addsong_Click(object sender, EventArgs e)
        {
            ManageSongs managesong = new ManageSongs();
            managesong.ShowDialog();
        }

        private void btn_CreatePlaylist_Click(object sender, EventArgs e)
        {
            ManagePlaylist manageplay = new ManagePlaylist();
            manageplay.ShowDialog();
        }

        private void btn_Select_Click(object sender, EventArgs e)
        {
            if (cmb_Playlist.SelectedValue != null)
            {
                SelectedPlaylistId = (int)cmb_Playlist.SelectedValue;
                SelectedPlaylistName = cmb_Playlist.Text;

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Please select a playlist.");
            }
        }
    }
}
