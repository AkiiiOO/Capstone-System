﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddUser : Form
    {
        private string username;

        public AddUser(string username)
        {
            InitializeComponent();
            this.username = username;
            lbl_User.Text = username;
            LoadUserRecords();
            customizeDesign();
        }
        //submenu hide
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }
        private void btn_Home_Click(object sender, EventArgs e)
        {
            Home form2 = new Home(username);
            form2.Show();
            this.Hide();
        }
        //UserSubMenu
        private void btn_User_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus
        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser(username);
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_ServiceRequest_Click_1(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        private void btn_AddClient_Click_1(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            AddNewUserForm addUserForm = new AddNewUserForm();
            addUserForm.UserAdded += AddUserForm_UserAdded;
            addUserForm.ShowDialog();
        }

        private void AddUserForm_UserAdded(object sender, EventArgs e)
        {
            LoadUserRecords();
        }


        private void AddUser_Load(object sender, EventArgs e)
        {
            LoadUserRecords();
        }

        private void btn_ManageUserStatus_Click(object sender, EventArgs e)
        {
            ManageUserStatus ManageUserStatusForm = new ManageUserStatus();
            ManageUserStatusForm.UpdateStatus += AddUserForm_UserAdded;
            ManageUserStatusForm.ShowDialog();
        }

        private void btn_EditUser_Click(object sender, EventArgs e)
        {
            EditUserForm editUserForm = new EditUserForm();
            editUserForm.UserUpdated += AddUserForm_UserAdded;
            editUserForm.UserDelete += AddUserForm_UserAdded;
            editUserForm.ShowDialog();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks 'Yes', log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }

        private void LoadUserRecords()
        {
            SqlConnection x = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
            x.Open();
            // Display UsersTable
            SqlCommand command = new SqlCommand("SELECT UserID, Username, Password, FirstName, LastName, Email, PhoneNum﻿ber, AccessLevel, Status FROM tbl_Users", x);
            SqlDataAdapter dt = new SqlDataAdapter(command);
            DataTable UsersTable = new DataTable();
            dt.Fill(UsersTable);
            dgv_UsersRecords.DataSource = UsersTable;
            x.Close();
        }
    }
}
