﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CustomizePackage : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        private decimal casketPrice = 0.0M;
        private decimal vehiclePrice = 0.0M;

        public CustomizePackage()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                UpdatePackagePrice();
            }
        }

        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                UpdatePackagePrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                casketPrice = selectFlowerForm.SelectedFlowerPrice;
                UpdatePackagePrice();
            }
        }
        private void UpdatePackagePrice()
        {
            decimal totalPrice = casketPrice + vehiclePrice;
            txt_PackagePrice.Text = totalPrice.ToString("F2");
        }

    }
}
