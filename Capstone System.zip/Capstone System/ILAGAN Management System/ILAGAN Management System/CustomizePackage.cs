﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CustomizePackage : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        //For package name and id
        private int selectedPackageId;
        //For songs
        private int selectedPlaylistId;
        private string selectedPlaylistName; 
        //casket
        public int SelectedCasketID { get; set; }
        private decimal casketPrice = 0.0M;
        //Vehicle
        public int SelectedVehicleID { get; set; }
        private decimal vehiclePrice = 0.0M;
        //Flower Arrangment
        public int SelectedFlowerID { get; set; }
        private decimal flowerPrice = 0.0M;

        // Embalming Prices
        private decimal baseEmbalmingPrice = 0.0M;
        private decimal additionalDayCharge = 0.0M;
        private int includedDays = 0;

        public int CustomizePackageID { get; private set; }

        public CustomizePackage(int customizepackageID)
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadPackage();
            LoadEmbalmingPrices();
            if (customizepackageID != 0)
            {
                MessageBox.Show("Loading customize package details for ID: " + customizepackageID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.CustomizePackageID = customizepackageID;
                LoadCustomizePackageDetails(this.CustomizePackageID);
            }
        }
        private void LoadCustomizePackageDetails(int customizePackageID)
        {
            // Clear previous details
            dgv_PackageDetails.Rows.Clear();
            dgv_PackageDetails.Columns.Clear();
            string query = @"SELECT cp.PackageID, cp.PackageName, cp.CasketName, c.Price AS CasketPrice, 
                            cp.VehicleName, v.Price AS VehiclePrice, 
                            cp.FlowerArrangementName, fa.Price AS FlowerPrice, 
                            cp.PlaylistsName, cp.EmbalmingDays, cp.TotalPrice,
                            cp.CasketID, cp.VehicleID, cp.ArrangementID, cp.PlaylistSongsID
                     FROM CustomizePackage cp
                     LEFT JOIN Casket c ON cp.CasketID = c.CasketID
                     LEFT JOIN Vehicle v ON cp.VehicleID = v.VehicleID
                     LEFT JOIN FlowerArrangements fa ON cp.ArrangementID = fa.ArrangementID
                     WHERE cp.CustomizePackageID = @CustomizePackageID";

            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@CustomizePackageID", customizePackageID);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    //Others
                    selectedPackageId = reader["PackageID"] != DBNull.Value ? Convert.ToInt32(reader["PackageID"]) : -1;
                    cmb_Package.SelectedValue = selectedPackageId;

                    txt_Casket.Text = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                    txt_Vehicle.Text = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                    txt_Flower.Text = reader["FlowerArrangementName"] != DBNull.Value ? reader["FlowerArrangementName"].ToString() : "N/A";
                    txt_Song.Text = reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A";
                    txt_EmbalmingDays.Text = reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A";

                    // Populate TotalPrice in TextBox
                    decimal totalPrice = reader["TotalPrice"] != DBNull.Value ? Convert.ToDecimal(reader["TotalPrice"]) : 0;
                    txt_PackagePrice.Text = totalPrice.ToString("F2");

                    // Set up DataGridView with 2 columns for vertical display
                    dgv_PackageDetails.ColumnCount = 2;
                    dgv_PackageDetails.Columns[0].Name = "Name";
                    dgv_PackageDetails.Columns[1].Name = "Value";

                    // Add package details to DataGridView, with null-safe checks
                    dgv_PackageDetails.Rows.Add("Package", reader["PackageName"] != DBNull.Value ? reader["PackageName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Casket", reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Vehicle", reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Flower Arrangement", reader["FlowerArrangementName"] != DBNull.Value ? reader["FlowerArrangementName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Playlist", reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Embalming Days", reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Total Price", totalPrice.ToString("F2"));

                    // Assign selected IDs
                    SelectedCasketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                    SelectedVehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                    SelectedFlowerID = reader["ArrangementID"] != DBNull.Value ? Convert.ToInt32(reader["ArrangementID"]) : 0;
                    selectedPlaylistId = reader["PlaylistSongsID"] != DBNull.Value ? Convert.ToInt32(reader["PlaylistSongsID"]) : 0;

                    // Extract and display individual prices
                    casketPrice = reader["CasketPrice"] != DBNull.Value ? Convert.ToDecimal(reader["CasketPrice"]) : 0;
                    vehiclePrice = reader["VehiclePrice"] != DBNull.Value ? Convert.ToDecimal(reader["VehiclePrice"]) : 0;
                    flowerPrice = reader["FlowerPrice"] != DBNull.Value ? Convert.ToDecimal(reader["FlowerPrice"]) : 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading customize package details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadEmbalmingPrices()
        {
            string query = "SELECT IncludedDays, BasePrice, AdditionalDayCharge FROM EmbalmingPrice";

            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    includedDays = reader.GetInt32(0);
                    baseEmbalmingPrice = reader.GetDecimal(1);
                    additionalDayCharge = reader.GetDecimal(2);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading embalming prices: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadPackage()
        {
            cmb_Package.Items.Clear();
            string query = "SELECT PackageID, PackageName FROM Package";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable packageTable = new DataTable();
                adapter.Fill(packageTable);

                cmb_Package.DataSource = packageTable;
                cmb_Package.DisplayMember = "PackageName";
                cmb_Package.ValueMember = "PackageID";

                cmb_Package.SelectedIndex = -1; // Clear the selection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading packages: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void cmb_Package_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CustomizePackageID == 0)
            {
                if (cmb_Package.SelectedValue != null && cmb_Package.SelectedValue is int)
                {
                    selectedPackageId = (int)cmb_Package.SelectedValue;
                    LoadPackageDetails(selectedPackageId);
                }
                else
                {
                    ClearCustomSelections();
                    UpdateEmbalmingPrice();
                }
            }
        }
        private void ClearCustomSelections()
        {
            txt_Casket.Text = txt_Vehicle.Text = txt_Flower.Text = txt_Song.Text = txt_EmbalmingDays.Text = "";
            casketPrice = vehiclePrice = flowerPrice = 0.0M;
            baseEmbalmingPrice = additionalDayCharge = 0.0M;
            includedDays = 0;
            txt_PackagePrice.Text = "0.00";
        }

        private void LoadPackageDetails(int packageId)
        {
            // Clear previous details
            dgv_PackageDetails.Rows.Clear();
            dgv_PackageDetails.Columns.Clear();

            string query = @"SELECT p.PackageName, c.CasketID, c.CasketName, c.Price AS CasketPrice, v.VehicleID, v.VehicleName, v.Price AS VehiclePrice, 
                                    fa.ArrangementID, fa.ArrangementName AS FlowerArrangementName, fa.Price AS FlowerPrice, 
                                    pl.PlaylistsID, pl.PlaylistsName, p.EmbalmingDays,p.TotalPrice 
                             FROM Package p
                             LEFT JOIN Casket c ON p.CasketID = c.CasketID
                             LEFT JOIN Vehicle v ON p.VehicleID = v.VehicleID
                             LEFT JOIN FlowerArrangements fa ON p.ArrangementID = fa.ArrangementID
                             LEFT JOIN Playlists pl ON p.PlaylistsID = pl.PlaylistsID
                             WHERE p.PackageID = @PackageID";
            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@PackageID", packageId);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    //Others
                    txt_Casket.Text = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                    txt_Vehicle.Text = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                    txt_Flower.Text = reader["FlowerArrangementName"] != DBNull.Value ? reader["FlowerArrangementName"].ToString() : "N/A";
                    txt_Song.Text = reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A";
                    txt_EmbalmingDays.Text = reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A";

                    // Populate TotalPrice in TextBox
                    decimal totalPrice = reader["TotalPrice"] != DBNull.Value ? Convert.ToDecimal(reader["TotalPrice"]) : 0;
                    txt_PackagePrice.Text = totalPrice.ToString("F2");

                    // Set up DataGridView with 2 columns for vertical display
                    dgv_PackageDetails.ColumnCount = 2;
                    dgv_PackageDetails.Columns[0].Name = "Name";
                    dgv_PackageDetails.Columns[1].Name = "Value";

                    // Add package details to DataGridView, with null-safe checks
                    dgv_PackageDetails.Rows.Add("Package", reader["PackageName"] != DBNull.Value ? reader["PackageName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Casket", reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Vehicle", reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Flower Arrangement", reader["FlowerArrangementName"] != DBNull.Value ? reader["FlowerArrangementName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Playlist", reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Embalming Days", reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A");
                    dgv_PackageDetails.Rows.Add("Total Price", totalPrice.ToString("F2"));

                    // Assign selected IDs
                    SelectedCasketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                    SelectedVehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                    SelectedFlowerID = reader["ArrangementID"] != DBNull.Value ? Convert.ToInt32(reader["ArrangementID"]) : 0;
                    selectedPlaylistId = reader["PlaylistsID"] != DBNull.Value ? Convert.ToInt32(reader["PlaylistsID"]) : 0;

                    // Extract and display individual prices
                     casketPrice = reader["CasketPrice"] != DBNull.Value ? Convert.ToDecimal(reader["CasketPrice"]) : 0;
                     vehiclePrice = reader["VehiclePrice"] != DBNull.Value ? Convert.ToDecimal(reader["VehiclePrice"]) : 0;
                     flowerPrice = reader["FlowerPrice"] != DBNull.Value ? Convert.ToDecimal(reader["FlowerPrice"]) : 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading package details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                SelectedCasketID = selectCasketForm.SelectedCasketID;

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                SelectedVehicleID = selectVehicleForm.SelectedVehicleID;

                UpdateEmbalmingPrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                casketPrice = selectFlowerForm.SelectedFlowerPrice;
                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectFLower_Click_1(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                flowerPrice = selectFlowerForm.SelectedFlowerPrice;
                UpdateEmbalmingPrice();
            }
        }
        //done
        private void btn_Song_Click(object sender, EventArgs e)
        {
            SelectSong selectPlaylistForm = new SelectSong();
            if (selectPlaylistForm.ShowDialog() == DialogResult.OK)
            {
                txt_Song.Text = selectPlaylistForm.SelectedPlaylistName;
                selectedPlaylistId = selectPlaylistForm.SelectedPlaylistId;
                selectedPlaylistName = selectPlaylistForm.SelectedPlaylistName;
            }
        }
        private void btn_ClearCasket_Click(object sender, EventArgs e)
        {
            // Clear the casket text field
            txt_Casket.Text = string.Empty;

            // Reset the selected casket ID and price
            SelectedCasketID = 0;
            casketPrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearVehicle_Click(object sender, EventArgs e)
        {
            // Clear the vehicle text field
            txt_Vehicle.Text = string.Empty;

            // Reset the selected vehicle ID and price
            SelectedVehicleID = 0;
            vehiclePrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearArrangement_Click(object sender, EventArgs e)
        {
            // Clear the vehicle text field
            txt_Flower.Text = string.Empty;

            // Reset the selected flower ID and price
            SelectedFlowerID = 0;
            flowerPrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearPlaylist_Click(object sender, EventArgs e)
        {
            // Clear the Playlist text field
            txt_Song.Text = string.Empty;

            // Reset the selected Playlist ID
            selectedPlaylistId = 0;
        }
        private void txt_EmbalmingDays_TextChanged(object sender, EventArgs e)
        {
            UpdateEmbalmingPrice();
        }
        private void UpdateEmbalmingPrice()
        {
            if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
            {
                // If the input is empty, set the embalming price to the base price
                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice).ToString("F2");
                return; // Exit the method early
            }
            int embalmingDays = 0;
            if (int.TryParse(txt_EmbalmingDays.Text, out embalmingDays))
            {
                decimal embalmingPrice = 0;
                if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
                {
                    // Input is empty, so use the base embalming price
                    embalmingPrice = baseEmbalmingPrice;
                }
                if (embalmingDays > 0)
                {
                    // Start with the base embalming price
                    embalmingPrice = baseEmbalmingPrice;

                    if (embalmingDays > includedDays)
                    {
                        // Calculate additional charges if days exceed the included days
                        int additionalDays = embalmingDays - includedDays;
                        embalmingPrice += additionalDays * additionalDayCharge;
                    }
                }

                // Calculate the total price with or without embalming
                decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + embalmingPrice;

                // Update the total price in the text box
                txt_PackagePrice.Text = totalPrice.ToString("F2");
            }
            else
            {
                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice + baseEmbalmingPrice).ToString("F2");
            }
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmb_Package.SelectedValue == null)
                {
                    MessageBox.Show("Please select a valid package before saving.", "Invalid Package", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Exit the method early
                }
                if (CustomizePackageID == 0) 
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to save this package customization?",
                                                         "Confirm Save",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.Yes)
                    {
                        SavePackage();
                        MessageBox.Show("Customization saved successfully!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
                else
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to update this package customization?",
                                                         "Confirm Update",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.Yes)
                    {
                        UpdatePackage(); 
                        MessageBox.Show("Customization updated successfully!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving: " + ex.Message);
            }
        }
        private void SavePackage()
        {
            // Calculate total price based on custom selections
            decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);
            string packageName = cmb_Package.Text; 

            string query = @"INSERT INTO CustomizePackage (PackageID, CasketID, VehicleID, ArrangementID, PlaylistSongsID, PackageName,
                             CasketName, VehicleName, FlowerArrangementName, PlaylistsName, EmbalmingDays, TotalPrice, CreatedDate)
                             VALUES (@PackageID, @CasketID, @VehicleID, @ArrangementID, @PlaylistSongsID, @PackageName, @CasketName, @VehicleName, 
                             @FlowerArrangementName, @PlaylistsName, @EmbalmingDays, @TotalPrice, GETDATE());
                             SELECT SCOPE_IDENTITY();";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@PackageID", selectedPackageId > 0 ? (object)selectedPackageId : DBNull.Value);
                command.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                command.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                command.Parameters.AddWithValue("@ArrangementID", SelectedFlowerID > 0 ? (object)SelectedFlowerID : DBNull.Value);
                command.Parameters.AddWithValue("@PlaylistSongsID", selectedPlaylistId > 0 ? (object)selectedPlaylistId : DBNull.Value);
                command.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                command.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(txt_Casket.Text) ? DBNull.Value : (object)txt_Casket.Text);
                command.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(txt_Vehicle.Text) ? DBNull.Value : (object)txt_Vehicle.Text);
                command.Parameters.AddWithValue("@FlowerArrangementName", string.IsNullOrEmpty(txt_Flower.Text) ? DBNull.Value : (object)txt_Flower.Text);
                command.Parameters.AddWithValue("@PlaylistsName", string.IsNullOrEmpty(txt_Song.Text) ? DBNull.Value : (object)txt_Song.Text);
                command.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? DBNull.Value : (object)txt_EmbalmingDays.Text);
                command.Parameters.AddWithValue("@TotalPrice", totalPrice);

                try
                {
                    db.Open();
                    CustomizePackageID = Convert.ToInt32(command.ExecuteScalar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving package: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        private void UpdatePackage()
        {
            // Calculate total price based on custom selections
            decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);
            string packageName = cmb_Package.Text;

            string query = @"UPDATE CustomizePackage 
                     SET PackageID = @PackageID,
                         CasketID = @CasketID,
                         VehicleID = @VehicleID,
                         ArrangementID = @ArrangementID,
                         PlaylistSongsID = @PlaylistSongsID,
                         PackageName = @PackageName,
                         CasketName = @CasketName,
                         VehicleName = @VehicleName,
                         FlowerArrangementName = @FlowerArrangementName,
                         PlaylistsName = @PlaylistsName,
                         EmbalmingDays = @EmbalmingDays,
                         TotalPrice = @TotalPrice
                     WHERE CustomizePackageID = @CustomizePackageID";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                command.Parameters.AddWithValue("@PackageID", selectedPackageId > 0 ? (object)selectedPackageId : DBNull.Value);
                command.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                command.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                command.Parameters.AddWithValue("@ArrangementID", SelectedFlowerID > 0 ? (object)SelectedFlowerID : DBNull.Value);
                command.Parameters.AddWithValue("@PlaylistSongsID", selectedPlaylistId > 0 ? (object)selectedPlaylistId : DBNull.Value);
                command.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                command.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(txt_Casket.Text) ? DBNull.Value : (object)txt_Casket.Text);
                command.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(txt_Vehicle.Text) ? DBNull.Value : (object)txt_Vehicle.Text);
                command.Parameters.AddWithValue("@FlowerArrangementName", string.IsNullOrEmpty(txt_Flower.Text) ? DBNull.Value : (object)txt_Flower.Text);
                command.Parameters.AddWithValue("@PlaylistsName", string.IsNullOrEmpty(txt_Song.Text) ? DBNull.Value : (object)txt_Song.Text);
                command.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? DBNull.Value : (object)txt_EmbalmingDays.Text);
                command.Parameters.AddWithValue("@TotalPrice", totalPrice);

                try
                {
                    db.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating package: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
    }
}
