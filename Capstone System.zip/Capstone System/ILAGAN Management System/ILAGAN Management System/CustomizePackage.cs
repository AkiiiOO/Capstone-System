﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CustomizePackage : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        private decimal casketPrice = 0.0M;
        private decimal vehiclePrice = 0.0M;
        private decimal flowerPrice = 0.0M;
        private decimal chapelPrice = 0.0M;

        public string SelectedPackageName { get; set; }

        public CustomizePackage()
        {
            InitializeComponent();
            db = y.GetConnection();
        }

        private void CustomizePackage_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(SelectedPackageName))
            {
                LoadPackageDetails(SelectedPackageName);
            }
        }

        private void LoadPackageDetails(string packageName)
        {
            try
            {
                string query = @"
        SELECT p.CasketName, p.VehicleName, p.FlowerArrangementName, p.TotalPrice,
               c.Price AS CasketPrice, v.Price AS VehiclePrice, f.Price AS FlowerPrice,
               sl.LightDescription, p.ChapelName, p.EmbalmingDays, s.SongName
        FROM Package p
        LEFT JOIN Casket c ON p.CasketID = c.CasketID
        LEFT JOIN Vehicle v ON p.VehicleID = v.VehicleID
        LEFT JOIN FlowerArrangements f ON p.ArrangementID = f.ArrangementID
        LEFT JOIN ServiceLights sl ON p.LightID = sl.LightID
        LEFT JOIN Song s ON p.SongID = s.SongID
        WHERE p.PackageName = @PackageName";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@PackageName", packageName);

                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            txt_Casket.Text = reader["CasketName"].ToString();
                            txt_Vehicle.Text = reader["VehicleName"].ToString();
                            txt_Flower.Text = reader["FlowerArrangementName"].ToString();
                            txt_PackagePrice.Text = reader["TotalPrice"].ToString();
                            txt_ServiceLights.Text = reader["LightDescription"].ToString();
                            txt_Chapel.Text = reader["ChapelName"].ToString();

                            int embalmingDays = reader["EmbalmingDays"] != DBNull.Value? Convert.ToInt32(reader["EmbalmingDays"]): 0;
                            txt_EmbalmingDays.Text = embalmingDays.ToString();

                            casketPrice = reader["CasketPrice"] != DBNull.Value? Convert.ToDecimal(reader["CasketPrice"]): 0;
                            vehiclePrice = reader["VehiclePrice"] != DBNull.Value? Convert.ToDecimal(reader["VehiclePrice"]): 0;

                            txt_Song.Text = reader["SongName"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("No details found for the selected package.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                db.Close();
            }

        }


        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                UpdatePackagePrice();
            }
        }

        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                UpdatePackagePrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                casketPrice = selectFlowerForm.SelectedFlowerPrice;
                UpdatePackagePrice();
            }
        }
        private void UpdatePackagePrice()
        {
            decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + chapelPrice;
            txt_PackagePrice.Text = totalPrice.ToString("F2");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btn_SelectFLower_Click_1(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                flowerPrice = selectFlowerForm.SelectedFlowerPrice;
                UpdatePackagePrice();
            }
        }

        private void btn_Chapel_Click(object sender, EventArgs e)
        {
            SelectChapel selectChapelForm = new SelectChapel();
            if (selectChapelForm.ShowDialog() == DialogResult.OK)
            {
                txt_Chapel.Text = selectChapelForm.SelectedChapelName;
                chapelPrice = selectChapelForm.SelectedChapelPrice;

                UpdatePackagePrice();
            }
        }

        private void btn_Song_Click(object sender, EventArgs e)
        {
            SelectSong selectSongForm = new SelectSong();
            if (selectSongForm.ShowDialog() == DialogResult.OK)
            {
                string songDetails = selectSongForm.SelectedSongName + ", " +
                                 selectSongForm.SelectedArtistName + ", " +
                                 selectSongForm.SelectedGenre;

                txt_Song.Text = songDetails;
            }
        }



    }
}
