﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CustomizePackage : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        //For package name and id
        private int selectedPackageId;
        //For songs
        private int selectedPlaylistId;
        private string selectedPlaylistName; 
        //casket
        public int SelectedCasketID { get; set; }
        private decimal casketPrice = 0.0M;
        //Vehicle
        public int SelectedVehicleID { get; set; }
        
        private decimal vehiclePrice = 0.0M;
        //Flower Arrangment
        public int SelectedFlowerID { get; set; }
        private string flowerName;
        private int flowerQuantity; 
        private decimal flowerPrice = 0.0M;
        private string flowerAdditional; 

        //Equipments
        public int equipmentID { get; set; }
        string equipmentName;
        int equipmentQuantity;

        // Embalming Prices
        private decimal baseEmbalmingPrice = 0.0M;
        private decimal additionalDayCharge = 0.0M;
        private int includedDays = 0;

        public int CustomizePackageID { get; private set; }

        public CustomizePackage(int customizepackageID)
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadPackage();
            LoadEmbalmingPrices();
            InitializeDataGridView();
            if (customizepackageID != 0)
            {
                MessageBox.Show("Loading customize package details for ID: " + customizepackageID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.CustomizePackageID = customizepackageID;
                LoadCustomizePackageDetails(this.CustomizePackageID);
            }
            
        }
        private void InitializeDataGridView()
        {
            // Check if columns are already added to prevent adding duplicates
            if (dgv_FlowerArrangement.Columns.Count == 0)
            {
                dgv_FlowerArrangement.Columns.Add("FlowerID", "Flower ID");
                dgv_FlowerArrangement.Columns.Add("FlowerName", "Flower");
                dgv_FlowerArrangement.Columns.Add("FlowerPrice", "Price");
                dgv_FlowerArrangement.Columns.Add("Quantity", "Quantity");
                dgv_FlowerArrangement.Columns.Add("Additional", "Additional");
            }
            if (dgv_Equipments.Columns.Count == 0)
            {
                dgv_Equipments.Columns.Add("EquipmentID", "Equipment ID");
                dgv_Equipments.Columns.Add("EquipmentName", "Equipment Name");
                dgv_Equipments.Columns.Add("EquipmentType", "Equipment Type");
                dgv_Equipments.Columns.Add("Quantity", "Quantity");
            }
        }
        private void LoadCustomizePackageDetails(int customizePackageID)
        {
            string query = @"SELECT cp.PackageID, cp.PackageName, cp.CasketName, c.Price AS CasketPrice, 
                            cp.VehicleName, v.Price AS VehiclePrice, 
                            cp.PlaylistsName, cp.EmbalmingDays, cp.TotalPrice,
                            cp.CasketID, cp.VehicleID, cp.PlaylistSongsID
                     FROM CustomizePackage cp
                     LEFT JOIN Casket c ON cp.CasketID = c.CasketID
                     LEFT JOIN Vehicle v ON cp.VehicleID = v.VehicleID
                     WHERE cp.CustomizePackageID = @CustomizePackageID";

            string flowerQuery = @"SELECT ArrangementID, FlowerArrangementName, Quantity, Additional, PricePerUnit 
                           FROM CustomizePackageFlowerArrangements 
                           WHERE CustomizePackageID = @CustomizePackageID";

            string equipmentQuery = @"SELECT EquipmentID, EquipmentName, EquipmentType, Quantity
                              FROM CustomizePackageEquipments
                              WHERE CustomizePackageID = @CustomizePackageID";

            try
            {
                db.Open();

                // Load main package details
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@CustomizePackageID", customizePackageID);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Load main package details
                            selectedPackageId = reader["PackageID"] != DBNull.Value ? Convert.ToInt32(reader["PackageID"]) : -1;
                            cmb_Package.SelectedValue = selectedPackageId;

                            txt_Casket.Text = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                            txt_Vehicle.Text = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                            txt_Song.Text = reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A";
                            txt_EmbalmingDays.Text = reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A";

                            decimal totalPrice = reader["TotalPrice"] != DBNull.Value ? Convert.ToDecimal(reader["TotalPrice"]) : 0;
                            txt_PackagePrice.Text = totalPrice.ToString("F2");

                            SelectedCasketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                            SelectedVehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                            selectedPlaylistId = reader["PlaylistSongsID"] != DBNull.Value ? Convert.ToInt32(reader["PlaylistSongsID"]) : 0;
                        }
                    }
                }

                // Load flower arrangements
                using (SqlCommand flowerCommand = new SqlCommand(flowerQuery, db))
                {
                    flowerCommand.Parameters.AddWithValue("@CustomizePackageID", customizePackageID);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(flowerCommand))
                    {
                        DataTable flowerTable = new DataTable();
                        adapter.Fill(flowerTable);

                        dgv_FlowerArrangement.Rows.Clear();
                        foreach (DataRow row in flowerTable.Rows)
                        {
                            dgv_FlowerArrangement.Rows.Add(
                                row["ArrangementID"],
                                row["FlowerArrangementName"],
                                row["PricePerUnit"],
                                row["Quantity"],
                                row["Additional"] != DBNull.Value ? row["Additional"].ToString() : string.Empty
                                
                            );
                        }
                    }
                }
                // Load equipment details
                using (SqlCommand equipmentCommand = new SqlCommand(equipmentQuery, db))
                {
                    equipmentCommand.Parameters.AddWithValue("@CustomizePackageID", customizePackageID);
                    using (SqlDataAdapter adapter = new SqlDataAdapter(equipmentCommand))
                    {
                        DataTable equipmentTable = new DataTable();
                        adapter.Fill(equipmentTable);

                        dgv_Equipments.Rows.Clear();
                        foreach (DataRow row in equipmentTable.Rows)
                        {
                            dgv_Equipments.Rows.Add(
                                row["EquipmentID"],
                                row["EquipmentName"],
                                row["EquipmentType"],
                                row["Quantity"]
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading customize package details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadEmbalmingPrices()
        {
            string query = "SELECT IncludedDays, BasePrice, AdditionalDayCharge FROM EmbalmingPrice";

            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    includedDays = reader.GetInt32(0);
                    baseEmbalmingPrice = reader.GetDecimal(1);
                    additionalDayCharge = reader.GetDecimal(2);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading embalming prices: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void LoadPackage()
        {
            cmb_Package.Items.Clear();
            string query = "SELECT PackageID, PackageName FROM Package";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable packageTable = new DataTable();
                adapter.Fill(packageTable);

                cmb_Package.DataSource = packageTable;
                cmb_Package.DisplayMember = "PackageName";
                cmb_Package.ValueMember = "PackageID";

                cmb_Package.SelectedIndex = -1; // Clear the selection
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading packages: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void cmb_Package_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CustomizePackageID == 0)
            {
                if (cmb_Package.SelectedValue != null && cmb_Package.SelectedValue is int)
                {
                    selectedPackageId = (int)cmb_Package.SelectedValue;
                    LoadPackageDetails(selectedPackageId);
                }
                else
                {
                    ClearCustomSelections();
                    UpdateEmbalmingPrice();
                }
            }
        }
        private void ClearCustomSelections()
        {
            txt_Casket.Text = txt_Vehicle.Text = txt_Song.Text = txt_EmbalmingDays.Text = "";
            dgv_FlowerArrangement.Rows.Clear();
            casketPrice = vehiclePrice = flowerPrice = 0.0M;
            baseEmbalmingPrice = additionalDayCharge = 0.0M;
            includedDays = 0;
            txt_PackagePrice.Text = "0.00";
        }

        private void LoadPackageDetails(int packageId)
        {

            string query = @"SELECT p.PackageName, c.CasketID, c.CasketName, c.Price AS CasketPrice, v.VehicleID, v.VehicleName, v.Price AS VehiclePrice, 
                                    fa.ArrangementID, fa.ArrangementName AS FlowerArrangementName, fa.Price AS FlowerPrice, 
                                    pl.PlaylistsID, pl.PlaylistsName, p.EmbalmingDays,p.TotalPrice 
                             FROM Package p
                             LEFT JOIN Casket c ON p.CasketID = c.CasketID
                             LEFT JOIN Vehicle v ON p.VehicleID = v.VehicleID
                             LEFT JOIN FlowerArrangements fa ON p.ArrangementID = fa.ArrangementID
                             LEFT JOIN Playlists pl ON p.PlaylistsID = pl.PlaylistsID
                             WHERE p.PackageID = @PackageID";
            try
            {
                db.Open();
                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@PackageID", packageId);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    //Others
                    txt_Casket.Text = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                    txt_Vehicle.Text = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                    txt_Song.Text = reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A";
                    txt_EmbalmingDays.Text = reader["EmbalmingDays"] != DBNull.Value ? reader["EmbalmingDays"].ToString() : "N/A";

                    // Populate TotalPrice in TextBox
                    decimal totalPrice = reader["TotalPrice"] != DBNull.Value ? Convert.ToDecimal(reader["TotalPrice"]) : 0;
                    txt_PackagePrice.Text = totalPrice.ToString("F2");

                    // Assign selected IDs
                    SelectedCasketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                    SelectedVehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                    SelectedFlowerID = reader["ArrangementID"] != DBNull.Value ? Convert.ToInt32(reader["ArrangementID"]) : 0;
                    selectedPlaylistId = reader["PlaylistsID"] != DBNull.Value ? Convert.ToInt32(reader["PlaylistsID"]) : 0;

                    // Extract and display individual prices
                     casketPrice = reader["CasketPrice"] != DBNull.Value ? Convert.ToDecimal(reader["CasketPrice"]) : 0;
                     vehiclePrice = reader["VehiclePrice"] != DBNull.Value ? Convert.ToDecimal(reader["VehiclePrice"]) : 0;
                     flowerPrice = reader["FlowerPrice"] != DBNull.Value ? Convert.ToDecimal(reader["FlowerPrice"]) : 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading package details: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                SelectedCasketID = selectCasketForm.SelectedCasketID;

                UpdateEmbalmingPrice();
            }
        }
        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                SelectedVehicleID = selectVehicleForm.SelectedVehicleID;

                UpdateEmbalmingPrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                var selectedFlowers = selectFlowerForm.SelectedFlowers;
                dgv_FlowerArrangement.Rows.Clear();

                foreach (var flower in selectedFlowers)
                {
                    dgv_FlowerArrangement.Rows.Add(flower.FlowerID, flower.FlowerName, flower.FlowerPrice.ToString("F2"), flower.Quantity, flower.Additional);

                    flowerPrice += flower.FlowerPrice * flower.Quantity;
                    SelectedFlowerID = flower.FlowerID;
                    flowerName = flower.FlowerName;
                    flowerQuantity = flower.Quantity;
                    flowerAdditional = flower.Additional;
                }

                UpdateEmbalmingPrice();
            }
        }
        //done
        private void btn_Song_Click(object sender, EventArgs e)
        {
            SelectSong selectPlaylistForm = new SelectSong();
            if (selectPlaylistForm.ShowDialog() == DialogResult.OK)
            {
                txt_Song.Text = selectPlaylistForm.SelectedPlaylistName;
                selectedPlaylistId = selectPlaylistForm.SelectedPlaylistId;
                selectedPlaylistName = selectPlaylistForm.SelectedPlaylistName;
            }
        }
        private void btn_SelectEquipment_Click(object sender, EventArgs e)
        {
            SelectEquipments selectEquipmentForm = new SelectEquipments();
            if (selectEquipmentForm.ShowDialog() == DialogResult.OK)
            {
                var selectedEquipments = selectEquipmentForm.SelectedEquipments;
                dgv_Equipments.Rows.Clear();

                foreach (var equipment in selectedEquipments)
                {
                    dgv_Equipments.Rows.Add(equipment.EquipmentID, equipment.EquipmentName, equipment.EquipmentType, equipment.Quantity);

                    // You can also add logic to update any totals or specific details for each equipment.
                    equipmentID = equipment.EquipmentID;
                    equipmentName = equipment.EquipmentName;
                    equipmentQuantity = equipment.Quantity;
                }
            }
        }
        private void btn_ClearCasket_Click(object sender, EventArgs e)
        {
            // Clear the casket text field
            txt_Casket.Text = string.Empty;

            // Reset the selected casket ID and price
            SelectedCasketID = 0;
            casketPrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearVehicle_Click(object sender, EventArgs e)
        {
            // Clear the vehicle text field
            txt_Vehicle.Text = string.Empty;

            // Reset the selected vehicle ID and price
            SelectedVehicleID = 0;
            vehiclePrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearArrangement_Click(object sender, EventArgs e)
        {
            dgv_FlowerArrangement.Rows.Clear();

            SelectedFlowerID = 0;
            flowerPrice = 0.0M;
            UpdateEmbalmingPrice();
        }

        private void btn_ClearPlaylist_Click(object sender, EventArgs e)
        {
            txt_Song.Text = string.Empty;

            selectedPlaylistId = 0;
        }
        private void btn_ClearEquipment_Click(object sender, EventArgs e)
        {
            dgv_Equipments.Rows.Clear();

            equipmentID = 0;
        }

        private void txt_EmbalmingDays_TextChanged(object sender, EventArgs e)
        {
            UpdateEmbalmingPrice();
        }
        private void UpdateEmbalmingPrice()
        {
            if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
            {
                // If the input is empty, set the embalming price to the base price
                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice).ToString("F2");
                return; // Exit the method early
            }
            int embalmingDays = 0;
            if (int.TryParse(txt_EmbalmingDays.Text, out embalmingDays))
            {
                decimal embalmingPrice = 0;
                if (string.IsNullOrEmpty(txt_EmbalmingDays.Text))
                {
                    // Input is empty, so use the base embalming price
                    embalmingPrice = baseEmbalmingPrice;
                }
                if (embalmingDays > 0)
                {
                    // Start with the base embalming price
                    embalmingPrice = baseEmbalmingPrice;

                    if (embalmingDays > includedDays)
                    {
                        // Calculate additional charges if days exceed the included days
                        int additionalDays = embalmingDays - includedDays;
                        embalmingPrice += additionalDays * additionalDayCharge;
                    }
                }

                // Calculate the total price with or without embalming
                decimal totalPrice = casketPrice + vehiclePrice + flowerPrice + embalmingPrice;

                // Update the total price in the text box
                txt_PackagePrice.Text = totalPrice.ToString("F2");
            }
            else
            {
                txt_PackagePrice.Text = (casketPrice + vehiclePrice + flowerPrice + baseEmbalmingPrice).ToString("F2");
            }
        }
        private void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmb_Package.SelectedValue == null)
                {
                    MessageBox.Show("Please select a valid package before saving.", "Invalid Package", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return; // Exit the method early
                }
                if (CustomizePackageID == 0) 
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to save this package customization?",
                                                         "Confirm Save",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.Yes)
                    {
                        SavePackage();
                        SaveFlowerArrangements();
                        SaveEquipments();
                        MessageBox.Show("Customization saved successfully!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
                else
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to update this package customization?",
                                                         "Confirm Update",
                                                         MessageBoxButtons.YesNo,
                                                         MessageBoxIcon.Question);
                    if (confirmResult == DialogResult.Yes)
                    {
                        UpdatePackage(); 
                        MessageBox.Show("Customization updated successfully!");
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving: " + ex.Message);
            }
        }
        private void SavePackage()
        {
            // Calculate total price based on custom selections
            decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);
            string packageName = cmb_Package.Text; 

            string query = @"INSERT INTO CustomizePackage (PackageID, CasketID, VehicleID, PlaylistSongsID, PackageName,
                             CasketName, VehicleName, PlaylistsName, EmbalmingDays, TotalPrice, CreatedDate)
                             VALUES (@PackageID, @CasketID, @VehicleID, @PlaylistSongsID, @PackageName, @CasketName, @VehicleName, 
                             @PlaylistsName, @EmbalmingDays, @TotalPrice, GETDATE());
                             SELECT SCOPE_IDENTITY();";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@PackageID", selectedPackageId > 0 ? (object)selectedPackageId : DBNull.Value);
                command.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                command.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                command.Parameters.AddWithValue("@PlaylistSongsID", selectedPlaylistId > 0 ? (object)selectedPlaylistId : DBNull.Value);
                command.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                command.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(txt_Casket.Text) ? DBNull.Value : (object)txt_Casket.Text);
                command.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(txt_Vehicle.Text) ? DBNull.Value : (object)txt_Vehicle.Text);
                command.Parameters.AddWithValue("@PlaylistsName", string.IsNullOrEmpty(txt_Song.Text) ? DBNull.Value : (object)txt_Song.Text);
                command.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? DBNull.Value : (object)txt_EmbalmingDays.Text);
                command.Parameters.AddWithValue("@TotalPrice", totalPrice);

                try
                {
                    db.Open();
                    CustomizePackageID = Convert.ToInt32(command.ExecuteScalar());
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving package: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        private void SaveFlowerArrangements()
        {
            string query = @"INSERT INTO CustomizePackageFlowerArrangements 
                     (CustomizePackageID, ArrangementID, FlowerArrangementName, Quantity, Additional, PricePerUnit)
                     VALUES (@CustomizePackageID, @ArrangementID, @FlowerArrangementName, @Quantity, @Additional, @PricePerUnit)";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                {
                    if (row.Cells["FlowerID"].Value != null)
                    {
                        command.Parameters.Clear();
                        command.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                        command.Parameters.AddWithValue("@ArrangementID", row.Cells["FlowerID"].Value);
                        command.Parameters.AddWithValue("@FlowerArrangementName", row.Cells["FlowerName"].Value);
                        command.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                        command.Parameters.AddWithValue("@Additional", row.Cells["Additional"].Value ?? DBNull.Value);
                        command.Parameters.AddWithValue("@PricePerUnit", row.Cells["FlowerPrice"].Value);

                        try
                        {
                            db.Open();
                            command.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving flower arrangements: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            db.Close();
                        }
                    }
                }
            }
        }
        private void SaveEquipments()
        {
            string query = @"INSERT INTO CustomizePackageEquipments 
                     (CustomizePackageID, EquipmentID, EquipmentName, EquipmentType, Quantity)
                     VALUES (@CustomizePackageID, @EquipmentID, @EquipmentName, @EquipmentType, @Quantity)";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                foreach (DataGridViewRow row in dgv_Equipments.Rows)
                {
                    if (row.Cells["EquipmentID"].Value != null)
                    {
                        command.Parameters.Clear();
                        command.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                        command.Parameters.AddWithValue("@EquipmentID", row.Cells["EquipmentID"].Value);
                        command.Parameters.AddWithValue("@EquipmentName", row.Cells["EquipmentName"].Value);
                        command.Parameters.AddWithValue("@EquipmentType", row.Cells["EquipmentType"].Value);
                        command.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);

                        try
                        {
                            db.Open();
                            command.ExecuteNonQuery();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving equipment: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            db.Close();
                        }
                    }
                }
            }
        }
        private void UpdatePackage()
        {
            // Calculate total price based on custom selections
            decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);
            string packageName = cmb_Package.Text;

            string updatePackageQuery = @"UPDATE CustomizePackage 
                                  SET PackageID = @PackageID,
                                      CasketID = @CasketID,
                                      VehicleID = @VehicleID,
                                      PlaylistSongsID = @PlaylistSongsID,
                                      PackageName = @PackageName,
                                      CasketName = @CasketName,
                                      VehicleName = @VehicleName,
                                      PlaylistsName = @PlaylistsName,
                                      EmbalmingDays = @EmbalmingDays,
                                      TotalPrice = @TotalPrice
                                  WHERE CustomizePackageID = @CustomizePackageID";

            string deleteFlowerArrangementsQuery = @"DELETE FROM CustomizePackageFlowerArrangements 
                                             WHERE CustomizePackageID = @CustomizePackageID";

            string insertFlowerArrangementsQuery = @"INSERT INTO CustomizePackageFlowerArrangements 
                                             (CustomizePackageID, ArrangementID, FlowerArrangementName, Quantity, Additional, PricePerUnit)
                                             VALUES (@CustomizePackageID, @ArrangementID, @FlowerArrangementName, @Quantity, @Additional, @PricePerUnit)";
           
            string deleteEquipmentsQuery = @"DELETE FROM CustomizePackageEquipments 
                                     WHERE CustomizePackageID = @CustomizePackageID";

            string insertEquipmentsQuery = @"INSERT INTO CustomizePackageEquipments 
                                     (CustomizePackageID, EquipmentID, EquipmentName, EquipmentType, Quantity)
                                     VALUES (@CustomizePackageID, @EquipmentID, @EquipmentName, @EquipmentType, @Quantity)";

            try
            {
                db.Open();

                // Update the main package
                using (SqlCommand updateCommand = new SqlCommand(updatePackageQuery, db))
                {
                    updateCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                    updateCommand.Parameters.AddWithValue("@PackageID", selectedPackageId > 0 ? (object)selectedPackageId : DBNull.Value);
                    updateCommand.Parameters.AddWithValue("@CasketID", SelectedCasketID > 0 ? (object)SelectedCasketID : DBNull.Value);
                    updateCommand.Parameters.AddWithValue("@VehicleID", SelectedVehicleID > 0 ? (object)SelectedVehicleID : DBNull.Value);
                    updateCommand.Parameters.AddWithValue("@PlaylistSongsID", selectedPlaylistId > 0 ? (object)selectedPlaylistId : DBNull.Value);
                    updateCommand.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                    updateCommand.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(txt_Casket.Text) ? DBNull.Value : (object)txt_Casket.Text);
                    updateCommand.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(txt_Vehicle.Text) ? DBNull.Value : (object)txt_Vehicle.Text);
                    updateCommand.Parameters.AddWithValue("@PlaylistsName", string.IsNullOrEmpty(txt_Song.Text) ? DBNull.Value : (object)txt_Song.Text);
                    updateCommand.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? DBNull.Value : (object)txt_EmbalmingDays.Text);
                    updateCommand.Parameters.AddWithValue("@TotalPrice", totalPrice);
                    updateCommand.ExecuteNonQuery();
                }

                // Delete existing flower arrangements
                using (SqlCommand deleteCommand = new SqlCommand(deleteFlowerArrangementsQuery, db))
                {
                    deleteCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                    deleteCommand.ExecuteNonQuery();
                }

                // Insert updated flower arrangements
                using (SqlCommand insertCommand = new SqlCommand(insertFlowerArrangementsQuery, db))
                {
                    foreach (DataGridViewRow row in dgv_FlowerArrangement.Rows)
                    {
                        if (row.Cells["FlowerID"].Value != null)
                        {
                            insertCommand.Parameters.Clear();
                            insertCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                            insertCommand.Parameters.AddWithValue("@ArrangementID", row.Cells["FlowerID"].Value);
                            insertCommand.Parameters.AddWithValue("@FlowerArrangementName", row.Cells["FlowerName"].Value);
                            insertCommand.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                            insertCommand.Parameters.AddWithValue("@Additional", row.Cells["Additional"].Value);
                            insertCommand.Parameters.AddWithValue("@PricePerUnit", row.Cells["FlowerPrice"].Value);
                            insertCommand.ExecuteNonQuery();
                        }
                    }
                }
                // Delete existing equipment
                using (SqlCommand deleteEquipmentCommand = new SqlCommand(deleteEquipmentsQuery, db))
                {
                    deleteEquipmentCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                    deleteEquipmentCommand.ExecuteNonQuery();
                }

                // Insert updated equipment
                using (SqlCommand insertEquipmentCommand = new SqlCommand(insertEquipmentsQuery, db))
                {
                    foreach (DataGridViewRow row in dgv_Equipments.Rows)
                    {
                        if (row.Cells["EquipmentID"].Value != null)
                        {
                            insertEquipmentCommand.Parameters.Clear();
                            insertEquipmentCommand.Parameters.AddWithValue("@CustomizePackageID", CustomizePackageID);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentID", row.Cells["EquipmentID"].Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentName", row.Cells["EquipmentName"].Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@EquipmentType", row.Cells["EquipmentType"].Value);
                            insertEquipmentCommand.Parameters.AddWithValue("@Quantity", row.Cells["Quantity"].Value);
                            insertEquipmentCommand.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating package: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
