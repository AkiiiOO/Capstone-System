﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CustomizePackage : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        //For songs
        private int selectedId;
        private string selectedName; 
        //casket
        public int SelectedCasketID { get; set; }
        private decimal casketPrice = 0.0M;
        //Vehicle
        public int SelectedVehicleID { get; set; }
        private decimal vehiclePrice = 0.0M;
        //Flower Arrangment
        public int SelectedFlowerID { get; set; }
        private decimal flowerPrice = 0.0M;

        public int SelectedPackageID { get; set; }
        public string SelectedPackageName { get; set; }
     
        public int SelectedSongID { get; set; }

        public CustomizePackage()
        {
            InitializeComponent();
            db = y.GetConnection();
            btn_Update.Visible = false; 
        }

        private void CustomizePackage_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(SelectedPackageName))
            {
                lbl_PackageName.Text = SelectedPackageName;
                
                if (PackageCustomized(SelectedPackageID))
                {
                    LoadCustomizedDetails(SelectedPackageID);
                    btn_Update.Visible = true;
                    btn_Save.Visible = false;
                }
                else
                {
                    LoadPackageDetails(SelectedPackageName);
                    btn_Update.Visible = false;
                    btn_Save.Visible = true;
                }

            }
        }

        private bool PackageCustomized(int packageId)
        {
            try
            {
                string query = "SELECT COUNT(*) FROM CustomizePackage WHERE PackageID = @PackageID";
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@PackageID", packageId);
                    db.Open();
                    int count = (int)command.ExecuteScalar();
                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while checking the package: " + ex.Message);
                return false;
            }
            finally
            {
                db.Close();
            }
        }
        private void LoadCustomizedDetails(int packageId)
        {
            try
            {
                string query = @"SELECT p.CasketID, p.VehicleID, p.ArrangementID, p.SongID, p.CasketName, p.VehicleName, p.FlowerArrangementName, p.TotalPrice, c.Price AS CasketPrice, v.Price AS VehiclePrice, f.Price AS FlowerPrice, ch.Price AS ChapelPrice, sl.LightDescription, p.ChapelName, p.EmbalmingDays, s.SongName
                                 FROM CustomizePackage p
                                 LEFT JOIN Casket c ON p.CasketID = c.CasketID
                                 LEFT JOIN Vehicle v ON p.VehicleID = v.VehicleID
                                 LEFT JOIN FlowerArrangements f ON p.ArrangementID = f.ArrangementID
                                 LEFT JOIN ServiceLights sl ON p.LightID = sl.LightID
                                 LEFT JOIN Song s ON p.SongID = s.SongID
                                 WHERE p.PackageID = @PackageID";

                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@PackageID", packageId);

                db.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    txt_Casket.Text = reader["CasketName"].ToString();
                    txt_Vehicle.Text = reader["VehicleName"].ToString();
                    txt_Flower.Text = reader["FlowerArrangementName"].ToString();
                    txt_PackagePrice.Text = reader["TotalPrice"].ToString();
                    txt_ServiceLights.Text = reader["LightDescription"].ToString();

                    int embalmingDays = reader["EmbalmingDays"] != DBNull.Value ? Convert.ToInt32(reader["EmbalmingDays"]) : 0;
                    txt_EmbalmingDays.Text = embalmingDays.ToString();

                    casketPrice = reader["CasketPrice"] != DBNull.Value ? Convert.ToDecimal(reader["CasketPrice"]) : 0;
                    vehiclePrice = reader["VehiclePrice"] != DBNull.Value ? Convert.ToDecimal(reader["VehiclePrice"]) : 0;
                    flowerPrice = reader["FlowerPrice"] != DBNull.Value ? Convert.ToDecimal(reader["FlowerPrice"]) : 0;

                    SelectedCasketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                    SelectedVehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                    SelectedFlowerID = reader["ArrangementID"] != DBNull.Value ? Convert.ToInt32(reader["ArrangementID"]) : 0;
                    SelectedSongID = reader["SongID"] != DBNull.Value ? Convert.ToInt32(reader["SongID"]) : 0;

                    txt_Song.Text = reader["SongName"].ToString();
                }
                else
                {
                    MessageBox.Show("No details found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }
        private void LoadPackageDetails(string packageName)
        {
            try
            {
                string query = @"SELECT p.CasketID, p.VehicleID, p.ArrangementID, p.SongID, p.CasketName, p.VehicleName, p.FlowerArrangementName, p.TotalPrice, c.Price AS CasketPrice, v.Price AS VehiclePrice, f.Price AS FlowerPrice, ch.Price AS ChapelPrice, sl.LightDescription, p.ChapelName, p.EmbalmingDays, s.SongName
                                 FROM Package p
                                 LEFT JOIN Casket c ON p.CasketID = c.CasketID
                                 LEFT JOIN Vehicle v ON p.VehicleID = v.VehicleID
                                 LEFT JOIN FlowerArrangements f ON p.ArrangementID = f.ArrangementID
                                 LEFT JOIN ServiceLights sl ON p.LightID = sl.LightID
                                 LEFT JOIN Song s ON p.SongID = s.SongID
                                 WHERE p.PackageName = @PackageName";

                SqlCommand command = new SqlCommand(query, db);
                command.Parameters.AddWithValue("@PackageName", packageName);

                db.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    txt_Casket.Text = reader["CasketName"].ToString();
                    txt_Vehicle.Text = reader["VehicleName"].ToString();
                    txt_Flower.Text = reader["FlowerArrangementName"].ToString();
                    txt_PackagePrice.Text = reader["TotalPrice"].ToString();
                    txt_ServiceLights.Text = reader["LightDescription"].ToString();

                    int embalmingDays = reader["EmbalmingDays"] != DBNull.Value ? Convert.ToInt32(reader["EmbalmingDays"]) : 0;
                    txt_EmbalmingDays.Text = embalmingDays.ToString();

                    casketPrice = reader["CasketPrice"] != DBNull.Value ? Convert.ToDecimal(reader["CasketPrice"]) : 0;
                    vehiclePrice = reader["VehiclePrice"] != DBNull.Value ? Convert.ToDecimal(reader["VehiclePrice"]) : 0;
                    flowerPrice = reader["FlowerPrice"] != DBNull.Value ? Convert.ToDecimal(reader["FlowerPrice"]) : 0;

                    SelectedFlowerID = reader["ArrangementID"] != DBNull.Value ? Convert.ToInt32(reader["ArrangementID"]) : 0;
                    SelectedSongID = reader["SongID"] != DBNull.Value ? Convert.ToInt32(reader["SongID"]) : 0;

                    txt_Song.Text = reader["SongName"].ToString();
                }
                else
                {
                    MessageBox.Show("No details found for the selected package.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                db.Close();
            }

        }


        private void btn_SelectCasket_Click(object sender, EventArgs e)
        {
            SelectCasket selectCasketForm = new SelectCasket();

            if (selectCasketForm.ShowDialog() == DialogResult.OK)
            {
                txt_Casket.Text = selectCasketForm.SelectedCasketName;
                casketPrice = selectCasketForm.SelectedCasketPrice;
                SelectedCasketID = selectCasketForm.SelectedCasketID;

                UpdatePackagePrice();
            }
        }

        private void btn_SelectVehicle_Click(object sender, EventArgs e)
        {
            SelectVehicle selectVehicleForm = new SelectVehicle();

            if (selectVehicleForm.ShowDialog() == DialogResult.OK)
            {
                txt_Vehicle.Text = selectVehicleForm.SelectedVehicleName;
                vehiclePrice = selectVehicleForm.SelectedVehiclePrice;
                SelectedVehicleID = selectVehicleForm.SelectedVehicleID;

                UpdatePackagePrice();
            }
        }

        private void btn_SelectFLower_Click(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                casketPrice = selectFlowerForm.SelectedFlowerPrice;
                UpdatePackagePrice();
            }
        }
        private void UpdatePackagePrice()
        {
            decimal totalPrice = casketPrice + vehiclePrice + flowerPrice;
            txt_PackagePrice.Text = totalPrice.ToString("F2");
        }



        private void btn_SelectFLower_Click_1(object sender, EventArgs e)
        {
            SelectFlowerArrangement selectFlowerForm = new SelectFlowerArrangement();

            if (selectFlowerForm.ShowDialog() == DialogResult.OK)
            {
                txt_Flower.Text = selectFlowerForm.SelectedFlowerName;
                flowerPrice = selectFlowerForm.SelectedFlowerPrice;
                UpdatePackagePrice();
            }
        }
        //done
        private void btn_Song_Click(object sender, EventArgs e)
        {
            SelectSong selectSongForm = new SelectSong();
            if (selectSongForm.ShowDialog() == DialogResult.OK)
            {
                selectedId = selectSongForm.SelectedPlaylistId;
                selectedName = selectSongForm.SelectedPlaylistName;
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            try
            {
                if (SelectedCasketID == 0 || SelectedVehicleID == 0 || SelectedFlowerID == 0)
                {
                    MessageBox.Show("Please select valid one .");
                    return;
                }

                decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);

                string query = @"INSERT INTO CustomizePackage (PackageID, CasketID, VehicleID, ArrangementID, PlaylistsID, LightID,
                    CasketName, VehicleName, FlowerArrangementName,PlaylistsName, EmbalmingDays, TotalPrice, CreatedDate)
                    VALUES 
                    (@PackageID, @CasketID, @VehicleID, @ArrangementID, @PlaylistsID, @LightID, @CasketName, @VehicleName, 
                     @FlowerArrangementName, @PlaylistsName, @EmbalmingDays, @TotalPrice, GETDATE())";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@PackageID", SelectedPackageID);
                    command.Parameters.AddWithValue("@CasketID", SelectedCasketID);
                    command.Parameters.AddWithValue("@VehicleID", SelectedVehicleID);
                    command.Parameters.AddWithValue("@ArrangementID", SelectedFlowerID);
                    command.Parameters.AddWithValue("@PlaylistsID", selectedId);//done
                    command.Parameters.AddWithValue("@LightID", 1);
                    command.Parameters.AddWithValue("@ReservationID", 1);
                    command.Parameters.AddWithValue("@VehicleName", txt_Vehicle.Text);
                    command.Parameters.AddWithValue("@FlowerArrangementName", txt_Flower.Text);
                    command.Parameters.AddWithValue("@PlaylistsName", selectedName);//done
                    command.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? (object)DBNull.Value : Convert.ToInt32(txt_EmbalmingDays.Text));
                    command.Parameters.AddWithValue("@TotalPrice", totalPrice);

                    if (db.State != ConnectionState.Open)
                    {
                        db.Open(); // Ensure connection is open
                    }

                    command.ExecuteNonQuery();
                    MessageBox.Show("Customization saved successfully!");

                    this.DialogResult = DialogResult.OK; // Set the dialog result
                    this.Close(); 

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close(); // Ensure connection is closed
                }
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            try
            {
                if (SelectedCasketID == 0 || SelectedVehicleID == 0 || SelectedFlowerID == 0)
                {
                    MessageBox.Show("Please select valid options.");
                    return;
                }

                decimal totalPrice = decimal.Parse(txt_PackagePrice.Text);

                string query = @"UPDATE CustomizePackage SET CasketID = @CasketID,
                                                             VehicleID = @VehicleID,
                                                             ArrangementID = @ArrangementID,
                                                             SongID = @SongID,
                                                             LightID = @LightID,
                                                             CasketName = @CasketName,
                                                             VehicleName = @VehicleName,
                                                             FlowerArrangementName = @FlowerArrangementName,
                                                             EmbalmingDays = @EmbalmingDays,
                                                             TotalPrice = @TotalPrice
                                                             WHERE PackageID = @PackageID";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@PackageID", SelectedPackageID);
                    command.Parameters.AddWithValue("@CasketID", SelectedCasketID);
                    command.Parameters.AddWithValue("@VehicleID", SelectedVehicleID);
                    command.Parameters.AddWithValue("@ArrangementID", SelectedFlowerID);
                    command.Parameters.AddWithValue("@SongID", SelectedSongID);
                    command.Parameters.AddWithValue("@LightID", 1);
                    command.Parameters.AddWithValue("@ReservationID", 1);
                    command.Parameters.AddWithValue("@CasketName", txt_Casket.Text);
                    command.Parameters.AddWithValue("@VehicleName", txt_Vehicle.Text);
                    command.Parameters.AddWithValue("@FlowerArrangementName", txt_Flower.Text);
                    command.Parameters.AddWithValue("@EmbalmingDays", string.IsNullOrEmpty(txt_EmbalmingDays.Text) ? (object)DBNull.Value : Convert.ToInt32(txt_EmbalmingDays.Text));
                    command.Parameters.AddWithValue("@TotalPrice", totalPrice);

                    if (db.State != ConnectionState.Open)
                    {
                        db.Open();
                    }

                    command.ExecuteNonQuery();
                    MessageBox.Show("Customization updated successfully!");

                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }

        }
    }
}
