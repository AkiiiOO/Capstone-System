﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class Chapel_Service : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public int ServiceTypeId { get; set; }
        public string SelectedServiceType { get; set; }

        public Chapel_Service()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadChapel();
        }
        private void LoadChapel()
        {
            cmb_Chapel.Items.Clear();

            string query = "SELECT ChapelID, ChapelName, Price FROM Chapel";

            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable playlistsTable = new DataTable();
                adapter.Fill(playlistsTable);

                cmb_Chapel.DataSource = playlistsTable;
                cmb_Chapel.DisplayMember = "ChapelName";
                cmb_Chapel.ValueMember = "ChapelID";

                cmb_Chapel.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading playlists: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void cmb_Chapel_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Chapel.SelectedItem != null)
            {
                DataRowView selectedChapel = (DataRowView)cmb_Chapel.SelectedItem;
                decimal price = Convert.ToDecimal(selectedChapel["Price"]);
                lbl_Price.Text = price.ToString("F2");
            }
            else
            {
                lbl_Price.Text = "";
            }
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (cmb_Chapel.SelectedValue == null)
            {
                MessageBox.Show("Please select a chapel.", "Chapel Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int chapelId = (int)cmb_Chapel.SelectedValue;
            SaveChapelReservation(chapelId, ServiceTypeId, SelectedServiceType);

        }
        private void SaveChapelReservation(int chapelId, int serviceTypeId, string selectedServiceType)
        {
            string query = @"INSERT INTO ChapelReservation (ChapelID, ClientID, ServiceTypeID, ServiceTypeName, StartDate, EndDate, ReservedBy)
                     VALUES (@ChapelID, @ClientID, @ServiceTypeID, @ServiceTypeName, @StartDate, @EndDate, @ReservedBy)";
            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@ChapelID", chapelId);
                command.Parameters.AddWithValue("@ClientID", 1);  // Assume you have ClientID
                command.Parameters.AddWithValue("@ServiceTypeID", serviceTypeId);
                command.Parameters.AddWithValue("@ServiceTypeName", selectedServiceType);
                command.Parameters.AddWithValue("@StartDate", dtp_StartDate.Value);
                command.Parameters.AddWithValue("@EndDate", dtp_EndDate.Value);
                command.Parameters.AddWithValue("@ReservedBy", "kl"); // Assume you have ReservedBy

                try
                {
                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Chapel reservation saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error saving chapel reservation: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
    }
}
