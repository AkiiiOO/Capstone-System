﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class RestockEquipmentForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public event EventHandler ClientAdded;

        public RestockEquipmentForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            SetupDataGridView();
            LoadEquipmentList();
        }
        private void SetupDataGridView()
        {
            // Create a checkbox column for selecting equipment
            DataGridViewCheckBoxColumn selectColumn = new DataGridViewCheckBoxColumn();
            selectColumn.HeaderText = "Select";
            selectColumn.Name = "Select";
            dgv_EquipmentList.Columns.Insert(0, selectColumn);
        }
        private void LoadEquipmentList()
        {
            try
            {
                // Query to load equipment list
                string query = "SELECT EquipmentID, EquipmentName, EquipmentType, Quantity FROM Equipment";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtEquipment = new DataTable();
                adapter.Fill(dtEquipment);

                dgv_EquipmentList.DataSource = dtEquipment;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading equipment: " + ex.Message);
            }
        }

        private void btn_Restock_Click(object sender, EventArgs e)
        {
            int restockQuantity;
            if (string.IsNullOrEmpty(txt_RestockQuantity.Text) || !int.TryParse(txt_RestockQuantity.Text, out restockQuantity))
            {
                MessageBox.Show("Please enter a valid quantity to restock.");
                return;
            }

            // Loop through the rows in the DataGridView to check which are selected
            foreach (DataGridViewRow row in dgv_EquipmentList.Rows)
            {
                if (Convert.ToBoolean(row.Cells["Select"].Value)) // Check if the checkbox is selected
                {
                    int equipmentId = Convert.ToInt32(row.Cells["EquipmentID"].Value);
                    int currentQuantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                    
                    // Update the equipment quantity (this could be a database update)
                    int updatedQuantity = currentQuantity + restockQuantity;
                    
                    // Simulate updating the database (replace with actual database query)
                    string updateQuery = "UPDATE Equipment SET Quantity = @Quantity WHERE EquipmentID = @EquipmentID";
                    using (SqlCommand command = new SqlCommand(updateQuery, db))
                    {
                        command.Parameters.AddWithValue("@Quantity", updatedQuantity);
                        command.Parameters.AddWithValue("@EquipmentID", equipmentId);
                        
                        db.Open();
                        command.ExecuteNonQuery();
                        db.Close();
                    }

                    // Update the DataGridView to reflect the new quantity
                    row.Cells["Quantity"].Value = updatedQuantity;
                }
            }

            MessageBox.Show("Selected equipment restocked successfully.");
            ClientAdded.Invoke(this, EventArgs.Empty);
        }
    }
}
