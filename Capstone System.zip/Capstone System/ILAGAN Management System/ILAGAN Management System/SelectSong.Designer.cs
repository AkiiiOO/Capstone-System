﻿namespace ILAGAN_Management_System
{
    partial class SelectSong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmb_Playlist = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dgv_Playlist = new System.Windows.Forms.DataGridView();
            this.btn_CreatePlaylist = new ILAGAN_Management_System.RoundedButton();
            this.btn_Addsong = new ILAGAN_Management_System.RoundedButton();
            this.btn_Select = new ILAGAN_Management_System.RoundedButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Playlist)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(367, 68);
            this.panel1.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label1.Location = new System.Drawing.Point(85, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 50);
            this.label1.TabIndex = 10;
            this.label1.Text = "Select Playlist";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ILAGAN_Management_System.Properties.Resources.IlaganLogo;
            this.pictureBox1.Location = new System.Drawing.Point(10, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(69, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // cmb_Playlist
            // 
            this.cmb_Playlist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmb_Playlist.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Playlist.FormattingEnabled = true;
            this.cmb_Playlist.Location = new System.Drawing.Point(89, 87);
            this.cmb_Playlist.Name = "cmb_Playlist";
            this.cmb_Playlist.Size = new System.Drawing.Size(250, 26);
            this.cmb_Playlist.TabIndex = 162;
            this.cmb_Playlist.SelectedIndexChanged += new System.EventHandler(this.cmb_Playlist_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(19, 92);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 16);
            this.label12.TabIndex = 163;
            this.label12.Text = "Playlist:";
            // 
            // dgv_Playlist
            // 
            this.dgv_Playlist.AllowUserToAddRows = false;
            this.dgv_Playlist.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_Playlist.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_Playlist.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.dgv_Playlist.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_Playlist.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_Playlist.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_Playlist.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Playlist.Location = new System.Drawing.Point(22, 130);
            this.dgv_Playlist.Name = "dgv_Playlist";
            this.dgv_Playlist.ReadOnly = true;
            this.dgv_Playlist.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dgv_Playlist.RowHeadersVisible = false;
            this.dgv_Playlist.Size = new System.Drawing.Size(317, 120);
            this.dgv_Playlist.TabIndex = 164;
            // 
            // btn_CreatePlaylist
            // 
            this.btn_CreatePlaylist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_CreatePlaylist.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_CreatePlaylist.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_CreatePlaylist.BorderRadius = 5;
            this.btn_CreatePlaylist.BorderSize = 0;
            this.btn_CreatePlaylist.FlatAppearance.BorderSize = 0;
            this.btn_CreatePlaylist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CreatePlaylist.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CreatePlaylist.ForeColor = System.Drawing.Color.White;
            this.btn_CreatePlaylist.Location = new System.Drawing.Point(22, 270);
            this.btn_CreatePlaylist.Name = "btn_CreatePlaylist";
            this.btn_CreatePlaylist.Size = new System.Drawing.Size(112, 30);
            this.btn_CreatePlaylist.TabIndex = 167;
            this.btn_CreatePlaylist.Text = "Create Playlist";
            this.btn_CreatePlaylist.TextColor = System.Drawing.Color.White;
            this.btn_CreatePlaylist.UseVisualStyleBackColor = false;
            this.btn_CreatePlaylist.Click += new System.EventHandler(this.btn_CreatePlaylist_Click);
            // 
            // btn_Addsong
            // 
            this.btn_Addsong.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Addsong.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Addsong.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Addsong.BorderRadius = 5;
            this.btn_Addsong.BorderSize = 0;
            this.btn_Addsong.FlatAppearance.BorderSize = 0;
            this.btn_Addsong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Addsong.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Addsong.ForeColor = System.Drawing.Color.White;
            this.btn_Addsong.Location = new System.Drawing.Point(160, 270);
            this.btn_Addsong.Name = "btn_Addsong";
            this.btn_Addsong.Size = new System.Drawing.Size(81, 30);
            this.btn_Addsong.TabIndex = 166;
            this.btn_Addsong.Text = "Add Song";
            this.btn_Addsong.TextColor = System.Drawing.Color.White;
            this.btn_Addsong.UseVisualStyleBackColor = false;
            this.btn_Addsong.Click += new System.EventHandler(this.btn_Addsong_Click);
            // 
            // btn_Select
            // 
            this.btn_Select.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Select.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btn_Select.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Select.BorderRadius = 5;
            this.btn_Select.BorderSize = 0;
            this.btn_Select.FlatAppearance.BorderSize = 0;
            this.btn_Select.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Select.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Select.ForeColor = System.Drawing.Color.White;
            this.btn_Select.Location = new System.Drawing.Point(270, 270);
            this.btn_Select.Name = "btn_Select";
            this.btn_Select.Size = new System.Drawing.Size(70, 30);
            this.btn_Select.TabIndex = 161;
            this.btn_Select.Text = "Select";
            this.btn_Select.TextColor = System.Drawing.Color.White;
            this.btn_Select.UseVisualStyleBackColor = false;
            this.btn_Select.Click += new System.EventHandler(this.btn_Select_Click);
            // 
            // SelectSong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.ClientSize = new System.Drawing.Size(367, 320);
            this.Controls.Add(this.btn_CreatePlaylist);
            this.Controls.Add(this.btn_Addsong);
            this.Controls.Add(this.dgv_Playlist);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cmb_Playlist);
            this.Controls.Add(this.btn_Select);
            this.Controls.Add(this.panel1);
            this.Name = "SelectSong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectSong";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Playlist)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private RoundedButton btn_Select;
        private System.Windows.Forms.ComboBox cmb_Playlist;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dgv_Playlist;
        private RoundedButton btn_Addsong;
        private RoundedButton btn_CreatePlaylist;
    }
}