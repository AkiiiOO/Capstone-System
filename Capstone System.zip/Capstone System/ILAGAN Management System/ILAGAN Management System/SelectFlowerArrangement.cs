﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class SelectFlowerArrangement : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public int SelectedFlowerID { get; set; }
        public string SelectedFlowerName { get; set; }
        public decimal SelectedFlowerPrice { get; set; }

        public SelectFlowerArrangement()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadFlowerArrangement();
        }

        private void LoadFlowerArrangement()
        {
            try
            {
                db.Open();
                string query = "SELECT ArrangementID, ArrangementName, ArrangementTypeName, Price, ArrangementImage FROM FlowerArrangements " +
                           "JOIN FlowerArrangementsType ON FlowerArrangements.ArrangementTypeID = FlowerArrangementsType.ArrangementTypeID";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataAdapter dt = new SqlDataAdapter(command);

                DataTable FlowerTable = new DataTable();
                dt.Fill(FlowerTable);
                dgv_FlowerRecords.DataSource = FlowerTable;

                // Rename the columns
                dgv_FlowerRecords.Columns["ArrangementName"].HeaderText = "Flower Arrangement";
                dgv_FlowerRecords.Columns["ArrangementTypeName"].HeaderText = "Flower Arrangement Type";
                dgv_FlowerRecords.Columns["Price"].HeaderText = "Price";
                dgv_FlowerRecords.Columns["ArrangementImage"].HeaderText = "Image";

                dgv_FlowerRecords.Columns["ArrangementID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading caskets: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadFlowerArrangement();
                return;
            }
            string query = @"SELECT ArrangementID, ArrangementName, ArrangementTypeName, Price, ArrangementImage 
                             FROM FlowerArrangements 
                             JOIN FlowerArrangementsType ON FlowerArrangements.ArrangementTypeID = FlowerArrangementsType.ArrangementTypeID 
                             WHERE ArrangementName LIKE @SearchText OR ArrangementTypeName LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_FlowerRecords.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_FlowerRecords.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void dgv_FlowerRecords_DoubleClick(object sender, EventArgs e)
        {
            if (dgv_FlowerRecords.SelectedRows.Count > 0)
            {
                // Get the selected casket's data
                DataRowView selectedRow = (DataRowView)dgv_FlowerRecords.SelectedRows[0].DataBoundItem;

                SelectedFlowerID = (int)selectedRow["ArrangementID"];
                SelectedFlowerName = selectedRow["ArrangementName"].ToString();
                SelectedFlowerPrice = (decimal)selectedRow["Price"];


                // Show the casket name in a label
                lbl_FlowerName.Text = SelectedFlowerName;
                lbl_FlowerPrice.Text = SelectedFlowerPrice.ToString("F2");

                if (selectedRow["ArrangementImage"] != DBNull.Value)
                {
                    byte[] image = (byte[])selectedRow["ArrangementImage"];
                    if (image.Length > 0)
                    {
                        using (MemoryStream ms = new MemoryStream(image))
                        {
                            picbox_FlowerImage.Image = Image.FromStream(ms);
                        }
                    }
                    else
                    {
                        picbox_FlowerImage.Image = null;
                    }
                }
                else
                {
                    picbox_FlowerImage.Image = null;
                }
            }
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (SelectedFlowerName != null)
            {
                this.DialogResult = DialogResult.OK;
                this.Close(); // Close the form
            }
            else
            {
                MessageBox.Show("Please select a casket.");
            }
        }
    }
}
