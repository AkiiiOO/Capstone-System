﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class SelectFlowerArrangement : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public List<Flower> SelectedFlowers { get; set; }

        public SelectFlowerArrangement()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadFlowerArrangement();
            SelectedFlowers = new List<Flower>();
        }

        private void LoadFlowerArrangement()
        {
            try
            {
                db.Open();
                string query = "SELECT ArrangementID, ArrangementName, ArrangementTypeName, Price, ArrangementImage FROM FlowerArrangements " +
                           "JOIN FlowerArrangementsType ON FlowerArrangements.ArrangementTypeID = FlowerArrangementsType.ArrangementTypeID";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataAdapter dt = new SqlDataAdapter(command);

                DataTable FlowerTable = new DataTable();
                dt.Fill(FlowerTable);
                dgv_FlowerRecords.DataSource = FlowerTable;

                // Rename the columns
                dgv_FlowerRecords.Columns["ArrangementID"].Visible = false;
                dgv_FlowerRecords.Columns["ArrangementName"].HeaderText = "Flower Arrangement";
                dgv_FlowerRecords.Columns["ArrangementName"].ReadOnly = true;
                dgv_FlowerRecords.Columns["ArrangementTypeName"].HeaderText = "Flower Arrangement Type";
                dgv_FlowerRecords.Columns["ArrangementTypeName"].ReadOnly = true;
                dgv_FlowerRecords.Columns["Price"].HeaderText = "Price";
                dgv_FlowerRecords.Columns["Price"].ReadOnly = true;
                dgv_FlowerRecords.Columns["ArrangementImage"].HeaderText = "Image";
                dgv_FlowerRecords.Columns["ArrangementImage"].ReadOnly = true;

                
                dgv_FlowerRecords.Columns["SelectColumn"].Visible = true;
                dgv_FlowerRecords.Columns["txt_Quantity"].Visible = true;
                dgv_FlowerRecords.Columns["txt_Additionals"].Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading caskets: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }
        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadFlowerArrangement();
                return;
            }
            string query = @"SELECT ArrangementID, ArrangementName, ArrangementTypeName, Price, ArrangementImage 
                             FROM FlowerArrangements 
                             JOIN FlowerArrangementsType ON FlowerArrangements.ArrangementTypeID = FlowerArrangementsType.ArrangementTypeID 
                             WHERE ArrangementName LIKE @SearchText OR ArrangementTypeName LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_FlowerRecords.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_FlowerRecords.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
                SelectedFlowers.Clear(); // Clear previous selections

            foreach (DataGridViewRow row in dgv_FlowerRecords.Rows)
            {
                if (Convert.ToBoolean(row.Cells["SelectColumn"].Value)) // Check if selected
                {
                    // Validate Quantity (must be entered and greater than 0)
                    if (row.Cells["txt_Quantity"].Value == null || string.IsNullOrEmpty(row.Cells["txt_Quantity"].Value.ToString()))
                    {
                        MessageBox.Show("Quantity is required for selected flowers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Stop processing if validation fails
                    }
                    int quantity;
                    if (!int.TryParse(row.Cells["txt_Quantity"].Value.ToString(), out  quantity) || quantity <= 0)
                    {
                        MessageBox.Show("Quantity must be a valid number greater than 0.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Stop processing if validation fails
                    }

                    // Optional: Get "Additional" text (no validation needed)
                    string additional = row.Cells["txt_Additionals"].Value != null ? row.Cells["txt_Additionals"].Value.ToString() : string.Empty;

                    // Add the selected flower to the list
                    int flowerID = Convert.ToInt32(row.Cells["ArrangementID"].Value);
                    string flowerName = row.Cells["ArrangementName"].Value.ToString();
                    decimal flowerPrice = Convert.ToDecimal(row.Cells["Price"].Value);

                    SelectedFlowers.Add(new Flower
                    {
                        FlowerID = flowerID,
                        FlowerName = flowerName,
                        FlowerPrice = flowerPrice,
                        Quantity = quantity,
                        Additional = additional
                    });
                }
            }

            if (SelectedFlowers.Count > 0)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Please select at least one flower.");
            }
        }
        public class Flower
        {
            public int FlowerID { get; set; }
            public string FlowerName { get; set; }
            public decimal FlowerPrice { get; set; }
            public int Quantity { get; set; }
            public string Additional { get; set; }
        }

    }
}
