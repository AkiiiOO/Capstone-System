﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class BrowseClient : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public int SelectedClientID { get; private set; }

        public BrowseClient(DataTable clients)
        {
            InitializeComponent();
            db = y.GetConnection();
            dgv_Client.DataSource = clients;
        }

        private void dgv_Client_DoubleClick(object sender, EventArgs e)
        {
            if (dgv_Client.SelectedRows.Count > 0)
            {
                SelectedClientID = Convert.ToInt32(dgv_Client.SelectedRows[0].Cells["ClientID"].Value);
                DialogResult = DialogResult.OK;
                Close();
            }
            else
            {
                MessageBox.Show("Please select a client.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            // If the search text is empty, load all clients
            if (string.IsNullOrEmpty(searchText))
            {
                MessageBox.Show("Empty Textbox.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string query = @"SELECT ClientID, FirstName, MiddleInitial, LastName, Address, Contact_No 
                     FROM Clients 
                     WHERE FirstName LIKE @SearchText 
                     OR MiddleInitial LIKE @SearchText 
                     OR LastName LIKE @SearchText
                     OR Address LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_Client.DataSource = dt; // Bind results to DataGridView
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_Client.DataSource = null; // Clear previous data
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
