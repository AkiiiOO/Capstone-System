﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class Payment : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public Payment()
        {
            InitializeComponent();
            db = y.GetConnection();
            customizeDesign();
            LoadPendingPayments(); 
        }

        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
            panelTransactionSubMenu.Visible = false;
            panelReportsSubMenu.Visible = false;
            panelSettingsSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
            if (panelTransactionSubMenu.Visible == true)
                panelTransactionSubMenu.Visible = false;
            if (panelReportsSubMenu.Visible == true)
                panelReportsSubMenu.Visible = false;
            if (panelSettingsSubMenu.Visible == true)
                panelSettingsSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        //Home Nav
        private void btn_Home_Click(object sender, EventArgs e)
        {
            Home form2 = new Home();
            form2.Show();
            this.Hide();
        }

        //UserSubMenu
        private void btn_User_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus
        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Permission_Click(object sender, EventArgs e)
        {
            Permission form1 = new Permission();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            ServiceRequest form3 = new ServiceRequest();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Package_Click(object sender, EventArgs e)
        {
            CreatePackage form2 = new CreatePackage();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }


        //TransactionSubMenu
        private void btn_Transaction_Click(object sender, EventArgs e)
        {
            showSubMenu(panelTransactionSubMenu);
        }
        //TheSubMenus
        private void btn_Payment_Click(object sender, EventArgs e)
        {
            Payment form3 = new Payment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //ReportsSubMenus
        private void btn_Reports_Click(object sender, EventArgs e)
        {
            showSubMenu(panelReportsSubMenu);
        }
        private void btn_ServiceHistory_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_AccountReceivable_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_EquipmentReleaseLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Inventory_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_Sales_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }
        private void btn_EquipmentNarrative_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //SettingsSubMenus
        private void btn_Settings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSettingsSubMenu);
        }
        private void btn_AccountDetails_Click(object sender, EventArgs e)
        {
            AccountDetails form3 = new AccountDetails();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (respond == DialogResult.Yes)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }

        private void LoadPendingPayments()
        {
            try
            {
                db.Open();
                string query = @"SELECT sr.ServiceRequestID, sr.DiscountID, sr.ClientID, sr.ClientName,sr.DeceasedFName, sr.DeceasedLName, sr.DeceasedMInitial, sr.PackageName,
                                        ss.StatusName AS ServiceStatusName, sr.TotalPrice, sr.Discount, sr.DiscountRate, sr.DiscountTotal
                                 FROM ServiceRequests sr
                                 JOIN ServiceStatus ss ON sr.ServiceStatusID = ss.ServiceStatusID
                                 LEFT JOIN Discounts d ON sr.DiscountID = d.DiscountID
                                 WHERE sr.ServiceStatusID = (SELECT ServiceStatusID FROM ServiceStatus WHERE StatusName = 'Pending')";

                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                dataTable.Columns["ClientName"].ColumnName = "Client";
                dataTable.Columns["DeceasedFName"].ColumnName = "Deceased First Name";
                dataTable.Columns["DeceasedLName"].ColumnName = "Deceased Last Name";
                dataTable.Columns["DeceasedMInitial"].ColumnName = "Deceased Middle Initial";
                dataTable.Columns["PackageName"].ColumnName = "Package";
                dataTable.Columns["ServiceStatusName"].ColumnName = "Service Status";
                dataTable.Columns["TotalPrice"].ColumnName = "Total Price";
                dataTable.Columns["Discount"].ColumnName = "Discount";
                dataTable.Columns["DiscountRate"].ColumnName = "Discount Rate";
                dataTable.Columns["DiscountTotal"].ColumnName = "Discount Total";

                dgv_PendingPaymentRecords.Columns["SelectColumn"].Visible = true;

                dgv_PendingPaymentRecords.DataSource = dataTable;
                dgv_PendingPaymentRecords.Columns["DiscountID"].Visible = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading pending payments: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void btn__ProceedPayment_Click(object sender, EventArgs e)
        {
            var selectedRows = dgv_PendingPaymentRecords.Rows.Cast<DataGridViewRow>().Where(row => Convert.ToBoolean(row.Cells["SelectColumn"].Value) == true).ToList();

            if (selectedRows.Count == 0)
            {
                MessageBox.Show("Please select at least one service request.");
                return;
            }

            var clients = selectedRows.Select(row => row.Cells["ClientID"].Value.ToString()).Distinct().ToList();
            if (clients.Count > 1)
            {
                MessageBox.Show("Please select service requests for the same client only.");
                return;
            }
            ProceedPaymentForm proceedPayForm = new ProceedPaymentForm(selectedRows);
            proceedPayForm.PaymentAdded += loaddatagrid;
            proceedPayForm.ShowDialog();
        }
        private void loaddatagrid(object sender, EventArgs e)
        {
            LoadPendingPayments();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtsearch.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadPendingPayments();
                return;
            }

            string query = @"SELECT sr.ServiceRequestID, sr.DiscountID, sr.ClientID, sr.ClientName, 
                            sr.DeceasedFName, sr.DeceasedLName, sr.DeceasedMInitial, sr.PackageName,
                            ss.StatusName AS ServiceStatusName, sr.TotalPrice, sr.Discount, sr.DiscountRate
                     FROM ServiceRequests sr
                     JOIN ServiceStatus ss ON sr.ServiceStatusID = ss.ServiceStatusID
                     LEFT JOIN Discounts d ON sr.DiscountID = d.DiscountID
                     WHERE sr.ServiceStatusID = (SELECT ServiceStatusID FROM ServiceStatus WHERE StatusName = 'Pending')
                     AND (sr.ClientName LIKE @SearchText OR 
                          sr.DeceasedFName LIKE @SearchText OR 
                          sr.DeceasedLName LIKE @SearchText OR
                          sr.ServiceRequestID LIKE @SearchText)";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dataTable = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    dgv_PendingPaymentRecords.DataSource = dataTable;
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_PendingPaymentRecords.DataSource = null; // Clear the DataGridView if no records found
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
}
