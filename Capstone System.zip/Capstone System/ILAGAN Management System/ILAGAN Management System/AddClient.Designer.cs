﻿namespace ILAGAN_Management_System
{
    partial class AddClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddClient));
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgv_UsersRecords = new System.Windows.Forms.DataGridView();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.panel_username = new System.Windows.Forms.Panel();
            this.lbl_User = new System.Windows.Forms.Label();
            this.SystemNamelbl = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelServiceSubMenu = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panelUserSubmenu = new System.Windows.Forms.Panel();
            this.btn_EditUser = new ILAGAN_Management_System.RoundedButton();
            this.btnNewUser = new ILAGAN_Management_System.RoundedButton();
            this.btnLogout = new ILAGAN_Management_System.RoundedButton();
            this.btn_AddClient = new ILAGAN_Management_System.RoundedButton();
            this.btn_Service = new ILAGAN_Management_System.RoundedButton();
            this.btn_UserLog = new ILAGAN_Management_System.RoundedButton();
            this.btn_AddUser = new ILAGAN_Management_System.RoundedButton();
            this.btn_User = new ILAGAN_Management_System.RoundedButton();
            this.btn_Home = new ILAGAN_Management_System.RoundedButton();
            this.btn_ServiceRequest = new ILAGAN_Management_System.RoundedButton();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_UsersRecords)).BeginInit();
            this.panel_username.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panelServiceSubMenu.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelUserSubmenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Controls.Add(this.dgv_UsersRecords);
            this.panel3.Controls.Add(this.txtusername);
            this.panel3.Controls.Add(this.btn_EditUser);
            this.panel3.Controls.Add(this.btnNewUser);
            this.panel3.Location = new System.Drawing.Point(210, 99);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(776, 571);
            this.panel3.TabIndex = 5;
            // 
            // dgv_UsersRecords
            // 
            this.dgv_UsersRecords.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv_UsersRecords.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_UsersRecords.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgv_UsersRecords.BackgroundColor = System.Drawing.Color.LightGreen;
            this.dgv_UsersRecords.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgv_UsersRecords.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgv_UsersRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_UsersRecords.Location = new System.Drawing.Point(0, 80);
            this.dgv_UsersRecords.Name = "dgv_UsersRecords";
            this.dgv_UsersRecords.Size = new System.Drawing.Size(775, 486);
            this.dgv_UsersRecords.TabIndex = 14;
            // 
            // txtusername
            // 
            this.txtusername.AccessibleName = "";
            this.txtusername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.Location = new System.Drawing.Point(7, 45);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(172, 24);
            this.txtusername.TabIndex = 12;
            this.txtusername.Tag = "";
            // 
            // panel_username
            // 
            this.panel_username.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.panel_username.BackColor = System.Drawing.Color.White;
            this.panel_username.Controls.Add(this.lbl_User);
            this.panel_username.Location = new System.Drawing.Point(750, 40);
            this.panel_username.Name = "panel_username";
            this.panel_username.Size = new System.Drawing.Size(0, 0);
            this.panel_username.TabIndex = 11;
            // 
            // lbl_User
            // 
            this.lbl_User.AutoSize = true;
            this.lbl_User.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_User.Location = new System.Drawing.Point(6, 6);
            this.lbl_User.Name = "lbl_User";
            this.lbl_User.Size = new System.Drawing.Size(41, 18);
            this.lbl_User.TabIndex = 9;
            this.lbl_User.Text = "User";
            // 
            // SystemNamelbl
            // 
            this.SystemNamelbl.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SystemNamelbl.ForeColor = System.Drawing.Color.Black;
            this.SystemNamelbl.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.SystemNamelbl.Location = new System.Drawing.Point(111, 30);
            this.SystemNamelbl.Name = "SystemNamelbl";
            this.SystemNamelbl.Size = new System.Drawing.Size(209, 47);
            this.SystemNamelbl.TabIndex = 4;
            this.SystemNamelbl.Text = "Ilagan Funera Home Management System";
            this.SystemNamelbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(38, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 67);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(210)))), ((int)(((byte)(179)))));
            this.panel1.Controls.Add(this.panel_username);
            this.panel1.Controls.Add(this.btnLogout);
            this.panel1.Controls.Add(this.SystemNamelbl);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.panel1.Size = new System.Drawing.Size(984, 100);
            this.panel1.TabIndex = 6;
            // 
            // panelServiceSubMenu
            // 
            this.panelServiceSubMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelServiceSubMenu.Controls.Add(this.btn_ServiceRequest);
            this.panelServiceSubMenu.Controls.Add(this.btn_AddClient);
            this.panelServiceSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelServiceSubMenu.ForeColor = System.Drawing.Color.Gray;
            this.panelServiceSubMenu.Location = new System.Drawing.Point(0, 296);
            this.panelServiceSubMenu.Name = "panelServiceSubMenu";
            this.panelServiceSubMenu.Size = new System.Drawing.Size(215, 71);
            this.panelServiceSubMenu.TabIndex = 17;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.ForeColor = System.Drawing.Color.Gray;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(215, 117);
            this.panel5.TabIndex = 13;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.panel2.AutoScroll = true;
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(149)))), ((int)(((byte)(210)))), ((int)(((byte)(159)))));
            this.panel2.Controls.Add(this.panelServiceSubMenu);
            this.panel2.Controls.Add(this.btn_Service);
            this.panel2.Controls.Add(this.panelUserSubmenu);
            this.panel2.Controls.Add(this.btn_User);
            this.panel2.Controls.Add(this.btn_Home);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Location = new System.Drawing.Point(-5, -5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(215, 673);
            this.panel2.TabIndex = 7;
            // 
            // panelUserSubmenu
            // 
            this.panelUserSubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(211)))));
            this.panelUserSubmenu.Controls.Add(this.btn_UserLog);
            this.panelUserSubmenu.Controls.Add(this.btn_AddUser);
            this.panelUserSubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUserSubmenu.ForeColor = System.Drawing.Color.Gray;
            this.panelUserSubmenu.Location = new System.Drawing.Point(0, 187);
            this.panelUserSubmenu.Name = "panelUserSubmenu";
            this.panelUserSubmenu.Size = new System.Drawing.Size(215, 74);
            this.panelUserSubmenu.TabIndex = 12;
            // 
            // btn_EditUser
            // 
            this.btn_EditUser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_EditUser.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_EditUser.BackgroundColor = System.Drawing.Color.RoyalBlue;
            this.btn_EditUser.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_EditUser.BorderRadius = 5;
            this.btn_EditUser.BorderSize = 0;
            this.btn_EditUser.FlatAppearance.BorderSize = 0;
            this.btn_EditUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_EditUser.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_EditUser.ForeColor = System.Drawing.Color.White;
            this.btn_EditUser.Location = new System.Drawing.Point(707, 42);
            this.btn_EditUser.Name = "btn_EditUser";
            this.btn_EditUser.Size = new System.Drawing.Size(64, 31);
            this.btn_EditUser.TabIndex = 13;
            this.btn_EditUser.Text = "Edit";
            this.btn_EditUser.TextColor = System.Drawing.Color.White;
            this.btn_EditUser.UseVisualStyleBackColor = false;
            // 
            // btnNewUser
            // 
            this.btnNewUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnNewUser.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnNewUser.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnNewUser.BorderRadius = 5;
            this.btnNewUser.BorderSize = 0;
            this.btnNewUser.FlatAppearance.BorderSize = 0;
            this.btnNewUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewUser.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewUser.ForeColor = System.Drawing.Color.White;
            this.btnNewUser.Location = new System.Drawing.Point(7, 5);
            this.btnNewUser.Name = "btnNewUser";
            this.btnNewUser.Size = new System.Drawing.Size(103, 31);
            this.btnNewUser.TabIndex = 11;
            this.btnNewUser.Text = "+  New Client";
            this.btnNewUser.TextColor = System.Drawing.Color.White;
            this.btnNewUser.UseVisualStyleBackColor = false;
            this.btnNewUser.Click += new System.EventHandler(this.btnNewUser_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnLogout.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(173)))), ((int)(((byte)(155)))));
            this.btnLogout.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btnLogout.BorderRadius = 5;
            this.btnLogout.BorderSize = 0;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(877, 40);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(80, 30);
            this.btnLogout.TabIndex = 8;
            this.btnLogout.Text = "Log out";
            this.btnLogout.TextColor = System.Drawing.Color.White;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btn_AddClient
            // 
            this.btn_AddClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddClient.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddClient.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddClient.BorderRadius = 0;
            this.btn_AddClient.BorderSize = 0;
            this.btn_AddClient.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddClient.FlatAppearance.BorderSize = 0;
            this.btn_AddClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddClient.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddClient.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddClient.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_AddClient.Location = new System.Drawing.Point(0, 0);
            this.btn_AddClient.Name = "btn_AddClient";
            this.btn_AddClient.Padding = new System.Windows.Forms.Padding(0, 0, 35, 0);
            this.btn_AddClient.Size = new System.Drawing.Size(215, 35);
            this.btn_AddClient.TabIndex = 13;
            this.btn_AddClient.Text = "Add Client ";
            this.btn_AddClient.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddClient.UseVisualStyleBackColor = false;
            this.btn_AddClient.Click += new System.EventHandler(this.btn_AddClient_Click);
            // 
            // btn_Service
            // 
            this.btn_Service.BackColor = System.Drawing.Color.Transparent;
            this.btn_Service.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Service.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Service.BorderRadius = 0;
            this.btn_Service.BorderSize = 0;
            this.btn_Service.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Service.FlatAppearance.BorderSize = 0;
            this.btn_Service.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Service.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Service.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Service.Image = ((System.Drawing.Image)(resources.GetObject("btn_Service.Image")));
            this.btn_Service.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Service.Location = new System.Drawing.Point(0, 261);
            this.btn_Service.Name = "btn_Service";
            this.btn_Service.Size = new System.Drawing.Size(215, 35);
            this.btn_Service.TabIndex = 16;
            this.btn_Service.Text = "         Service                                     v";
            this.btn_Service.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Service.UseVisualStyleBackColor = false;
            this.btn_Service.Click += new System.EventHandler(this.btn_Service_Click);
            // 
            // btn_UserLog
            // 
            this.btn_UserLog.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_UserLog.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_UserLog.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_UserLog.BorderRadius = 0;
            this.btn_UserLog.BorderSize = 0;
            this.btn_UserLog.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_UserLog.FlatAppearance.BorderSize = 0;
            this.btn_UserLog.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_UserLog.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UserLog.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_UserLog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_UserLog.Location = new System.Drawing.Point(0, 40);
            this.btn_UserLog.Name = "btn_UserLog";
            this.btn_UserLog.Padding = new System.Windows.Forms.Padding(50, 0, 90, 0);
            this.btn_UserLog.Size = new System.Drawing.Size(215, 35);
            this.btn_UserLog.TabIndex = 13;
            this.btn_UserLog.Text = "User Log";
            this.btn_UserLog.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_UserLog.UseVisualStyleBackColor = false;
            this.btn_UserLog.Click += new System.EventHandler(this.btn_UserLog_Click);
            // 
            // btn_AddUser
            // 
            this.btn_AddUser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddUser.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_AddUser.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_AddUser.BorderRadius = 0;
            this.btn_AddUser.BorderSize = 0;
            this.btn_AddUser.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_AddUser.FlatAppearance.BorderSize = 0;
            this.btn_AddUser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_AddUser.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddUser.Location = new System.Drawing.Point(0, 0);
            this.btn_AddUser.Name = "btn_AddUser";
            this.btn_AddUser.Padding = new System.Windows.Forms.Padding(50, 0, 90, 0);
            this.btn_AddUser.Size = new System.Drawing.Size(215, 40);
            this.btn_AddUser.TabIndex = 12;
            this.btn_AddUser.Text = "Add User";
            this.btn_AddUser.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_AddUser.UseVisualStyleBackColor = false;
            this.btn_AddUser.Click += new System.EventHandler(this.btn_AddUser_Click);
            // 
            // btn_User
            // 
            this.btn_User.BackColor = System.Drawing.Color.Transparent;
            this.btn_User.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_User.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_User.BorderRadius = 0;
            this.btn_User.BorderSize = 0;
            this.btn_User.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_User.FlatAppearance.BorderSize = 0;
            this.btn_User.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_User.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_User.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_User.Image = ((System.Drawing.Image)(resources.GetObject("btn_User.Image")));
            this.btn_User.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_User.Location = new System.Drawing.Point(0, 152);
            this.btn_User.Name = "btn_User";
            this.btn_User.Size = new System.Drawing.Size(215, 35);
            this.btn_User.TabIndex = 11;
            this.btn_User.Text = "         User                                          v";
            this.btn_User.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_User.UseVisualStyleBackColor = false;
            this.btn_User.Click += new System.EventHandler(this.btn_User_Click_1);
            // 
            // btn_Home
            // 
            this.btn_Home.BackColor = System.Drawing.Color.Transparent;
            this.btn_Home.BackgroundColor = System.Drawing.Color.Transparent;
            this.btn_Home.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_Home.BorderRadius = 0;
            this.btn_Home.BorderSize = 0;
            this.btn_Home.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_Home.FlatAppearance.BorderSize = 0;
            this.btn_Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Home.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Home.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Home.Image = ((System.Drawing.Image)(resources.GetObject("btn_Home.Image")));
            this.btn_Home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Home.Location = new System.Drawing.Point(0, 117);
            this.btn_Home.Name = "btn_Home";
            this.btn_Home.Padding = new System.Windows.Forms.Padding(0, 0, 100, 0);
            this.btn_Home.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_Home.Size = new System.Drawing.Size(215, 35);
            this.btn_Home.TabIndex = 11;
            this.btn_Home.Text = "Home";
            this.btn_Home.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Home.UseVisualStyleBackColor = false;
            this.btn_Home.Click += new System.EventHandler(this.btn_Home_Click_1);
            // 
            // btn_ServiceRequest
            // 
            this.btn_ServiceRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceRequest.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(242)))), ((int)(((byte)(242)))));
            this.btn_ServiceRequest.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(211)))), ((int)(((byte)(234)))));
            this.btn_ServiceRequest.BorderRadius = 0;
            this.btn_ServiceRequest.BorderSize = 0;
            this.btn_ServiceRequest.Dock = System.Windows.Forms.DockStyle.Top;
            this.btn_ServiceRequest.FlatAppearance.BorderSize = 0;
            this.btn_ServiceRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ServiceRequest.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ServiceRequest.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceRequest.Location = new System.Drawing.Point(0, 35);
            this.btn_ServiceRequest.Name = "btn_ServiceRequest";
            this.btn_ServiceRequest.Size = new System.Drawing.Size(215, 35);
            this.btn_ServiceRequest.TabIndex = 14;
            this.btn_ServiceRequest.Text = "Service Request";
            this.btn_ServiceRequest.TextColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ServiceRequest.UseVisualStyleBackColor = false;
            // 
            // AddClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(984, 662);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "AddClient";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddClient";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_UsersRecords)).EndInit();
            this.panel_username.ResumeLayout(false);
            this.panel_username.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panelServiceSubMenu.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panelUserSubmenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private RoundedButton btn_EditUser;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dgv_UsersRecords;
        private System.Windows.Forms.TextBox txtusername;
        private RoundedButton btnNewUser;
        private RoundedButton btn_AddClient;
        private RoundedButton btn_Service;
        private RoundedButton btn_UserLog;
        private RoundedButton btn_User;
        private System.Windows.Forms.Panel panel_username;
        private System.Windows.Forms.Label lbl_User;
        private RoundedButton btn_AddUser;
        private RoundedButton btnLogout;
        private System.Windows.Forms.Label SystemNamelbl;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelServiceSubMenu;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelUserSubmenu;
        private RoundedButton btn_Home;
        private RoundedButton btn_ServiceRequest;
    }
}