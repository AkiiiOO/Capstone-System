﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ILAGAN_Management_System;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class CreateNewServiceRequestForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public event EventHandler ClientAdded;
        private int clientID;

        //for combo box document
        private List<DocumentType> documentTypes = new List<DocumentType>();
        //for combo box Cemetery
        private List<Cemetery> cemeteries = new List<Cemetery>();

        // resrvation id once inserted 
        private int reservationID;

        public CreateNewServiceRequestForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadServiceType();
            LoadCemeteries();
            LoadDocumentTypes();
        }
        private void LoadServiceType()
        {
            cmb_ServiceType.Items.Clear();
            string query = "SELECT ServiceTypeID, ServiceTypeName FROM ServiceType";
            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable servicetypeTable = new DataTable();
                adapter.Fill(servicetypeTable);

                cmb_ServiceType.DataSource = servicetypeTable;
                cmb_ServiceType.DisplayMember = "ServiceTypeName";
                cmb_ServiceType.ValueMember = "ServiceTypeID";

                cmb_ServiceType.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Service type: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void btn_Reservation_Click(object sender, EventArgs e)
        {
            if (cmb_ServiceType.SelectedValue == null)
            {
                MessageBox.Show("Please select a service type.", "Service Type Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (clientID == 0)
            {
                MessageBox.Show("Please enter client details first.", "Client Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            int serviceTypeId = (int)cmb_ServiceType.SelectedValue;
            string selectedServiceType = cmb_ServiceType.Text;

            if (selectedServiceType == "Chapel Service")
            {
                OpenChapelSelectionForm(serviceTypeId, selectedServiceType);
            }
            else if (selectedServiceType == "Home Service")
            {
                OpenHomeLocationForm(serviceTypeId, selectedServiceType);
            }
            else
            {
                MessageBox.Show("Invalid service type selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void OpenChapelSelectionForm(int serviceTypeId, string selectedServiceType)
        {
            string clientName = ConstructClientName();

            if (string.IsNullOrEmpty(clientName))
            {
                MessageBox.Show("First name and last name cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Chapel_Service chapelServiceForm = new Chapel_Service(clientID, clientName, reservationID)
            {
            ServiceTypeId = serviceTypeId,
            SelectedServiceType = selectedServiceType 
            };
            chapelServiceForm.ShowDialog();

            if (chapelServiceForm.DialogResult == DialogResult.OK)
            {
                reservationID = chapelServiceForm.ReservationID;

                MessageBox.Show("Chapel reservation created successfully. Reservation ID: " + reservationID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void OpenHomeLocationForm(int serviceTypeId, string selectedServiceType)
        {
            string clientName = ConstructClientName();

            if (string.IsNullOrEmpty(clientName))
            {
                MessageBox.Show("First name and last name cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Home_Service homeServiceForm = new Home_Service(clientID, clientName)
            {
                ServiceTypeId = serviceTypeId,
                SelectedServiceType = selectedServiceType
            };
            homeServiceForm.ShowDialog();
            if (homeServiceForm.DialogResult == DialogResult.OK)
            {
                reservationID = homeServiceForm.ReservationID;

                MessageBox.Show("Home reservation created successfully. Reservation ID: " + reservationID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        // if client dont have a middle name
        private string ConstructClientName()
        {
            string firstName = txtFName.Text.Trim();
            string lastName = txtLName.Text.Trim();
            string middleInitial = txt_MiddleInitial.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
                return null;

            if (string.IsNullOrEmpty(middleInitial))
                return firstName + " " + lastName;

            return firstName + " " + middleInitial + ". " + lastName;
        }
        private void btn_Browse_Click(object sender, EventArgs e)
        {
            clientID = CheckIfClientExists();
        }
        private void AddNewClientForm_ClientAdded(object sender, EventArgs e)
        {
            MessageBox.Show("A new client was added.");
        }
        private int CheckIfClientExists()
        {
            string firstName = txtFName.Text.Trim();
            string middleInitial = txt_MiddleInitial.Text.Trim();
            string lastName = txtLName.Text.Trim();
            string address = txt_Address.Text;

            // Validate input
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
            {
                MessageBox.Show("Please enter both the first and last names.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 0;
            }

            string query = @"SELECT ClientID, Address FROM Clients
                             WHERE FirstName = @FirstName 
                             AND MiddleInitial = @MiddleInitial 
                             AND LastName = @LastName";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@MiddleInitial", middleInitial);
                command.Parameters.AddWithValue("@LastName", lastName);

                try
                {
                    db.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            txt_Address.Text = reader["Address"].ToString();
                            MessageBox.Show("This client has already availed a service.");
                            return (int)reader["ClientID"];
                        }
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("Client not found. Would you like to add a new client?", "Client Not Found", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            AddNewClientForm addNewClientForm = new AddNewClientForm();
                            addNewClientForm.ClientAdded += AddNewClientForm_ClientAdded; 
                            addNewClientForm.SetClientDetails(firstName, middleInitial, lastName, address);
                            addNewClientForm.ShowDialog();
                        }
                    }
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                    {
                        db.Close();
                    }
                }
            }
            return 0;
        }
        //for combobox ducument
        private void LoadDocumentTypes()
        {
            cmb_DocumentType.Items.Clear();
            string query = "SELECT DocumentTypeID, DocumentTypeName FROM DocumentType"; // Include ID in the query
            using (SqlCommand doc_command = new SqlCommand(query, db))
            {
                db.Open();
                using (SqlDataReader doc_reader = doc_command.ExecuteReader())
                {
                    while (doc_reader.Read())
                    {
                        var docType = new DocumentType
                        {
                            ID = (int)doc_reader["DocumentTypeID"],
                            Name = doc_reader["DocumentTypeName"].ToString()
                        };
                        documentTypes.Add(docType);
                        cmb_DocumentType.Items.Add(docType); // Add to ComboBox
                    }
                }
                db.Close();
            }
        }
        //uploading pic for document
        private void btn_Upload_Click(object sender, EventArgs e)
        {
            if (cmb_DocumentType.SelectedItem == null)
            {
                MessageBox.Show("Please select a document type before uploading an image.", "Document Type Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_documents.Image = Image.FromFile(filePath);
            }
        }
        //view the document
        private void btn_View_Click(object sender, EventArgs e)
        {
            if (picb_documents.Image != null)
            {
                ImageViewerForm viewer = new ImageViewerForm(picb_documents.Image);
                viewer.ShowDialog();
            }
            else
            {
                MessageBox.Show("No document image available to view.", "Image Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //for combo box cemetery
        private void LoadCemeteries()
        {
            cmb_CemeteryLocation.Items.Clear();
            string queryc = "SELECT CemeteryID, CemeteryName FROM Cemeteries";
            using (SqlCommand command = new SqlCommand(queryc, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var cemetery = new Cemetery
                            {
                                ID = (int)reader["CemeteryID"],
                                Name = reader["CemeteryName"].ToString()
                            };
                            cemeteries.Add(cemetery);
                            cmb_CemeteryLocation.Items.Add(cemetery);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading cemeteries: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }
        }
        // btn Add 
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_DFname.Text) || string.IsNullOrEmpty(txt_DLname.Text))
            {
                MessageBox.Show("Please enter the deceased's first name and last name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtp_burialdate.Value < DateTime.Today)
            {
                MessageBox.Show("Burial date cannot be in the past.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtp_burialtime.Value < DateTime.Today)
            {
                MessageBox.Show("Burial time cannot be in the past.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("Do you want to create this service request?",
                                          "Confirm Creation",
                                          MessageBoxButtons.YesNo,
                                          MessageBoxIcon.Question);

            // If the user clicks Yes, proceed to add the service request
            if (result == DialogResult.Yes)
            {
                AddServiceRequest();
            }

        }
        // to add service request databse 
        private void AddServiceRequest()
        {
            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            int clientID = CheckIfClientExists();
            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string clientName = ConstructClientName();
            //document combo box
            int selectedDocumentTypeID = ((DocumentType)cmb_DocumentType.SelectedItem).ID;
            string selectedDocumentTypeName = ((DocumentType)cmb_DocumentType.SelectedItem).Name;
            //cemetery cobobox
            int selectedCemeteryID = ((Cemetery)cmb_CemeteryLocation.SelectedItem).ID;
            string selectedCemeteryName = ((Cemetery)cmb_CemeteryLocation.SelectedItem).Name;

            int serviceTypeId = (int)cmb_ServiceType.SelectedValue;
            string serviceTypeName = cmb_ServiceType.Text;

            string query = @"INSERT INTO ServiceRequests (UserID, ClientID, ServiceStatusID, DocumentTypeID, CemeteryID, ServiceTypeID, 
                                                                ReservationID, CopPackageID, CopCasketID, CopVehicleID, CopArrangementID, 
                                                                CopSongID, CopLightID, ServiceType, ClientName, DeceasedFName, DeceasedLName, 
                                                                DeceasedMInitial, CasketName, VehicleName, FlowerArrangementName, PlaylistName, 
                                                                ChapelName, ServiceLightsName, PackageName, CemeteryLocation, DateBurial, 
                                                                TimeBurial, Address, DocumentType, DocumentImage, EmbalmingDays, TotalPrice, 
                                                                CreationDate, CreatedBy) 
                                                                VALUES 
                                                                (@UserID, @ClientID, @ServiceStatusID, @DocumentTypeID, @CemeteryID, @ServiceTypeID, 
                                                                @ReservationID, @CopPackageID, @CopCasketID, @CopVehicleID, @CopArrangementID, 
                                                                @CopSongID, @CopLightID, @ServiceType, @ClientName, @DeceasedFName, @DeceasedLName, 
                                                                @DeceasedMInitial, @CasketName, @VehicleName, @FlowerArrangementName, @PlaylistName, 
                                                                @ChapelName, @ServiceLightsName, @PackageName, @CemeteryLocation, @DateBurial, 
                                                                @TimeBurial, @Address, @DocumentType, @DocumentImage, @EmbalmingDays, @TotalPrice, 
                                                                GETDATE(), @CreatedBy);";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@UserID", currentUserId);
                command.Parameters.AddWithValue("@ClientID", clientID);
                command.Parameters.AddWithValue("@ServiceStatusID", 1);
                command.Parameters.AddWithValue("@ServiceTypeID", serviceTypeId); 
                command.Parameters.AddWithValue("@CemeteryID", selectedCemeteryID);
                command.Parameters.AddWithValue("@DocumentTypeID", selectedDocumentTypeID);
                command.Parameters.AddWithValue("@ReservationID", reservationID);

                // Packages
                command.Parameters.AddWithValue("@CopPackageID", 0); // ID of the package
                command.Parameters.AddWithValue("@CopCasketID", 0); // ID of the casket
                command.Parameters.AddWithValue("@CopVehicleID", 0); // ID of the vehicle
                command.Parameters.AddWithValue("@CopArrangementID", 0); // ID of the flower arrangement
                command.Parameters.AddWithValue("@CopSongID", 0); // ID of the song
                command.Parameters.AddWithValue("@CopLightID", 0);

                //Service type
                command.Parameters.AddWithValue("@ServiceType", serviceTypeName);

                // Client and deceased information
                command.Parameters.AddWithValue("@ClientName", clientName);
                command.Parameters.AddWithValue("@DeceasedFName", txt_DFname.Text);
                command.Parameters.AddWithValue("@DeceasedLName", txt_DLname.Text);
                if (string.IsNullOrEmpty(txt_DMname.Text))
                {
                    command.Parameters.AddWithValue("@DeceasedMInitial", DBNull.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@DeceasedMInitial", txt_DMname.Text);
                }

                // Package information
                command.Parameters.AddWithValue("@PackageName", 0); // Name of the package
                command.Parameters.AddWithValue("@CasketName", 0); // Name of the casket
                command.Parameters.AddWithValue("@VehicleName", 0); // Name of the vehicle
                command.Parameters.AddWithValue("@FlowerArrangementName", 0); // Name of the flower arrangement
                command.Parameters.AddWithValue("@PlaylistName", 0); // Name of the song
                command.Parameters.AddWithValue("@ServiceLightsName", 0); // Name of the service lights

                // Burial and service details
                command.Parameters.AddWithValue("@CemeteryLocation", selectedCemeteryName); // Location of the cemetery
                if (dtp_burialdate.Value != DateTime.MinValue)
                {
                    command.Parameters.AddWithValue("@DateBurial", dtp_burialdate.Value);
                }
                else
                {
                    command.Parameters.AddWithValue("@DateBurial", DBNull.Value);
                }
                if (dtp_burialtime.Value != DateTime.MinValue)
                {
                    command.Parameters.AddWithValue("@TimeBurial", dtp_burialtime.Value.TimeOfDay);
                }
                else
                {
                    command.Parameters.AddWithValue("@TimeBurial", DBNull.Value);
                }
                command.Parameters.AddWithValue("@Address", txt_Address.Text);

                // Document details
                command.Parameters.AddWithValue("@DocumentType", selectedDocumentTypeName);
                if (picb_documents.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_documents.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        command.Parameters.AddWithValue("@DocumentImage", ms.ToArray());
                    }
                }

                // Service specifics
                command.Parameters.AddWithValue("@EmbalmingDays", 0);// Number of days for embalming
                command.Parameters.AddWithValue("@TotalPrice", lbl_Price.Text);
                command.Parameters.AddWithValue("@CreatedBy", createdBy);

                try
                {
                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Service request added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding service request: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }




        private void btn_CustomizePackage_Click(object sender, EventArgs e)
        {

        }

        //d pa nagamit 
        private void DeleteCustomize()
        {
            string deleteQuery = "DELETE FROM CustomizePackage";
            using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, db))
            {
                db.Open();
                deleteCommand.ExecuteNonQuery();
                db.Close();
            }
        }
    }
    
    public class Cemetery
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name; 
        }
    }

    public class DocumentType
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
