﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CreateNewServiceRequestForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public CreateNewServiceRequestForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadClientRecords();
        }

        private void LoadClientRecords()
        {
            db.Open();
            // Display UsersTable
            string query = @"SELECT c.ClientID, c.FirstName, c.MiddleInitial, c.LastName, 
                             c.Address, c.Contact_No, c.CreatedBy
                             FROM Clients c";

            SqlCommand command = new SqlCommand(query, db);
            SqlDataAdapter dt = new SqlDataAdapter(command);
            DataTable ClientsTable = new DataTable();
            dt.Fill(ClientsTable);
            dgv_ClientsRecords.DataSource = ClientsTable;
            db.Close();
        }
    }
}
