﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ILAGAN_Management_System;
using System.IO;


namespace ILAGAN_Management_System
{
    public partial class CreateNewServiceRequestForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        private List<DocumentType> documentTypes = new List<DocumentType>();
        private Timer typingTimer; 
        private const int TypingDelay = 2000;
        private int PackageID;

        public string SelectedFirstName { get; set; }
        public string SelectedMiddleInitial { get; set; }
        public string SelectedLastName { get; set; }
        public string SelectedAddress { get; set; }

        public int SelectedCasketID { get; set; }
        public int SelectedVehicleID { get; set; }
        public int SelectedFlowerID { get; set; }
        public int SelectedSongID { get; set; }
        public decimal TotalPrice { get; set; }

        public int SelectedPackageID { get; set; }

        public int SelectedIDPackage { get; set; }
        public int SelectedLightID { get; set; }
        public int SelectedIDCasket { get; set; }
        public int SelectedIDVehicle { get; set; }
        public int SelectedIDFlower { get; set; }
        public int SelectedIDSong { get; set; }
        public string SelectedPackageName { get; set; }
        public string SelectedCasketName { get; set; }
        public string SelectedVehicleName { get; set; }
        public string SelectedFlowerArrangementName { get; set; }
        public string SelectedSongName { get; set; }
        public string SelectedChapelName { get; set; }
        public string SelectedLightName { get; set; }
        public string SelectedEmbalmingDays { get; set; }

        public CreateNewServiceRequestForm()
        {
            InitializeComponent();
            db = y.GetConnection();

            typingTimer = new Timer();
            typingTimer.Interval = TypingDelay;
            typingTimer.Tick += TypingTimer_Tick;

            txtFName.TextChanged += OnTextChanged;
            txt_MiddleInitial.TextChanged += OnTextChanged;
            txtLName.TextChanged += OnTextChanged;
        }

        private void btn_CustomizePackage_Click(object sender, EventArgs e)
        {
            if (cmb_Package.SelectedItem != null)
            {
                string selectedPackageName = cmb_Package.SelectedItem.ToString();


                if (CheckCustomizations())
                {
                    if (!SameSelectedPackage(selectedPackageName))
                    {
                        DialogResult result = MessageBox.Show("There are existing customizations. Selecting another package will delete these customizations. Do you want to continue?",
                                                              "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                        if (result == DialogResult.Yes)
                        {
                            DeleteCustomizations();
                        }
                        else
                        {
                            return;
                        }
                    }
                    else
                    {
                        DialogResult result = MessageBox.Show("This package has already been customized. Would you like to re-customize it?",
                                                              "Package Already Customized", 
                                                              MessageBoxButtons.YesNo, MessageBoxIcon.Information);

                        if (result == DialogResult.No)
                        {
                            return; // User does not want to re-customize
                        }
                    }
                }

                CustomizePackage customizePackageForm = new CustomizePackage
                {
                    SelectedPackageName = selectedPackageName,
                    SelectedPackageID = PackageID 
                };

                if (customizePackageForm.ShowDialog() == DialogResult.OK)
                {
                    MessageBox.Show("Package customized successfully!");
                    LoadCustomizedPackageDetails();
                }
            }
            else
            {
                MessageBox.Show("Please select a package to customize.");
            }

        }

        private bool CheckCustomizations()
        {
            string checkQuery = "SELECT COUNT(*) FROM CustomizePackage";
            SqlCommand checkCommand = new SqlCommand(checkQuery, db);

            db.Open();
            int count = (int)checkCommand.ExecuteScalar();
            db.Close();

            return count > 0;
        }

        private void DeleteCustomizations()
        {
            string deleteQuery = "DELETE FROM CustomizePackage ";
            SqlCommand deleteCommand = new SqlCommand(deleteQuery, db);

            db.Open();
            deleteCommand.ExecuteNonQuery();
            db.Close();

            MessageBox.Show("Existing customizations have been deleted.");
        }

        private bool SameSelectedPackage(string selectedPackageName)
        {
            string query = @"SELECT COUNT(*)FROM CustomizePackage cp
                             JOIN Package p ON cp.PackageID = p.PackageID
                             WHERE cp.PackageID = @PackageID 
                             AND p.PackageName = @PackageName";
            SqlCommand command = new SqlCommand(query, db);
            command.Parameters.AddWithValue("@PackageID", PackageID);
            command.Parameters.AddWithValue("@PackageName", selectedPackageName);

            db.Open();
            int count = (int)command.ExecuteScalar();
            db.Close();

            return count > 0;
        }


        private void LoadCustomizedPackageDetails()
        {
            string query = @"SELECT cp.CustomizePackageID, cp.PackageID, cp.CasketID, cp.VehicleID, cp.ArrangementID, cp.SongID, p.PackageName, cp.CasketName, cp.VehicleName, 
                                    f.ArrangementName, s.SongName, cp.ChapelName, sl.LightDescription, 
                                    cp.TotalPrice, sl.LightID, cp.EmbalmingDays
                                     FROM CustomizePackage cp
                                     JOIN Package p ON cp.PackageID = p.PackageID
                                     JOIN FlowerArrangements f ON cp.ArrangementID = f.ArrangementID
                                     JOIN Song s ON cp.SongID = s.SongID
                                     JOIN ServiceLights sl ON cp.LightID = sl.LightID
                                     WHERE cp.PackageID = @PackageID";

            SqlCommand command = new SqlCommand(query, db);

            command.Parameters.AddWithValue("@PackageID", PackageID);

                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataTable customPackageDetailsTable = new DataTable();
                adapter.Fill(customPackageDetailsTable);

                if (customPackageDetailsTable.Rows.Count > 0)
                {
                    dgv_PackageDetails.DataSource = customPackageDetailsTable;

                    dgv_PackageDetails.Columns["CustomizePackageID"].Visible = false;
                    dgv_PackageDetails.Columns["LightID"].Visible = false;
                    //dgv_PackageDetails.Columns["PackageID"].Visible = false;

                    //Order being display 
                    dgv_PackageDetails.Columns["PackageName"].DisplayIndex = 0;
                    dgv_PackageDetails.Columns["CasketName"].DisplayIndex = 1;
                    dgv_PackageDetails.Columns["VehicleName"].DisplayIndex = 2;
                    dgv_PackageDetails.Columns["ArrangementName"].DisplayIndex = 3;
                    dgv_PackageDetails.Columns["SongName"].DisplayIndex = 4;
                    dgv_PackageDetails.Columns["ChapelName"].DisplayIndex = 5;
                    dgv_PackageDetails.Columns["LightDescription"].DisplayIndex = 6;
                    dgv_PackageDetails.Columns["EmbalmingDays"].DisplayIndex = 7; 
                    dgv_PackageDetails.Columns["TotalPrice"].DisplayIndex = 8;

                    SelectedPackageName = customPackageDetailsTable.Rows[0]["PackageName"].ToString();
                    SelectedCasketName = customPackageDetailsTable.Rows[0]["CasketName"].ToString();
                    SelectedVehicleName = customPackageDetailsTable.Rows[0]["VehicleName"].ToString();
                    SelectedFlowerArrangementName = customPackageDetailsTable.Rows[0]["ArrangementName"].ToString();
                    SelectedSongName = customPackageDetailsTable.Rows[0]["SongName"].ToString();
                    SelectedChapelName = customPackageDetailsTable.Rows[0]["ChapelName"].ToString();
                    SelectedLightName = customPackageDetailsTable.Rows[0]["LightDescription"].ToString();
                    SelectedEmbalmingDays = customPackageDetailsTable.Rows[0]["EmbalmingDays"].ToString();

                    txt_Price.Text = customPackageDetailsTable.Rows[0]["TotalPrice"].ToString();

                    SelectedIDPackage = (int)customPackageDetailsTable.Rows[0]["PackageID"];
                    SelectedLightID = (int)customPackageDetailsTable.Rows[0]["LightID"];
                    SelectedIDCasket = (int)customPackageDetailsTable.Rows[0]["CasketID"];
                    SelectedIDVehicle = (int)customPackageDetailsTable.Rows[0]["VehicleID"];
                    SelectedIDFlower = (int)customPackageDetailsTable.Rows[0]["ArrangementID"];
                    SelectedIDSong = (int)customPackageDetailsTable.Rows[0]["SongID"];
                }
                else
                {
                    MessageBox.Show("No custom package details found.");
                }

                db.Close();
        }

        private void dgv_ClientsRecords_Click(object sender, EventArgs e)
        {
            if (dgv_PackageDetails.SelectedRows.Count > 0)
            {
                DataRowView selectedRow = (DataRowView)dgv_PackageDetails.SelectedRows[0].DataBoundItem;

                SelectedFirstName = selectedRow["FirstName"].ToString();
                SelectedMiddleInitial = selectedRow["MiddleInitial"].ToString();
                SelectedLastName = selectedRow["LastName"].ToString();
                SelectedAddress = selectedRow["Address"].ToString();

                txtFName.Text = SelectedFirstName;
                txt_MiddleInitial.Text = SelectedMiddleInitial;
                txtLName.Text = SelectedLastName;
                txtAddress.Text = SelectedAddress;
            }
        }

        private void CreateNewServiceRequestForm_Load(object sender, EventArgs e)
        {
            LoadPackage();
            LoadDocumentTypes();
        }

        private void LoadDocumentTypes()
        {
            cmb_DocumentType.Items.Clear();
            string query = "SELECT DocumentTypeID, DocumentTypeName FROM DocumentType"; // Include ID in the query
            using (SqlCommand doc_command = new SqlCommand(query, db))
            {
                db.Open();
                using (SqlDataReader doc_reader = doc_command.ExecuteReader())
                {
                    while (doc_reader.Read())
                    {
                        var docType = new DocumentType
                        {
                            ID = (int)doc_reader["DocumentTypeID"],
                            Name = doc_reader["DocumentTypeName"].ToString()
                        };
                        documentTypes.Add(docType);
                        cmb_DocumentType.Items.Add(docType); // Add to ComboBox
                    }
                }
                db.Close();
            }
        }


        private void LoadPackage()
        {
            cmb_Package.Items.Clear();
            string pack_query = "SELECT PackageName FROM Package";
            using (SqlCommand pack_command = new SqlCommand(pack_query, db))
            {
                db.Open();
                using (SqlDataReader pack_reader = pack_command.ExecuteReader())
                {
                    while (pack_reader.Read())
                    {
                        cmb_Package.Items.Add(pack_reader["PackageName"].ToString());
                    }
                }
                db.Close();
            }
        }

        private void cmb_Package_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedPackage = cmb_Package.SelectedItem.ToString();

            LoadPackageDetails(selectedPackage);
        }

        private void LoadPackageDetails(string selectedPackage)
        {
            string query = @"SELECT p.PackageID, p.PackageName, c.CasketName, v.VehicleName, f.ArrangementName, s.SongName, ch.ChapelName, p.TotalPrice 
                             FROM Package p
                             JOIN Casket c ON p.CasketID = c.CasketID
                             JOIN Vehicle v ON p.VehicleID = v.VehicleID
                             JOIN FlowerArrangements f ON p.ArrangementID = f.ArrangementID
                             JOIN Song s ON p.SongID = s.SongID
                             JOIN ChapelReservation cr ON p.ReservationID = cr.ReservationID              
                             JOIN Chapel ch ON cr.ChapelID = ch.ChapelID
                             WHERE p.PackageName = @PackageName";


            SqlCommand command = new SqlCommand(query, db);
            command.Parameters.AddWithValue("@PackageName", selectedPackage);
            db.Open();

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable packageDetailsTable = new DataTable();
            adapter.Fill(packageDetailsTable);

            if (packageDetailsTable.Rows.Count > 0)
            {
                PackageID = (int)packageDetailsTable.Rows[0]["PackageID"];

                dgv_PackageDetails.DataSource = packageDetailsTable;


                dgv_PackageDetails.Columns["PackageID"].Visible = false;
            }
            else
            {
                MessageBox.Show("No package details found.");
            }
            db.Close();
        }


        private void OnTextChanged(object sender, EventArgs e)
        {
            typingTimer.Stop();
            typingTimer.Start();
        }

        private void TypingTimer_Tick(object sender, EventArgs e)
        {
            typingTimer.Stop();
            CheckIfClientExists();
        }

        private int CheckIfClientExists()
        {
            string firstName = txtFName.Text.Trim();
            string middleInitial = txt_MiddleInitial.Text.Trim();
            string lastName = txtLName.Text.Trim();

            if (!string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName))
            {
                string query = @"SELECT ClientID, Address FROM Clients
                                 WHERE FirstName = @FirstName 
                                 AND MiddleInitial = @MiddleInitial 
                                 AND LastName = @LastName";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@MiddleInitial", middleInitial);
                    command.Parameters.AddWithValue("@LastName", lastName);

                    try
                    {
                        db.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                txtAddress.Text = reader["Address"].ToString();
                                MessageBox.Show("This client has already availed a service.");
                                return (int)reader["ClientID"];
                            }
                        }
                        else
                        {
                            txtAddress.Text = string.Empty;
                            DialogResult dialogResult = MessageBox.Show("Client not found. Would you like to add a new client?", "Client Not Found", MessageBoxButtons.YesNo);
                            if (dialogResult == DialogResult.Yes)
                            {
                                AddNewClientForm addNewClientForm = new AddNewClientForm();
                                addNewClientForm.Show();
                            }
                        }
                    }
                    finally
                    {
                        if (db.State == ConnectionState.Open)
                        {
                            db.Close(); // Ensure the connection is closed
                        }
                    }
                }
            }
            return 0; 
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            if (cmb_DocumentType.SelectedItem == null)
            {
                MessageBox.Show("Please select a document type before uploading an image.", "Document Type Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                picb_documents.Image = Image.FromFile(filePath);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            int clientID = CheckIfClientExists();

            int selectedDocumentTypeID = ((DocumentType)cmb_DocumentType.SelectedItem).ID; 

            string query = @"INSERT INTO ServiceRequests (UserID, ClientID, ServiceStatusID, DocumentTypeID, CopPackageID, CopCasketID, CopVehicleID, 
                                                         CopArrangementID, CopSongID, CopLightID, ClientName, 
                                                         DeceasedFName, DeceasedLName, DeceasedMInitial, 
                                                         CasketName, VehicleName, FlowerArrangementName, 
                                                         SongName, ChapelName, ServiceLightsName, PackageName, 
                                                         Cemetery, DateBurial, TimeBurial, Address, DocumentType,
                                                         DocumentImage, EmbalmingDays, TotalPrice, CreatedBy)
                                                 VALUES (@UserID, @ClientID, @ServiceStatusID, @DocumentTypeID, @CopPackageID, @CopCasketID, @CopVehicleID, 
                                                         @CopArrangementID, @CopSongID, @CopLightID, @ClientName, 
                                                         @DeceasedFName, @DeceasedLName, @DeceasedMInitial, 
                                                         @CasketName, @VehicleName, @FlowerArrangementName, 
                                                         @SongName, @ChapelName, @ServiceLightsName, @PackageName, 
                                                         @Cemetery, @DateBurial, @TimeBurial, @Address, @DocumentType,
                                                         @DocumentImage, @EmbalmingDays, @TotalPrice, @CreatedBy)";

            SqlCommand command = new SqlCommand(query, db);

            command.Parameters.AddWithValue("@UserID", currentUserId);
            command.Parameters.AddWithValue("@ClientID", clientID);
            command.Parameters.AddWithValue("@ServiceStatusID", 1);
            command.Parameters.AddWithValue("@DocumentTypeID", selectedDocumentTypeID);

            command.Parameters.AddWithValue("@CopPackageID", SelectedIDPackage);
            command.Parameters.AddWithValue("@CopCasketID", SelectedIDCasket);
            command.Parameters.AddWithValue("@CopVehicleID", SelectedIDVehicle);
            command.Parameters.AddWithValue("@CopArrangementID", SelectedIDFlower);
            command.Parameters.AddWithValue("@CopSongID", SelectedIDSong);
            command.Parameters.AddWithValue("@CopLightID", SelectedLightID);

            command.Parameters.AddWithValue("@ClientName", txtFName.Text + " " + txt_MiddleInitial.Text + " " + txtLName.Text);
            command.Parameters.AddWithValue("@DeceasedFName", txt_DFname.Text);
            command.Parameters.AddWithValue("@DeceasedLName", txt_DLname.Text);
            command.Parameters.AddWithValue("@DeceasedMInitial", txt_DMname.Text);

            command.Parameters.AddWithValue("@PackageName", SelectedPackageName);
            command.Parameters.AddWithValue("@CasketName", SelectedCasketName);
            command.Parameters.AddWithValue("@VehicleName",SelectedVehicleName);
            command.Parameters.AddWithValue("@FlowerArrangementName", SelectedFlowerArrangementName);
            command.Parameters.AddWithValue("@SongName",SelectedSongName);
            command.Parameters.AddWithValue("@ChapelName", SelectedChapelName);
            command.Parameters.AddWithValue("@ServiceLightsName", SelectedLightName);

            command.Parameters.AddWithValue("@Cemetery", string.IsNullOrEmpty(txt_CemeteryLocation.Text) ? (object)DBNull.Value : txt_CemeteryLocation.Text);
            command.Parameters.AddWithValue("@DateBurial", dtp_burialdate.Value != DateTime.MinValue ? (object)dtp_burialdate.Value : DBNull.Value);
            command.Parameters.AddWithValue("@TimeBurial", dtp_burialtime.Value != DateTime.MinValue ? (object)dtp_burialtime.Value.TimeOfDay : DBNull.Value);
            command.Parameters.AddWithValue("@Address", txtAddress.Text);

            command.Parameters.AddWithValue("@DocumentType", cmb_DocumentType.SelectedItem.ToString());
            if (picb_documents.Image != null)
            {
                using (MemoryStream ms = new MemoryStream())
                {
                    picb_documents.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    command.Parameters.AddWithValue("@DocumentImage", ms.ToArray());
                }
            }
            command.Parameters.AddWithValue("@EmbalmingDays",SelectedEmbalmingDays);
            command.Parameters.AddWithValue("@TotalPrice", txt_Price.Text);
            command.Parameters.AddWithValue("@CreatedBy", createdBy);

            db.Open();
            command.ExecuteNonQuery();
            db.Close();

            DeleteCustomize();

            MessageBox.Show("Service request added successfully!");
        }

        private void DeleteCustomize()
        {
            string deleteQuery = "DELETE FROM CustomizePackage";
            using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, db))
            {
                db.Open();
                deleteCommand.ExecuteNonQuery();
                db.Close();
            }
        }
    }

    public class DocumentType
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
