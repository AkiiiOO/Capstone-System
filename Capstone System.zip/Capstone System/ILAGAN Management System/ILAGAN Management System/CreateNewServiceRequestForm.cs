﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CreateNewServiceRequestForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        private Timer typingTimer; 
        private const int TypingDelay = 2000; 

        public string SelectedFirstName { get; set; }
        public string SelectedMiddleInitial { get; set; }
        public string SelectedLastName { get; set; }
        public string SelectedAddress { get; set; }

        public CreateNewServiceRequestForm()
        {
            InitializeComponent();
            db = y.GetConnection();

            typingTimer = new Timer();
            typingTimer.Interval = TypingDelay;
            typingTimer.Tick += TypingTimer_Tick;

            txtFName.TextChanged += OnTextChanged;
            txt_MiddleInitial.TextChanged += OnTextChanged;
            txtLName.TextChanged += OnTextChanged;
        }

        private void btn_CustomizePackage_Click(object sender, EventArgs e)
        {
            if (cmb_Package.SelectedItem != null)
            {
                string selectedPackageName = cmb_Package.SelectedItem.ToString();
                CustomizePackage customizePackageForm = new CustomizePackage
                {
                    SelectedPackageName = selectedPackageName
                };

                if (customizePackageForm.ShowDialog() == DialogResult.OK)
                {
                    MessageBox.Show("Package customized successfully!");
                }
            }
            else
            {
                MessageBox.Show("Please select a package to customize.");
            }

        }

        private void dgv_ClientsRecords_Click(object sender, EventArgs e)
        {
            if (dgv_PackageDetails.SelectedRows.Count > 0)
            {
                // Get the selected casket's data
                DataRowView selectedRow = (DataRowView)dgv_PackageDetails.SelectedRows[0].DataBoundItem;

                SelectedFirstName = selectedRow["FirstName"].ToString();
                SelectedMiddleInitial = selectedRow["MiddleInitial"].ToString();
                SelectedLastName = selectedRow["LastName"].ToString();
                SelectedAddress = selectedRow["Address"].ToString();

                txtFName.Text = SelectedFirstName;
                txt_MiddleInitial.Text = SelectedMiddleInitial;
                txtLName.Text = SelectedLastName;
                txtAddress.Text = SelectedAddress;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void CreateNewServiceRequestForm_Load(object sender, EventArgs e)
        {
            LoadPackage();
        }

        private void LoadPackage()
        {
            cmb_Package.Items.Clear();
            string pack_query = "SELECT PackageName FROM Package";
            using (SqlCommand pack_command = new SqlCommand(pack_query, db))
            {
                db.Open();
                using (SqlDataReader pack_reader = pack_command.ExecuteReader())
                {
                    while (pack_reader.Read())
                    {
                        cmb_Package.Items.Add(pack_reader["PackageName"].ToString());
                    }
                }
                db.Close();
            }
        }

        private void cmb_Package_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedPackage = cmb_Package.SelectedItem.ToString();

            string query = @"SELECT p.PackageName, c.CasketName, v.VehicleName, f.ArrangementName, s.SongName, ch.ChapelName 
                             FROM Package p
                             JOIN Casket c ON p.CasketID = c.CasketID
                             JOIN Vehicle v ON p.VehicleID = v.VehicleID
                             JOIN FlowerArrangements f ON p.ArrangementID = f.ArrangementID
                             JOIN Song s ON p.SongID = s.SongID
                             JOIN ChapelReservation cr ON p.ReservationID = cr.ReservationID              
                             JOIN Chapel ch ON cr.ChapelID = ch.ChapelID
                             WHERE p.PackageName = @PackageName";


            SqlCommand command = new SqlCommand(query, db);
            command.Parameters.AddWithValue("@PackageName", selectedPackage);

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable packageDetailsTable = new DataTable();
            adapter.Fill(packageDetailsTable);

            dgv_PackageDetails.DataSource = packageDetailsTable;
        }


        private void OnTextChanged(object sender, EventArgs e)
        {
            // Restart the timer on every text change
            typingTimer.Stop();
            typingTimer.Start();
        }

        private void TypingTimer_Tick(object sender, EventArgs e)
        {
            typingTimer.Stop();
            CheckIfClientExists();
        }

        private void CheckIfClientExists()
        {
            string firstName = txtFName.Text.Trim();
            string middleInitial = txt_MiddleInitial.Text.Trim();
            string lastName = txtLName.Text.Trim();

            if (!string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName))
            {
                string query = @"SELECT FirstName, MiddleInitial, LastName, Address
                             FROM Clients
                             WHERE FirstName = @FirstName 
                               AND MiddleInitial = @MiddleInitial 
                               AND LastName = @LastName";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@MiddleInitial", middleInitial);
                    command.Parameters.AddWithValue("@LastName", lastName);

                    db.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            txtAddress.Text = reader["Address"].ToString();
                            MessageBox.Show("This client has already availed a service.");
                        }
                    }
                    else
                    {
                        txtAddress.Text = string.Empty;
                        DialogResult dialogResult = MessageBox.Show("Client not found. Would you like to add a new client?", "Client Not Found", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            AddNewClientForm addNewClientForm = new AddNewClientForm();
                            addNewClientForm.Show();
                            this.Hide();
                        }
                    }
                    db.Close();
                }
            }
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                picb_documents.Image = Image.FromFile(filePath);
            }
        }

    }
}
