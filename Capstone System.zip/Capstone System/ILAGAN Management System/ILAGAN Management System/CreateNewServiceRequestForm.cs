﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ILAGAN_Management_System;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class CreateNewServiceRequestForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        private int clientID;

        //for combo box document
        private List<DocumentType> documentTypes = new List<DocumentType>();
        //for combo box Cemetery
        private List<Cemetery> cemeteries = new List<Cemetery>();

        // resrvation id once inserted 
        private int reservationID;
        //value reservation
        private string location;
        private string chapelName;

        //for Custpmize package
        private int customizepackageID;
        //value customize package 
        private int packageID;
        private int casketID;
        private int vehicleID;
        private int flowerArrangementID;
        private int playlistsID;
        //Names
        private string packageName;
        private string casketName;
        private string vehicleName;
        private string flowerArrangementName;
        private string playlistsName;
        private int embalmingDays;
        private decimal totalPrice;

        public CreateNewServiceRequestForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadServiceType();
            LoadCemeteries();
            LoadDocumentTypes();
            LoadDiscounts();
            GetReservationDetails();
        }
        private void GetReservationDetails()
        {
            if (reservationID <= 0)
            {
                return; // Exit if there is no valid customize package ID
            }
            else
            {
                // Query to get package details
                string query = @"SELECT cr.Location, cr.ChapelID, ch.ChapelName 
                                 FROM ChapelReservation cr
                                 LEFT JOIN Chapel ch ON cr.ChapelID = ch.ChapelID
                                 WHERE cr.ReservationID = @ReservationID";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@ReservationID", reservationID);

                    try
                    {
                        db.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            if (reader.Read())
                            {

                                // Retrieve values
                                location = reader["Location"] != DBNull.Value ? reader["Location"].ToString() : "N/A";
                                chapelName = reader["ChapelName"] != DBNull.Value ? reader["ChapelName"].ToString() : "N/A";
                            }
                            else
                            {
                                MessageBox.Show("No package details found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching package details: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
        private void LoadServiceType()
        {
            cmb_ServiceType.Items.Clear();
            string query = "SELECT ServiceTypeID, ServiceTypeName FROM ServiceType";
            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable servicetypeTable = new DataTable();
                adapter.Fill(servicetypeTable);

                cmb_ServiceType.DataSource = servicetypeTable;
                cmb_ServiceType.DisplayMember = "ServiceTypeName";
                cmb_ServiceType.ValueMember = "ServiceTypeID";

                cmb_ServiceType.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Service type: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void btn_Reservation_Click(object sender, EventArgs e)
        {
            if (cmb_ServiceType.SelectedValue == null)
            {
                MessageBox.Show("Please select a service type.", "Service Type Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (clientID == 0)
            {
                MessageBox.Show("Please enter client details first.", "Client Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            int serviceTypeId = (int)cmb_ServiceType.SelectedValue;
            string selectedServiceType = cmb_ServiceType.Text;

            if (selectedServiceType == "Chapel Service")
            {
                OpenChapelSelectionForm(serviceTypeId, selectedServiceType);
            }
            else if (selectedServiceType == "Home Service")
            {
                OpenHomeLocationForm(serviceTypeId, selectedServiceType);
            }
            else
            {
                MessageBox.Show("Invalid service type selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void OpenChapelSelectionForm(int serviceTypeId, string selectedServiceType)
        {
            string clientName = ConstructClientName();

            if (string.IsNullOrEmpty(clientName))
            {
                MessageBox.Show("First name and last name cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Chapel_Service chapelServiceForm = new Chapel_Service(clientID, clientName, reservationID)
            {
            ServiceTypeId = serviceTypeId,
            SelectedServiceType = selectedServiceType 
            };
            chapelServiceForm.ShowDialog();

            if (chapelServiceForm.DialogResult == DialogResult.OK)
            {
                reservationID = chapelServiceForm.ReservationID;
                DisplayPrices();
                DateTime endDate = GetReservationEndDate();
                dtp_burialdate.Value = endDate;
                MessageBox.Show("Chapel reservation saved successfully. Reservation ID: " + reservationID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void OpenHomeLocationForm(int serviceTypeId, string selectedServiceType)
        {
            string clientName = ConstructClientName();

            if (string.IsNullOrEmpty(clientName))
            {
                MessageBox.Show("First name and last name cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Home_Service homeServiceForm = new Home_Service(clientID, clientName, reservationID)
            {
                ServiceTypeId = serviceTypeId,
                SelectedServiceType = selectedServiceType
            };
            homeServiceForm.ShowDialog();
            if (homeServiceForm.DialogResult == DialogResult.OK)
            {
                reservationID = homeServiceForm.ReservationID;
                DisplayPrices();
                DateTime endDate = GetReservationEndDate();
                dtp_burialdate.Value = endDate;
                MessageBox.Show("Home reservation saved successfully. Reservation ID: " + reservationID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        // if client dont have a middle name
        private string ConstructClientName()
        {
            string firstName = txtFName.Text.Trim();
            string lastName = txtLName.Text.Trim();
            string middleName = txt_MiddleInitial.Text.Trim();

            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
                return null;

            if (string.IsNullOrEmpty(middleName))
                return firstName + " " + lastName;

            return firstName + " " + middleName + ". " + lastName;
        }
        private void btn_Browse_Click(object sender, EventArgs e)
        {
            clientID = SearchClients();
            if (clientID > 0)
            {
                MessageBox.Show("Client with ID " + clientID + " selected.", "Client Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void AddNewClientForm_ClientAdded(object sender, EventArgs e)
        {
            MessageBox.Show("A new client was added.");
        }
        private int SearchClients()
        {
            string firstName = txtFName.Text.Trim();
            string middleName = txt_MiddleInitial.Text.Trim();
            string lastName = txtLName.Text.Trim();
            string address = txt_Address.Text;

            // Validate input
            if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName) || string.IsNullOrEmpty(address))
            {
                MessageBox.Show("Please enter necessary details.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return 0;
            }

            string query = @"SELECT ClientID, FirstName, MiddleName, LastName, Address, Contact_No FROM Clients
                     WHERE FirstName = @FirstName 
                     AND MiddleName = @MiddleName 
                     AND LastName = @LastName
                     AND Address = @Address";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@MiddleName", middleName);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@Address", address);

                try
                {
                    db.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable clientTable = new DataTable();
                    adapter.Fill(clientTable);

                    if (clientTable.Rows.Count == 1)
                    {
                        // Single client found
                        return Convert.ToInt32(clientTable.Rows[0]["ClientID"]);
                    }
                    else if (clientTable.Rows.Count > 1)
                    {
                        // Multiple clients found, open BrowseClientsForm
                        BrowseClient browseForm = new BrowseClient(clientTable);
                        if (browseForm.ShowDialog() == DialogResult.OK)
                        {
                            return browseForm.SelectedClientID;
                        }
                    }
                    else
                    {
                        // No client found
                        DialogResult dialogResult = MessageBox.Show("Client not found. Would you like to add a new client?", "Client Not Found", MessageBoxButtons.YesNo);
                        if (dialogResult == DialogResult.Yes)
                        {
                            AddNewClientForm addNewClientForm = new AddNewClientForm();
                            addNewClientForm.ClientAdded += AddNewClientForm_ClientAdded;
                            addNewClientForm.SetClientDetails(firstName, middleName, lastName, address);
                            addNewClientForm.ShowDialog();
                        }
                    }
                }
                finally
                {
                    db.Close();
                }
            }
            return 0;
        }
        //for combobox ducument
        private void LoadDocumentTypes()
        {
            cmb_DocumentType.Items.Clear();
            string query = "SELECT DocumentTypeID, DocumentTypeName FROM DocumentType"; // Include ID in the query
            using (SqlCommand doc_command = new SqlCommand(query, db))
            {
                db.Open();
                using (SqlDataReader doc_reader = doc_command.ExecuteReader())
                {
                    while (doc_reader.Read())
                    {
                        var docType = new DocumentType
                        {
                            ID = (int)doc_reader["DocumentTypeID"],
                            Name = doc_reader["DocumentTypeName"].ToString()
                        };
                        documentTypes.Add(docType);
                        cmb_DocumentType.Items.Add(docType); // Add to ComboBox
                    }
                }
                db.Close();
            }
        }
        //uploading pic for document
        private void btn_Upload_Click(object sender, EventArgs e)
        {
            if (cmb_DocumentType.SelectedItem == null)
            {
                MessageBox.Show("Please select a document type before uploading an image.", "Document Type Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog.Title = "Select an Image";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;
                picb_documents.Image = Image.FromFile(filePath);
            }
        }
        //view the document
        private void btn_View_Click(object sender, EventArgs e)
        {
            if (picb_documents.Image != null)
            {
                ImageViewerForm viewer = new ImageViewerForm(picb_documents.Image);
                viewer.ShowDialog();
            }
            else
            {
                MessageBox.Show("No document image available to view.", "Image Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        //for combo box cemetery
        private void LoadCemeteries()
        {
            cmb_CemeteryLocation.Items.Clear();
            string queryc = "SELECT CemeteryID, CemeteryName FROM Cemeteries";
            using (SqlCommand command = new SqlCommand(queryc, db))
            {
                try
                {
                    db.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var cemetery = new Cemetery
                            {
                                ID = (int)reader["CemeteryID"],
                                Name = reader["CemeteryName"].ToString()
                            };
                            cemeteries.Add(cemetery);
                            cmb_CemeteryLocation.Items.Add(cemetery);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error loading cemeteries: " + ex.Message);
                }
                finally
                {
                    db.Close();
                }
            }
        }
        private void btn_CustomizePackage_Click_1(object sender, EventArgs e)
        {
            CustomizePackage customizePackageForm = new CustomizePackage(customizepackageID);

            if (customizePackageForm.ShowDialog() == DialogResult.OK)
            {
                customizepackageID = customizePackageForm.CustomizePackageID;
                DisplayPackageDetails();
                DisplayPrices();
                MessageBox.Show("Customize Package saved successfully. Customize Package ID: " + customizepackageID, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void DisplayPackageDetails()
        {
            if (customizepackageID <= 0)
            {
                return; // Exit if there is no valid customize package ID
            }
            else
            {
                // Query to get package details
                string query = @"SELECT PackageID, PackageName, CasketID, CasketName, VehicleID, VehicleName, ArrangementID, FlowerArrangementName, PlaylistSongsID, PlaylistsName, EmbalmingDays, TotalPrice 
                     FROM CustomizePackage 
                     WHERE CustomizePackageID = @CustomizePackageID";

                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);

                    try
                    {
                        db.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Clear existing columns and rows
                            dgv_PackageDetails.Columns.Clear();
                            dgv_PackageDetails.Rows.Clear();

                            // Add columns for Name and Value
                            dgv_PackageDetails.Columns.Add("Name", "Name");
                            dgv_PackageDetails.Columns.Add("Value", "Value");

                            if (reader.Read())
                            {
                                // get value ID
                                packageID = reader["PackageID"] != DBNull.Value ? Convert.ToInt32(reader["PackageID"]) : 0;
                                casketID = reader["CasketID"] != DBNull.Value ? Convert.ToInt32(reader["CasketID"]) : 0;
                                vehicleID = reader["VehicleID"] != DBNull.Value ? Convert.ToInt32(reader["VehicleID"]) : 0;
                                flowerArrangementID = reader["ArrangementID"] != DBNull.Value ? Convert.ToInt32(reader["ArrangementID"]) : 0;
                                playlistsID = reader["PlaylistSongsID"] != DBNull.Value ? Convert.ToInt32(reader["PlaylistSongsID"]) : 0;

                                // Retrieve values
                                packageName = reader["PackageName"] != DBNull.Value ? reader["PackageName"].ToString() : "N/A";
                                casketName = reader["CasketName"] != DBNull.Value ? reader["CasketName"].ToString() : "N/A";
                                vehicleName = reader["VehicleName"] != DBNull.Value ? reader["VehicleName"].ToString() : "N/A";
                                flowerArrangementName = reader["FlowerArrangementName"] != DBNull.Value ? reader["FlowerArrangementName"].ToString() : "N/A";
                                playlistsName = reader["PlaylistsName"] != DBNull.Value ? reader["PlaylistsName"].ToString() : "N/A";
                                embalmingDays = reader["EmbalmingDays"] != DBNull.Value ? Convert.ToInt32(reader["EmbalmingDays"]) : 0;
                                totalPrice = (decimal)reader["TotalPrice"];
                                
                                // Add rows for each detail
                                dgv_PackageDetails.Rows.Add("Package", packageName);
                                dgv_PackageDetails.Rows.Add("Casket", casketName);
                                dgv_PackageDetails.Rows.Add("Vehicle", vehicleName);
                                dgv_PackageDetails.Rows.Add("Flower Arrangement", flowerArrangementName);
                                dgv_PackageDetails.Rows.Add("Playlists", playlistsName);
                                dgv_PackageDetails.Rows.Add("Embalming Days", embalmingDays);
                                dgv_PackageDetails.Rows.Add("Total Price", totalPrice.ToString("F2"));
                            }
                            else
                            {
                                MessageBox.Show("No package details found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching package details: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
        }
        //display the price 
        private void DisplayPrices()
        {
            decimal chapelPrice = 0;
            if (reservationID > 0)
            {
                // Check if reservationID has a valid value
                string chapelQuery = "SELECT Price FROM Chapel WHERE ChapelID = " +
                              "(SELECT ChapelID FROM ChapelReservation WHERE ReservationID = @ReservationID)";

                using (SqlCommand chapelCommand = new SqlCommand(chapelQuery, db))
                {
                    chapelCommand.Parameters.AddWithValue("@ReservationID", reservationID);

                    try
                    {
                        db.Open();
                        object chapelResult = chapelCommand.ExecuteScalar();

                        // Check if result is not null and parse the price
                        if (chapelResult != null)
                        {
                            chapelPrice = Convert.ToDecimal(chapelResult);
                        }
                        else
                        {
                            lbl_TotalPrice.Text = "0.00"; // Message if price is not found
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching chapel price: " + ex.Message);
                        return; // Exit on error
                    }
                    finally
                    {
                        db.Close();
                    }

                }
            }
            decimal packageTotalPrice = 0;

            // Only fetch package price if customizepackageID is valid
            if (customizepackageID > 0)
            {
                // Query to get total price from CustomizePackage
                string packageQuery = "SELECT TotalPrice FROM CustomizePackage WHERE CustomizePackageID = @CustomizePackageID";

                using (SqlCommand packageCommand = new SqlCommand(packageQuery, db))
                {
                    packageCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);

                    try
                    {
                        db.Open();
                        object packageResult = packageCommand.ExecuteScalar();

                        // Check if result is not null and parse the price
                        if (packageResult != null)
                        {
                            packageTotalPrice = Convert.ToDecimal(packageResult);
                        }
                        else
                        {
                            lbl_TotalPrice.Text = "Customize package price not available"; // Message if price is not found
                            return; // Exit if there's no price available
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching customize package price: " + ex.Message);
                        return; // Exit on error
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }

            decimal totalPrice = chapelPrice + packageTotalPrice;
            lbl_TotalPrice.Text = totalPrice.ToString("F2");
        }
        private DateTime GetReservationEndDate()
        {
            DateTime endDate = DateTime.Today; // Default in case of error

            string query = "SELECT EndDate FROM ChapelReservation WHERE ReservationID = @ReservationID";

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                cmd.Parameters.AddWithValue("@ReservationID", reservationID);

                try
                {
                    db.Open();
                    var result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        endDate = Convert.ToDateTime(result);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving reservation end date: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    db.Close();
                }
            }

            return endDate;
        }
        //for the discount 
        private void LoadDiscounts()
        {
            cmb_Discount.Items.Clear();
            string query = "SELECT DiscountID, DiscountName, DiscountRate FROM Discounts";
            try
            {
                db.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable discountTable = new DataTable();
                adapter.Fill(discountTable);

                cmb_Discount.DataSource = discountTable;
                cmb_Discount.DisplayMember = "DiscountName";
                cmb_Discount.ValueMember = "DiscountID"; // Use DiscountID as ValueMember

                cmb_Discount.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading discounts: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }

        private void cmb_Discount_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_Discount.SelectedItem != null)
            {
                DataRowView selectedRow = (DataRowView)cmb_Discount.SelectedItem;
                decimal discountRate = (decimal)selectedRow["DiscountRate"];

                if (string.IsNullOrEmpty(lbl_DiscountedPrice.Text) || lbl_DiscountedPrice.Text == "0")
                {
                    MessageBox.Show("Please ensure that a chapel reservation has been made and the price is available.", "Price Not Available", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                CalculateTotalPrice(discountRate);
            }
        }
        // calculate the totalprice and discount
        private void CalculateTotalPrice(decimal discountRate)
        {
            decimal totalPrice = 0;

            // Check if ReservationID is not null and fetch the chapel price
            if (reservationID > 0)
            {
                string query = "SELECT Price FROM Chapel WHERE ChapelID IN (SELECT ChapelID FROM ChapelReservation WHERE ReservationID = @ReservationID)";
                using (SqlCommand command = new SqlCommand(query, db))
                {
                    command.Parameters.AddWithValue("@ReservationID", reservationID);
                    try
                    {
                        db.Open();
                        object result = command.ExecuteScalar();
                        if (result != null)
                        {
                            totalPrice += Convert.ToDecimal(result);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching chapel price: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
            // Fetch the total price from the CustomizePackage if it is set
            if (customizepackageID > 0)
            {
                string packageQuery = "SELECT TotalPrice FROM CustomizePackage WHERE CustomizePackageID = @CustomizePackageID";
                using (SqlCommand packageCommand = new SqlCommand(packageQuery, db))
                {
                    packageCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                    try
                    {
                        db.Open();
                        object packageResult = packageCommand.ExecuteScalar();
                        if (packageResult != null)
                        {
                            totalPrice += Convert.ToDecimal(packageResult);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error fetching package price: " + ex.Message);
                    }
                    finally
                    {
                        db.Close();
                    }
                }
            }
            // Calculate discount amount
            decimal discountAmount = totalPrice * (discountRate / 100);
            decimal finalPrice = totalPrice - discountAmount;

            // Update the label to display the final price
            lbl_DiscountedPrice.Text = finalPrice.ToString("F2");
        }
        private bool ValidateBurialDate()
        {
            // Retrieve the EndDate from the database based on ReservationID
            DateTime endDate;

            string query = "SELECT EndDate FROM ChapelReservation WHERE ReservationID = @ReservationID";

            using (SqlCommand cmd = new SqlCommand(query, db))
            {
                cmd.Parameters.AddWithValue("@ReservationID", reservationID);

                try
                {
                    db.Open();
                    object result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        endDate = Convert.ToDateTime(result);

                        // Check if dtp_burialdate.Value is equal to endDate
                        if (dtp_burialdate.Value.Date != endDate.Date)
                        {
                            MessageBox.Show("Burial date must be the same as the reservation's end date.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return false; ;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No reservation found with the given ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false; 
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving reservation date: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false; 
                }
                finally
                {
                    db.Close();
                }
            }
            return true;
        }
        // btn Add 
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_DFname.Text) || string.IsNullOrEmpty(txt_DLname.Text))
            {
                MessageBox.Show("Please enter the deceased's first name and last name.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int serviceTypeId = cmb_ServiceType.SelectedValue != null ? (int)cmb_ServiceType.SelectedValue : -1;

            if (serviceTypeId == 1 && customizepackageID <= 0)
            {
                MessageBox.Show("Please select a package for Home Service.", "Package Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (reservationID > 0)
            {
                if (!ValidateBurialDate())
                {
                    return;
                }
            }

            DialogResult result = MessageBox.Show("Do you want to create this service request?",
                                          "Confirm Creation",
                                          MessageBoxButtons.YesNo,
                                          MessageBoxIcon.Question);

            // If the user clicks Yes, proceed to add the service request
            if (result == DialogResult.Yes)
            {
                AddServiceRequest();
                DeleteCustomize();
                ServiceRequestPrint printForm = new ServiceRequestPrint();
                printForm.ShowDialog();
            }

        }
        // to add service request databse 
        private void AddServiceRequest()
        {
            int currentUserId = CurrentUser.UserID;
            string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

            /*int clientID = SearchClients();
            if (clientID <= 0)
            {
                MessageBox.Show("Invalid client ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }*/
            string clientName = ConstructClientName();
            // Document combo box - optional
            int? selectedDocumentTypeID = null;
            string selectedDocumentTypeName = null;

            if (cmb_DocumentType.SelectedItem != null)
            {
                var selectedDocumentType = (DocumentType)cmb_DocumentType.SelectedItem;
                selectedDocumentTypeID = selectedDocumentType.ID;
                selectedDocumentTypeName = selectedDocumentType.Name;
            }

            //cemetery cobobox - optional
            int? selectedCemeteryID = null;
            string selectedCemeteryName = null;

            if (cmb_CemeteryLocation.SelectedItem != null)
            {
                var selectedCemetery = (Cemetery)cmb_CemeteryLocation.SelectedItem;
                selectedCemeteryID = selectedCemetery.ID;
                selectedCemeteryName = selectedCemetery.Name;
            }

            // Service type combo box - optional
            int? serviceTypeId = null;
            string serviceTypeName = null;

            if (cmb_ServiceType.SelectedValue != null)
            {
                serviceTypeId = (int)cmb_ServiceType.SelectedValue;
                serviceTypeName = cmb_ServiceType.Text;
            }

            // Get the selected discount
            int? discountID = cmb_Discount.SelectedValue != null ? (int?)cmb_Discount.SelectedValue : null;
            string discountName = cmb_Discount.SelectedItem != null ? ((DataRowView)cmb_Discount.SelectedItem)["DiscountName"].ToString() : string.Empty;
            decimal discountRate = cmb_Discount.SelectedItem != null ? (decimal)((DataRowView)cmb_Discount.SelectedItem)["DiscountRate"] : 0;

            string query = @"INSERT INTO ServiceRequests (UserID, ClientID, ServiceStatusID, DocumentTypeID, CemeteryID, ServiceTypeID, 
                                                        ReservationID, DiscountID, CopPackageID, CopCasketID, CopVehicleID, CopArrangementID, 
                                                        CopPlaylistID, ServiceType, ClientName, DeceasedFName, DeceasedLName, 
                                                        DeceasedMName, PackageName, CasketName, VehicleName, FlowerArrangementName, PlaylistName, 
                                                        ChapelName, Location, CemeteryLocation, DateBurial, 
                                                        TimeBurial, Address, DocumentType, DocumentImage, EmbalmingDays, TotalPrice, 
                                                        Discount, DiscountRate, DiscountTotal, CreationDate, CreatedBy) 
                                                        VALUES 
                                                        (@UserID, @ClientID, @ServiceStatusID, @DocumentTypeID, @CemeteryID, @ServiceTypeID, 
                                                        @ReservationID, @DiscountID, @CopPackageID, @CopCasketID, @CopVehicleID, @CopArrangementID, 
                                                        @CopPlaylistID, @ServiceType, @ClientName, @DeceasedFName, @DeceasedLName, 
                                                        @DeceasedMName, @PackageName, @CasketName, @VehicleName, @FlowerArrangementName, 
                                                        @PlaylistName, @ChapelName, @Location, @CemeteryLocation, @DateBurial, 
                                                        @TimeBurial, @Address, @DocumentType, @DocumentImage, @EmbalmingDays, 
                                                        @TotalPrice, @Discount, @DiscountRate, @DiscountTotal, GETDATE(), @CreatedBy);";

            using (SqlCommand command = new SqlCommand(query, db))
            {
                command.Parameters.AddWithValue("@UserID", currentUserId);
                command.Parameters.AddWithValue("@ClientID", clientID);
                command.Parameters.AddWithValue("@ServiceStatusID", 1);
                command.Parameters.AddWithValue("@ServiceTypeID", (object)serviceTypeId ?? DBNull.Value);
                command.Parameters.AddWithValue("@CemeteryID", (object)selectedCemeteryID ?? DBNull.Value);
                command.Parameters.AddWithValue("@DocumentTypeID", (object)selectedDocumentTypeID ?? DBNull.Value);
                command.Parameters.AddWithValue("@ReservationID", reservationID > 0 ? (object)reservationID : DBNull.Value);
                command.Parameters.AddWithValue("@DiscountID", (object)discountID ?? DBNull.Value);
                
                // Packages
                command.Parameters.AddWithValue("@CopPackageID", packageID > 0 ? (object)packageID : DBNull.Value);
                command.Parameters.AddWithValue("@CopCasketID", casketID > 0 ? (object)casketID : DBNull.Value);
                command.Parameters.AddWithValue("@CopVehicleID", vehicleID > 0 ? (object)vehicleID : DBNull.Value);
                command.Parameters.AddWithValue("@CopArrangementID", flowerArrangementID > 0 ? (object)flowerArrangementID : DBNull.Value); 
                command.Parameters.AddWithValue("@CopPlaylistID", playlistsID > 0 ? (object)playlistsID : DBNull.Value);

                //Service type
                command.Parameters.AddWithValue("@ServiceType", serviceTypeName ?? (object)DBNull.Value);

                // Client and deceased information
                command.Parameters.AddWithValue("@ClientName", clientName);
                command.Parameters.AddWithValue("@DeceasedFName", txt_DFname.Text);
                command.Parameters.AddWithValue("@DeceasedLName", txt_DLname.Text);
                command.Parameters.AddWithValue("@DeceasedMName", string.IsNullOrEmpty(txt_DMname.Text) ? (object)DBNull.Value : txt_DMname.Text);

                // Package information
                command.Parameters.AddWithValue("@PackageName", string.IsNullOrEmpty(packageName) ? DBNull.Value : (object)packageName);
                command.Parameters.AddWithValue("@CasketName", string.IsNullOrEmpty(casketName) ? DBNull.Value : (object)casketName); 
                command.Parameters.AddWithValue("@VehicleName", string.IsNullOrEmpty(vehicleName) ? DBNull.Value : (object)vehicleName);
                command.Parameters.AddWithValue("@FlowerArrangementName", string.IsNullOrEmpty(flowerArrangementName) ? DBNull.Value : (object)flowerArrangementName); 
                command.Parameters.AddWithValue("@PlaylistName", string.IsNullOrEmpty(playlistsName) ? DBNull.Value : (object)playlistsName);
                command.Parameters.AddWithValue("@ChapelName", string.IsNullOrEmpty(chapelName) ? (object)DBNull.Value : chapelName);
                command.Parameters.AddWithValue("@Location", string.IsNullOrEmpty(location) ? (object)DBNull.Value : location);

                // Burial and service details
                command.Parameters.AddWithValue("@CemeteryLocation", selectedCemeteryName ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@DateBurial", dtp_burialdate.Value != DateTime.MinValue ? (object)dtp_burialdate.Value : DBNull.Value);
                command.Parameters.AddWithValue("@TimeBurial", dtp_burialtime.Value != DateTime.MinValue ? (object)dtp_burialtime.Value.TimeOfDay : DBNull.Value);
                command.Parameters.AddWithValue("@Address", txt_Address.Text);

                // Document details
                command.Parameters.AddWithValue("@DocumentType", selectedDocumentTypeName ?? (object)DBNull.Value);
                if (picb_documents.Image != null)
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        picb_documents.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        command.Parameters.AddWithValue("@DocumentImage", ms.ToArray());
                    }
                }
                else
                {
                    command.Parameters.Add("@DocumentImage", SqlDbType.VarBinary).Value = DBNull.Value;
                }
                
                // Service specifics
                command.Parameters.AddWithValue("@EmbalmingDays", embalmingDays > 0 ? (object)embalmingDays : DBNull.Value);
                command.Parameters.AddWithValue("@TotalPrice", lbl_TotalPrice.Text);

                // Discount handling
                command.Parameters.AddWithValue("@Discount", discountName);
                command.Parameters.AddWithValue("@DiscountRate", discountRate);
                command.Parameters.AddWithValue("@DiscountTotal", string.IsNullOrEmpty(lbl_DiscountedPrice.Text) ? (object)DBNull.Value : lbl_DiscountedPrice.Text);

                command.Parameters.AddWithValue("@CreatedBy", createdBy);

                try
                {
                    db.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Service request added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error adding service request: " + ex.Message);
                }
                finally
                {
                    if (db.State == ConnectionState.Open)
                        db.Close();
                }
            }
        }
        //d pa nagamit 
        private void DeleteCustomize()
        {
            string deleteQuery = "DELETE FROM CustomizePackage";
            using (SqlCommand deleteCommand = new SqlCommand(deleteQuery, db))
            {
                db.Open();
                deleteCommand.ExecuteNonQuery();
                db.Close();
            }
        }

        private void CreateNewServiceRequestForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (reservationID > 0 || customizepackageID > 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to exit? Unsaved data will be deleted.",
                                          "Confirm Exit",
                                          MessageBoxButtons.YesNo,
                                          MessageBoxIcon.Warning);
                if (result == DialogResult.No)
                {
                    // Prevent the form from closing
                    e.Cancel = true;
                    return;
                }
                if (reservationID > 0)
                {
                    DeleteReservation();
                }

                if (customizepackageID > 0)
                {
                    DeleteCustomizePackage();
                }
            }
        }
        private void DeleteReservation()
        {
            string checkReservationStatusQuery = "SELECT ReservationStatusID FROM ChapelReservation WHERE ReservationID = @ReservationID";
            int reservationStatusID = 0;

            try
            {
                db.Open();
                using (SqlCommand checkReservationStatusCommand = new SqlCommand(checkReservationStatusQuery, db))
                {
                    checkReservationStatusCommand.Parameters.AddWithValue("@ReservationID", reservationID);
                    reservationStatusID = Convert.ToInt32(checkReservationStatusCommand.ExecuteScalar());
                }

                // Check if the reservation status is not "in chapel" (you need to define the ID for the "in chapel" status)
                if (reservationStatusID == 1)
                {
                    return;
                }

                // Proceed with the deletion if the status is not "in chapel"
                string deleteReservationQuery = "DELETE FROM ChapelReservation WHERE ReservationID = @ReservationID";
                using (SqlCommand deleteReservationCommand = new SqlCommand(deleteReservationQuery, db))
                {
                    deleteReservationCommand.Parameters.AddWithValue("@ReservationID", reservationID);
                    deleteReservationCommand.ExecuteNonQuery();
                }

                MessageBox.Show("Reservation deleted successfully.", "Deletion Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting reservation: " + ex.Message, "Deletion Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void DeleteCustomizePackage()
        {
            string deleteCustomizePackageQuery = "DELETE FROM CustomizePackage WHERE CustomizePackageID = @CustomizePackageID";

            try
            {
                db.Open();
                using (SqlCommand deleteCustomizePackageCommand = new SqlCommand(deleteCustomizePackageQuery, db))
                {
                    deleteCustomizePackageCommand.Parameters.AddWithValue("@CustomizePackageID", customizepackageID);
                    deleteCustomizePackageCommand.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting customize package: " + ex.Message, "Deletion Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
    }
    
    public class Cemetery
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public override string ToString()
        {
            return Name; 
        }
    }

    public class DocumentType
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
