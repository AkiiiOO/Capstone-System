﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class CreateNewServiceRequestForm : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public string SelectedFirstName { get; set; }
        public string SelectedMiddleInitial { get; set; }
        public string SelectedLastName { get; set; }
        public string SelectedAddress { get; set; }

        public CreateNewServiceRequestForm()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadClientRecords();
        }

        private void LoadClientRecords()
        {
            db.Open();
            // Display UsersTable
            string query = @"SELECT c.ClientID, c.FirstName, c.MiddleInitial, c.LastName, 
                             c.Address, c.Contact_No, c.CreatedBy
                             FROM Clients c";

            SqlCommand command = new SqlCommand(query, db);
            SqlDataAdapter dt = new SqlDataAdapter(command);
            DataTable ClientsTable = new DataTable();
            dt.Fill(ClientsTable);
            dgv_ClientsRecords.DataSource = ClientsTable;
            db.Close();
        }

        private void btn_EditUser_Click(object sender, EventArgs e)
        {
            CustomizePackage form1 = new CustomizePackage();
            if (form1.ShowDialog() == DialogResult.OK)
            {

               

            }
        }

        private void dgv_ClientsRecords_Click(object sender, EventArgs e)
        {
            if (dgv_ClientsRecords.SelectedRows.Count > 0)
            {
                // Get the selected casket's data
                DataRowView selectedRow = (DataRowView)dgv_ClientsRecords.SelectedRows[0].DataBoundItem;

                SelectedFirstName = selectedRow["FirstName"].ToString();
                SelectedMiddleInitial = selectedRow["MiddleInitial"].ToString();
                SelectedLastName = selectedRow["LastName"].ToString();
                SelectedAddress = selectedRow["Address"].ToString();

                txtFName.Text = SelectedFirstName;
                txt_MiddleInitial.Text = SelectedMiddleInitial;
                txtLName.Text = SelectedLastName;
                txtAddress.Text = SelectedAddress;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }
    }
}
