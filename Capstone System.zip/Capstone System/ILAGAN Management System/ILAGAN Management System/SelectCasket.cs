﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ILAGAN_Management_System
{
    public partial class SelectCasket : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public int SelectedCasketID { get; private set; }
        public string SelectedCasketName { get; set; }
        public decimal SelectedCasketPrice { get; set; }

        public SelectCasket()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadCaskets();
        }

        private void LoadCaskets()
        {
            try
            {
                db.Open();
                string query = "SELECT CasketID, CasketName, CasketTypeName, Price, CasketImage FROM Casket " +
                               "JOIN CasketType ON Casket.CasketTypeID = CasketType.CasketTypeID";
                SqlCommand command = new SqlCommand(query, db);
                SqlDataAdapter dt = new SqlDataAdapter(command);

                DataTable CasketTable = new DataTable();
                dt.Fill(CasketTable);
                dgv_CasketRecords.DataSource = CasketTable;

                // Rename the columns
                dgv_CasketRecords.Columns["CasketName"].HeaderText = "Casket";
                dgv_CasketRecords.Columns["CasketTypeName"].HeaderText = "Casket Type";
                dgv_CasketRecords.Columns["Price"].HeaderText = "Price";
                dgv_CasketRecords.Columns["CasketImage"].HeaderText = "Image";

                dgv_CasketRecords.Columns["CasketID"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading caskets: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                {
                    db.Close();
                }
            }
        }

        private void dgv_CasketRecords_DoubleClick(object sender, EventArgs e)
        {
            if (dgv_CasketRecords.SelectedRows.Count > 0)
            {
                // Get the selected casket's data
                DataRowView selectedRow = (DataRowView)dgv_CasketRecords.SelectedRows[0].DataBoundItem;

                SelectedCasketID = (int)selectedRow["CasketID"];
                SelectedCasketName = selectedRow["CasketName"].ToString();
                SelectedCasketPrice = (decimal)selectedRow["Price"];


                // Show the casket name in a label
                lbl_CasketName.Text = SelectedCasketName;
                lbl_CasketPrice.Text = SelectedCasketPrice.ToString("F2");

                if (selectedRow["CasketImage"] != DBNull.Value)
                {
                    byte[] image = (byte[])selectedRow["CasketImage"];
                    if (image.Length > 0)
                    {
                        using (MemoryStream ms = new MemoryStream(image))
                        {
                            picbox_CasketImage.Image = Image.FromStream(ms);
                        }
                    }
                    else
                    {
                        picbox_CasketImage.Image = null;
                    }
                }
                else
                {
                    picbox_CasketImage.Image = null;
                }
            }
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            string searchText = txt_search.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadCaskets();
                return;
            }
            string query = @"SELECT CasketID, CasketName, CasketTypeName, Price, CasketImage 
                             FROM Casket 
                             JOIN CasketType ON Casket.CasketTypeID = CasketType.CasketTypeID 
                             WHERE CasketName LIKE @SearchText OR CasketTypeName LIKE @SearchText";

            SqlCommand cmd = new SqlCommand(query, db);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            try
            {
                db.Open();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    dgv_CasketRecords.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("No records found.", "Search Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dgv_CasketRecords.DataSource = null;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                if (db.State == ConnectionState.Open)
                    db.Close();
            }
        }
        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (SelectedCasketID > 0 && !string.IsNullOrEmpty(SelectedCasketName))
            {
                this.DialogResult = DialogResult.OK;
                this.Close(); // Close the form
            }
            else
            {
                MessageBox.Show("Please select a casket.");
            }
        }
    }
}
