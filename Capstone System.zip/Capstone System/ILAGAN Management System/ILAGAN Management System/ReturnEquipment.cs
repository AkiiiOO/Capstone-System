﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class ReturnEquipment : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;
        public ReturnEquipment()
        {
            InitializeComponent();
            db = y.GetConnection();
            LoadReleasedServiceRequests();
        }
        private void LoadReleasedServiceRequests()
        {
            try
            {
                db.Open();

                // Update the query to select only ongoing service requests that have equipment and a service location
                string query = @"
            SELECT 
                sr.ServiceRequestID,  
                sr.ClientName, 
                sr.ServiceLocation, 
                sr.PackageName
            FROM ServiceRequests sr
            JOIN ServiceStatus ss ON sr.ServiceStatusID = ss.ServiceStatusID
            LEFT JOIN EquipmentRelease srpe ON srpe.ServiceRequestID = sr.ServiceRequestID
             WHERE srpe.EquipmentStatusID = 3";

                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                // Rename columns for display
                dataTable.Columns["ClientName"].ColumnName = "Client";
                dataTable.Columns["ServiceLocation"].ColumnName = "Service Location";
                dataTable.Columns["PackageName"].ColumnName = "Package";

                dgv_ReleaseEquipment.Columns["SelectColumn"].Visible = true;
                dgv_ReleaseEquipment.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading ongoing service requests: " + ex.Message);
            }
            finally
            {
                db.Close();
            }
        }

        private void btn_Return_Click(object sender, EventArgs e)
        {
            ReturnEquipment releaseForm = new ReturnEquipment();
            releaseForm.ShowDialog();
        }

    }
}
