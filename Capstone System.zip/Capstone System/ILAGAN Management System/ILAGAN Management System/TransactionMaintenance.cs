﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class TransactionMaintenance : Form
    {
        SqlDbConnection y = new SqlDbConnection();
        SqlConnection db;

        public TransactionMaintenance()
        {
            InitializeComponent();
            db = y.GetConnection();
            customizeDesign();
            showSubMenu(panelTransactionSubMenu);
            btn_TransactionMaintenance.BackColor = Color.LightSkyBlue;
            UserAccessLevel();
            LoadDiscounts();
            txt_PaymentInterval.Text = "Monthly";
            txt_PaymentInterval.ReadOnly = true;
            LoadInstallmentPlans();
        }
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
            panelTransactionSubMenu.Visible = false;
            panelInventorySubMenu.Visible = false;
            panelReportsSubMenu.Visible = false;
            panelSettingsSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            //user
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            //service
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
            //transaction
            if (panelTransactionSubMenu.Visible == true)
                panelTransactionSubMenu.Visible = false;
            //inventory
            if (panelInventorySubMenu.Visible == true)
                panelInventorySubMenu.Visible = false;
            //reports
            if (panelReportsSubMenu.Visible == true)
                panelReportsSubMenu.Visible = false;
            //setting
            if (panelSettingsSubMenu.Visible == true)
                panelSettingsSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }

        //Home Nav
        private void btn_Home_Click(object sender, EventArgs e)
        {
            Home form2 = new Home();
            form2.Show();
            this.Hide();
        }

        //UserSubMenu
        private void btn_User_Click(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus
        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            UsersLog form1 = new UsersLog();
            form1.Show();
            this.Hide();
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            ServiceRequest form3 = new ServiceRequest();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Package_Click(object sender, EventArgs e)
        {
            CreatePackage form2 = new CreatePackage();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ServiceFileMaintenance_Click(object sender, EventArgs e)
        {
            ServiceMaintenance form2 = new ServiceMaintenance();
            form2.Show();
            this.Hide();
            hideSubMenu();
        }


        //TransactionSubMenu
        private void btn_Transaction_Click(object sender, EventArgs e)
        {
            showSubMenu(panelTransactionSubMenu);
        }
        //TheSubMenus
        private void btn_Payment_Click(object sender, EventArgs e)
        {
            Payment form3 = new Payment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_InstallmentPayment_Click_1(object sender, EventArgs e)
        {
            InstallmentPayment form3 = new InstallmentPayment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_TransactionMaintenance_Click(object sender, EventArgs e)
        {
            TransactionMaintenance form3 = new TransactionMaintenance();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //InventorySubMenus
        private void btn_Inventory_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelInventorySubMenu);
        }
        private void btn_AddEquipment_Click(object sender, EventArgs e)
        {
            AddEquipment form3 = new AddEquipment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Release_Click(object sender, EventArgs e)
        {
            ReleaseEquipment form3 = new ReleaseEquipment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_ReturnEquipment_Click(object sender, EventArgs e)
        {
            ReturnEquipment form3 = new ReturnEquipment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_DamageEquipment_Click(object sender, EventArgs e)
        {
            DamageEquipment form3 = new DamageEquipment();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //ReportsSubMenus
        private void btn_Reports_Click(object sender, EventArgs e)
        {
            showSubMenu(panelReportsSubMenu);
        }
        private void btn_ServiceHistory_Click(object sender, EventArgs e)
        {
            ServiceHistory form3 = new ServiceHistory();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_EquipmentReleaseLog_Click(object sender, EventArgs e)
        {
            EquipmentReleaseLogReport form3 = new EquipmentReleaseLogReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Inventory_Click(object sender, EventArgs e)
        {
            InventoryMasterListReport form3 = new InventoryMasterListReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_Sales_Click(object sender, EventArgs e)
        {
            SalesReport form3 = new SalesReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_EquipmentNarrative_Click(object sender, EventArgs e)
        {
            EquipmentnNarrativeReport form3 = new EquipmentnNarrativeReport();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        //SettingsSubMenus
        private void btn_Settings_Click(object sender, EventArgs e)
        {
            showSubMenu(panelSettingsSubMenu);
        }
        private void btn_EmployeeList_Click(object sender, EventArgs e)
        {
            EmployeeList form3 = new EmployeeList();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_AccountDetails_Click(object sender, EventArgs e)
        {
            AccountDetails form3 = new AccountDetails();
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks Yes log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LogUserLogout();
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }
        private void LogUserLogout()
        {
            try
            {
                if (CurrentUser.LogID > 0)
                {
                    string logoutQuery = "UPDATE UserLog SET LogoutDateTime = GETDATE() WHERE LogID = @LogID";
                    SqlCommand logoutCommand = new SqlCommand(logoutQuery, db);
                    logoutCommand.Parameters.AddWithValue("@LogID", CurrentUser.LogID);

                    y.Open();
                    logoutCommand.ExecuteNonQuery();
                    y.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while logging out: " + ex.Message);
            }
        }
        private void UserAccessLevel()
        {
            int userID = CurrentUser.UserID;

            //what buttons admin can access
            if (CurrentUser.AccessLevel == "1")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = true;
                btn_AddUser.Visible = true;
                btn_UserLog.Visible = true;
                //service
                btn_Service.Visible = true;
                btn_AddClient.Visible = true;
                btn_ServiceRequest.Visible = true;
                btn_Package.Visible = true;
                btn_ServiceFileMaintenance.Visible = true;
                //transaction
                btn_Transaction.Visible = true;
                btn_Payment.Visible = true;
                btn_InstallmentPayment.Visible = true;
                btn_TransactionMaintenance.Visible = true;
                //Inventory
                btn_Inventory.Visible = true;
                btn_AddEquipment.Visible = true;
                btn_Release.Visible = true;
                btn_ReturnEquipment.Visible = true;
                btn_DamageEquipment.Visible = true;
                //report
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = true;
                btn_EquipmentReleaseLog.Visible = true;
                btn_InventoryMasterList.Visible = true;
                btn_Sales.Visible = true;
                btn_EquipmentNarrative.Visible = true;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = true;
                btn_AccountDetails.Visible = true;
            }
            //what buttons Service Staff can access
            else if (CurrentUser.AccessLevel == "2")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = false;
                btn_AddUser.Visible = false;
                btn_UserLog.Visible = false;
                //service
                btn_Service.Visible = true;
                btn_AddClient.Visible = true;
                btn_ServiceRequest.Visible = true;
                btn_Package.Visible = true;
                btn_ServiceFileMaintenance.Visible = true;
                //transaction
                btn_Transaction.Visible = true;
                btn_Payment.Visible = true;
                btn_InstallmentPayment.Visible = true;
                btn_TransactionMaintenance.Visible = true;
                //Inventory
                btn_Inventory.Visible = false;
                btn_AddEquipment.Visible = false;
                btn_Release.Visible = false;
                btn_ReturnEquipment.Visible = false;
                btn_DamageEquipment.Visible = false;
                //report
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = true;
                btn_EquipmentReleaseLog.Visible = false;
                btn_Inventory.Visible = false;
                btn_Sales.Visible = true;
                btn_EquipmentNarrative.Visible = false;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = false;
                btn_AccountDetails.Visible = true;
            }
            //what buttons Inventory Staff can access
            else if (CurrentUser.AccessLevel == "3")
            {
                btn_Home.Visible = true;
                //user
                btn_User.Visible = false;
                btn_AddUser.Visible = false;
                btn_UserLog.Visible = false;
                //service 
                btn_Service.Visible = false;
                btn_AddClient.Visible = false;
                btn_ServiceRequest.Visible = false;
                btn_Package.Visible = false;
                btn_ServiceFileMaintenance.Visible = false;
                //transaction
                btn_Transaction.Visible = false;
                btn_Payment.Visible = false;
                btn_InstallmentPayment.Visible = false;
                btn_TransactionMaintenance.Visible = false;
                //Inventory
                btn_Inventory.Visible = true;
                btn_AddEquipment.Visible = true;
                btn_Release.Visible = true;
                btn_ReturnEquipment.Visible = true;
                btn_DamageEquipment.Visible = true;
                //report module
                btn_Reports.Visible = true;
                btn_ServiceHistory.Visible = false;
                btn_EquipmentReleaseLog.Visible = true;
                btn_Inventory.Visible = true;
                btn_Sales.Visible = false;
                btn_EquipmentNarrative.Visible = true;
                //settings
                btn_Settings.Visible = true;
                btn_EmployeeList.Visible = false;
                btn_AccountDetails.Visible = true;
            }
        }
        private void LoadDiscounts()
        {
            try
            {
                string query = "SELECT DiscountID, DiscountName, DiscountRate FROM Discounts";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtDiscounts = new DataTable();
                adapter.Fill(dtDiscounts);

                dgv_DiscountList.DataSource = dtDiscounts;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Discounts: " + ex.Message);
            }
        }

        private void btn_Add_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (string.IsNullOrEmpty(txt_DiscountName.Text) || string.IsNullOrEmpty(txt_DiscountRate.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                string discountName = txt_DiscountName.Text;
                decimal discountRate = decimal.Parse(txt_DiscountRate.Text);
                string createdBy = CurrentUser.FirstName + ", " + CurrentUser.LastName;

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO Discounts (DiscountName, DiscountRate) VALUES (@DiscountName, @DiscountRate)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@DiscountName", discountName);
                    command.Parameters.AddWithValue("@DiscountRate", discountRate);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Discount added successfully.");
                        LoadDiscounts();
                    }
                    else
                    {
                        MessageBox.Show("Error adding Discount.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (dgv_DiscountList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a Discount to update.");
                return;
            }

            if (string.IsNullOrEmpty(txt_DiscountName.Text) || string.IsNullOrEmpty(txt_DiscountRate.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                int discountId = Convert.ToInt32(dgv_DiscountList.SelectedRows[0].Cells["DiscountID"].Value);
                string discountName = txt_DiscountName.Text;
                decimal discountRate = decimal.Parse(txt_DiscountRate.Text);

                string updateQuery = "UPDATE Discounts SET DiscountName = @DiscountName, DiscountRate = @DiscountRate WHERE DiscountID = @DiscountID";

                using (SqlCommand command = new SqlCommand(updateQuery, db))
                {
                    command.Parameters.AddWithValue("@DiscountName", discountName);
                    command.Parameters.AddWithValue("@DiscountRate", discountRate);
                    command.Parameters.AddWithValue("@DiscountID", discountId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Discount updated successfully.");
                        LoadDiscounts();
                    }
                    else
                    {
                        MessageBox.Show("Error updating Discount.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_Delete_Click(object sender, EventArgs e)
        {
            if (dgv_DiscountList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a Discount to delete.");
                return;
            }

            try
            {
                int discountId = Convert.ToInt32(dgv_DiscountList.SelectedRows[0].Cells["DiscountID"].Value);

                string deleteQuery = "DELETE FROM Discounts WHERE DiscountID = @DiscountID";

                using (SqlCommand command = new SqlCommand(deleteQuery, db))
                {
                    command.Parameters.AddWithValue("@DiscountID", discountId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Discount deleted successfully.");
                        LoadDiscounts();
                    }
                    else
                    {
                        MessageBox.Show("Error deleting Discount.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgv_DiscountList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_DiscountList.Rows[e.RowIndex];
                txt_DiscountName.Text = row.Cells["DiscountName"].Value.ToString();
                txt_DiscountRate.Text = row.Cells["DiscountRate"].Value.ToString();
            }
        }
        private void LoadInstallmentPlans()
        {
            try
            {
                string query = "SELECT InstallmentPlanID, PlanName, NumberOfPayments, PaymentInterval FROM InstallmentPlans";
                SqlDataAdapter adapter = new SqlDataAdapter(query, db);
                DataTable dtPlans = new DataTable();
                adapter.Fill(dtPlans);

                dgv_PlanList.DataSource = dtPlans;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading Installment Plans: " + ex.Message);
            }
        }


        private void btn_Addplan_Click(object sender, EventArgs e)
        {
            // Check if all fields are filled
            if (string.IsNullOrEmpty(txt_PlanName.Text) || string.IsNullOrEmpty(txt_NumberOfPayments.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                // Get values from form controls
                string planName = txt_PlanName.Text;
                int numberOfPayments = int.Parse(txt_NumberOfPayments.Text);
                string paymentInterval = "Monthly";  // Default to "Monthly"

                // Prepare the SQL Insert query
                string insertQuery = "INSERT INTO InstallmentPlans (PlanName, NumberOfPayments, PaymentInterval) " +
                                     "VALUES (@PlanName, @NumberOfPayments, @PaymentInterval)";

                using (SqlCommand command = new SqlCommand(insertQuery, db))
                {
                    command.Parameters.AddWithValue("@PlanName", planName);
                    command.Parameters.AddWithValue("@NumberOfPayments", numberOfPayments);
                    command.Parameters.AddWithValue("@PaymentInterval", paymentInterval);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Installment Plan added successfully.");
                        LoadInstallmentPlans();
                    }
                    else
                    {
                        MessageBox.Show("Error adding Installment Plan.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_EditPlan_Click(object sender, EventArgs e)
        {
            if (dgv_PlanList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an Installment Plan to update.");
                return;
            }

            if (string.IsNullOrEmpty(txt_PlanName.Text) || string.IsNullOrEmpty(txt_NumberOfPayments.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            try
            {
                int planId = Convert.ToInt32(dgv_PlanList.SelectedRows[0].Cells["InstallmentPlanID"].Value);
                string planName = txt_PlanName.Text;
                int numberOfPayments = int.Parse(txt_NumberOfPayments.Text);
                string paymentInterval = "Monthly";  // Always set to "Monthly"

                string updateQuery = "UPDATE InstallmentPlans SET PlanName = @PlanName, NumberOfPayments = @NumberOfPayments, PaymentInterval = @PaymentInterval WHERE InstallmentPlanID = @InstallmentPlanID";

                using (SqlCommand command = new SqlCommand(updateQuery, db))
                {
                    command.Parameters.AddWithValue("@PlanName", planName);
                    command.Parameters.AddWithValue("@NumberOfPayments", numberOfPayments);
                    command.Parameters.AddWithValue("@PaymentInterval", paymentInterval);
                    command.Parameters.AddWithValue("@InstallmentPlanID", planId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Installment Plan updated successfully.");
                        LoadInstallmentPlans();
                    }
                    else
                    {
                        MessageBox.Show("Error updating Installment Plan.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btn_DeletePlan_Click(object sender, EventArgs e)
        {
            if (dgv_PlanList.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an Installment Plan to delete.");
                return;
            }

            try
            {
                int planId = Convert.ToInt32(dgv_PlanList.SelectedRows[0].Cells["InstallmentPlanID"].Value);

                string deleteQuery = "DELETE FROM InstallmentPlans WHERE InstallmentPlanID = @InstallmentPlanID";

                using (SqlCommand command = new SqlCommand(deleteQuery, db))
                {
                    command.Parameters.AddWithValue("@InstallmentPlanID", planId);

                    db.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    db.Close();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Installment Plan deleted successfully.");
                        LoadInstallmentPlans();
                    }
                    else
                    {
                        MessageBox.Show("Error deleting Installment Plan.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void dgv_PlanList_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgv_PlanList.Rows[e.RowIndex];
                txt_PlanName.Text = row.Cells["PlanName"].Value.ToString();
                txt_NumberOfPayments.Text = row.Cells["NumberOfPayments"].Value.ToString();
                // Keep the interval as "Monthly"
                txt_PaymentInterval.Text = "Monthly";
            }
        }

    }
}
