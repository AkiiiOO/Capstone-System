﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ILAGAN_Management_System
{
    public partial class AddClient : Form
    {
        private string username;


        public AddClient(string username)
        {
            InitializeComponent();
            this.username = username;
            customizeDesign();
        }
        //submenu hide
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }
        private void btn_Home_Click_1(object sender, EventArgs e)
        {
            Home form2 = new Home(username);
            form2.Show();
            this.Hide();
        }
        //UserSubMenu
        private void btn_User_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus

        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser(username);
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient(username);
            form3.Show();
            this.Hide();
            hideSubMenu();
        }


        //Button
        private void btnNewUser_Click(object sender, EventArgs e)
        {
            AddNewClientForm addClientForm = new AddNewClientForm();
            addClientForm.ShowDialog();
        }



        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks 'Yes', log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }


    }
}
