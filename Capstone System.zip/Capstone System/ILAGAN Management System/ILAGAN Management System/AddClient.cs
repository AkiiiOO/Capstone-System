﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ILAGAN_Management_System
{
    public partial class AddClient : Form
    {
        SqlConnection x = new SqlConnection(@"Data Source=JOHN-PC;Initial Catalog=db_Ilagan;Integrated Security=True");
        private string username;

        public AddClient(string username)
        {
            InitializeComponent();
            this.username = username;
            LoadClientRecords();
            customizeDesign();
        }
        //submenu hide
        private void customizeDesign()
        {
            panelUserSubmenu.Visible = false;
            panelServiceSubMenu.Visible = false;
        }

        private void hideSubMenu()
        {
            if (panelUserSubmenu.Visible == true)
                panelUserSubmenu.Visible = false;
            if (panelServiceSubMenu.Visible == true)
                panelServiceSubMenu.Visible = false;
        }

        private void showSubMenu(Panel subMenu)
        {
            if (subMenu.Visible == false)
            {
                hideSubMenu();
                subMenu.Visible = true;
            }
            else
                subMenu.Visible = false;
        }
        private void btn_Home_Click_1(object sender, EventArgs e)
        {
            Home form2 = new Home(username);
            form2.Show();
            this.Hide();
        }
        //UserSubMenu
        private void btn_User_Click_1(object sender, EventArgs e)
        {
            showSubMenu(panelUserSubmenu);
        }
        //TheSubMenus

        private void btn_AddUser_Click(object sender, EventArgs e)
        {
            AddUser form1 = new AddUser(username);
            form1.Show();
            this.Hide();
            hideSubMenu();
        }
        private void btn_UserLog_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        //ServiceSubMenu
        private void btn_Service_Click(object sender, EventArgs e)
        {
            showSubMenu(panelServiceSubMenu);
        }
        //TheSubMenus
        private void btn_ServiceRequest_Click(object sender, EventArgs e)
        {
            hideSubMenu();
        }

        private void btn_AddClient_Click(object sender, EventArgs e)
        {
            AddClient form3 = new AddClient(username);
            form3.Show();
            this.Hide();
            hideSubMenu();
        }

        private void AddClientForm_ClientAdded(object sender, EventArgs e)
        {
            LoadClientRecords();
        }


        //Button
        private void btnNewUser_Click(object sender, EventArgs e)
        {
            AddNewClientForm addClientForm = new AddNewClientForm();
            addClientForm.ClientAdded += AddClientForm_ClientAdded;
            addClientForm.ShowDialog();
        }
        private void btn_EditUser_Click(object sender, EventArgs e)
        {
            EditClientForm editClientForm = new EditClientForm();
            editClientForm.ShowDialog();
        }


        private void btnLogout_Click(object sender, EventArgs e)
        {
            //ask the user if they want to logout
            DialogResult respond = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // If user clicks 'Yes', log out and go back to login form
            if (respond == DialogResult.Yes)
            {
                LoginForm loginForm = new LoginForm();
                loginForm.Show();
                this.Close();
            }
        }

        private void LoadClientRecords()
        {
            x.Open();
            // Display UsersTable
            string query = @"SELECT c.ClientID, c.FirstName, c.MiddleInitial, c.LastName, c.Email, 
                             c.Address, c.Contact_No, c.DateCreated, c.CreatedBy
                             FROM Clients c";

            SqlCommand command = new SqlCommand(query, x);
            SqlDataAdapter dt = new SqlDataAdapter(command);
            DataTable ClientsTable = new DataTable();
            dt.Fill(ClientsTable);
            dgv_ClientsRecords.DataSource = ClientsTable;
            x.Close();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtsearch.Text.Trim();

            if (string.IsNullOrEmpty(searchText))
            {
                LoadClientRecords();
                return;
            }

            string query = @"SELECT c.ClientID, c.FirstName, c.MiddleInitial, c.LastName, c.Email, c.Address, c.Contact_No, 
                             c.DateCreated, c.CreatedBy
                     FROM Clients c
                     WHERE c.FirstName LIKE @SearchText 
                        OR c.MiddleInitial LIKE @SearchText
                        OR c.ClientID LIKE @SearchText
                        OR c.LastName LIKE @SearchText
                        OR c.Email LIKE @SearchText";


            SqlCommand cmd = new SqlCommand(query, x);
            cmd.Parameters.AddWithValue("@SearchText", "%" + searchText + "%");

            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            dgv_ClientsRecords.DataSource = dt;
        }



    }
}
